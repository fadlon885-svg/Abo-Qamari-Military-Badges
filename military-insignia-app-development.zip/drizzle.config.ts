import "dotenv/config";
import { defineConfig } from "drizzle-kit";

// Only drizzle-kit commands need the URL; importing this file elsewhere must not crash the build.
const url = process.env.DATABASE_URL;
if (!url && process.argv.some((arg) => /drizzle-kit/.test(arg))) {
  throw new Error("DATABASE_URL is required to run Drizzle Kit");
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: { url: url || "postgresql://localhost:5432/placeholder" },
});
