import type { NextConfig } from "next";

/**
 * Security headers.
 * - Always on: nosniff, referrer policy, permissions policy, HSTS.
 * - Clickjacking protection (frame-ancestors / X-Frame-Options) is OPT-IN via FRAME_ANCESTORS because the
 *   Arena preview embeds the app in an iframe whose parent origin is not predictable. On Vercel set
 *   FRAME_ANCESTORS='none' (or a space-separated origin list) to enable it; see DEPLOY_VERCEL.md.
 */
const frameAncestors = (process.env.FRAME_ANCESTORS || "").trim();

const cspDirectives = [
  "default-src 'self'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  "style-src 'self' 'unsafe-inline'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:",
  "connect-src 'self' blob:",
  "worker-src 'self' blob:",
  "manifest-src 'self'",
];
if (frameAncestors) cspDirectives.push(`frame-ancestors ${frameAncestors}`);

const securityHeaders: { key: string; value: string }[] = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "geolocation=*, camera=(), microphone=(), payment=(), usb=()" },
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
  { key: "Content-Security-Policy", value: cspDirectives.join("; ") },
];
if (frameAncestors === "'none'") securityHeaders.push({ key: "X-Frame-Options", value: "DENY" });

const nextConfig: NextConfig = {
  poweredByHeader: false,
  // sharp is used for logo/icon generation and upload validation; keep it external so Vercel bundles its native binaries.
  serverExternalPackages: ["sharp"],
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

export default nextConfig;
