"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { createArabicReportPdf, downloadBlob, shareReportFile } from "@/lib/report-export";
import AdminAuth from "@/components/admin-auth";
import PromoBannerView from "@/components/promo-banner";
import { DEFAULT_PROMO, type PromoBanner } from "@/lib/promo-shared";
import SecurityCenter from "@/components/security-center";

type CustomField = { key: string; label: string; type: "text" | "textarea" | "select"; required?: boolean; options?: string[] };
type Category = {
  id: number; slug: string; name: string; description: string; sortOrder: number; visible: boolean; archived: boolean;
  includeInOverall: boolean; customFields: CustomField[];
};
type Product = {
  id: number; categoryId: number | null; name: string; description: string; customFields: CustomField[];
  unitPrice: string | null; imageUrl: string | null; archived: boolean;
};
type CommerceSettings = { bankak: string; fawry: string; okash: string; paymentInstructions: string; accountOwner: string; whatsappUrl: string; paymentImageUrl: string; contactName: string; contactPhone: string; contactEmail: string };
type OrderRecord = {
  id: number; orderCode: string; categoryId: number | null; productId: number | null; categoryNameSnapshot: string;
  productNameSnapshot: string; printedName: string | null; details: Record<string, unknown>; quantity: number; unitPrice: string | null;
  paymentMethod: string | null; transactionReference: string | null; receiptData?: string | null; receiptAvailable?: boolean;
  locationLat: number | null; locationLng: number | null;
  orderStatus: string; paymentStatus: string; customerNotes: string; adminNotes: string; adminPaymentFollowup: boolean;
  createdAt: string; updatedAt: string; customerName: string; customerPhone: string;
};
type AdminOrderRow = { order: OrderRecord; customerName: string; customerPhone: string };
type CustomerCredential = { code: string; token: string };
type OrderFormState = {
  printedName: string; productName: string; designDescription: string; quantity: string; notes: string;
  latitude: number | null; longitude: number | null; paymentMethod: string; transactionReference: string;
  customValues: Record<string, string>;
};
type AdminTab = "orders" | "catalog" | "settings" | "reports" | "security";
type ReportScope = "overall" | "category" | "designer";

const ORDER_STATUSES = ["جديد", "قيد المراجعة", "بانتظار الاتفاق", "قيد التجهيز", "جاهز", "تم التسليم", "مرفوض", "ملغى"];
const PAYMENT_STATUSES = ["غير مدفوع", "بانتظار الدفع", "بانتظار التحقق", "مدفوع ومؤكد", "مسترد"];
const PAYMENT_METHODS = ["بنكك", "فوري", "أوكاش"];
const DEFAULT_SETTINGS: CommerceSettings = {
  bankak: "1836656", fawry: "52151508", okash: "1604611",
  paymentInstructions: "وسائل الدفع اختيارية، ويمكن الاتفاق على تفاصيل الدفع مع الإدارة.",
  accountOwner: "محمد عثمان فضلون بابكر",
  whatsappUrl: "https://wa.me/249129834873",
  paymentImageUrl: "",
  contactName: "محمد عثمان فضلون",
  contactPhone: "0129834873",
  contactEmail: "mohammedfadlon885@gmail.com",
};
const EMPTY_FORM: OrderFormState = {
  printedName: "", productName: "", designDescription: "", quantity: "1", notes: "",
  latitude: null, longitude: null, paymentMethod: "", transactionReference: "", customValues: {},
};
const CATEGORY_ICONS: Record<string, string> = {
  "military-names": "✦", patches: "⬟", diaries: "▤", "armed-forces": "✪", other: "＋",
};
const DETAIL_LABELS: Record<string, string> = {
  designDescription: "الوصف",
  design: "التصميم", executionNotes: "ملاحظات التنفيذ",
};

function jsonFromStorage<T>(key: string, fallback: T): T {
  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) as T : fallback;
  } catch { return fallback; }
}

function formatDate(value: string | Date) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("ar", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function isForbiddenFieldLabel(value: string) {
  const normalized = value.normalize("NFKC").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[إأآ]/g, "ا").toLowerCase();
  return /(مقاس|لون|الوان|خامة|size|colou?r|material)/i.test(normalized);
}

function buildFieldEditor(fields: CustomField[] = []) {
  return fields.filter((field) => !isForbiddenFieldLabel(field.label) && !isForbiddenFieldLabel(field.key))
    .map((field) => [field.label, field.type, (field.options || []).join(","), field.required ? "مطلوب" : "اختياري"].join("|")).join("\n");
}

function parseFieldEditor(value: string, prefix: string): CustomField[] {
  return value.split("\n").map((line, index) => {
    const [labelValue = "", typeValue = "text", optionsValue = "", requiredValue = ""] = line.split("|");
    const label = labelValue.trim();
    const type = typeValue.trim() === "select" || typeValue.trim() === "textarea" ? typeValue.trim() as CustomField["type"] : "text";
    const options = optionsValue.split(",").map((option) => option.trim()).filter(Boolean).slice(0, 30);
    return { key: `${prefix}_${index + 1}`, label, type, required: requiredValue.includes("مطلوب"), ...(type === "select" ? { options } : {}) };
  }).filter((field) => field.label && !isForbiddenFieldLabel(field.label) && !isForbiddenFieldLabel(field.key) && (field.type !== "select" || (field.options?.length || 0) > 0));
}

function escapeCsv(value: unknown) {
  const text = value === null || value === undefined ? "" : typeof value === "string" ? value : String(value);
  return `"${text.replaceAll('"', '""')}"`;
}

function isForbiddenDimensionKey(key: string) {
  const normalized = key.normalize("NFKC").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[إأآ]/g, "ا").toLowerCase();
  return /(مقاس|لون|الوان|خامة|size|colou?r|material)/i.test(normalized);
}

function fieldLabel(key: string) {
  if (DETAIL_LABELS[key]) return DETAIL_LABELS[key];
  if (key.startsWith("حقل مخصص - ")) return key.replace("حقل مخصص - ", "");
  return key;
}

function isDesignerDetail(key: string) {
  if (isForbiddenDimensionKey(key)) return false;
  return ["designDescription", "design", "executionNotes"].includes(key) || key.startsWith("حقل مخصص - ");
}

function statusTone(status: string) {
  if (["تم التسليم", "جاهز", "مدفوع ومؤكد"].includes(status)) return "green";
  if (["بانتظار الدفع", "بانتظار التحقق", "بانتظار الاتفاق", "قيد التجهيز"].includes(status)) return "amber";
  if (["مرفوض", "ملغى"].includes(status)) return "red";
  return "";
}

function makeFormDetails(form: OrderFormState, fields: CustomField[]) {
  const details: Record<string, string> = {};
  if (form.designDescription.trim()) details.designDescription = form.designDescription.trim();
  for (const field of fields) {
    const value = form.customValues[field.key]?.trim();
    if (value) details[`حقل مخصص - ${field.label}`] = value;
  }
  return details;
}

async function readImage(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("اختر ملف صورة.");
  if (file.size > 1_000_000) throw new Error("يجب ألا يتجاوز حجم الصورة 1 ميغابايت.");
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("تعذر قراءة الصورة."));
    reader.onerror = () => reject(new Error("تعذر قراءة الصورة."));
    reader.readAsDataURL(file);
  });
}

/** Normalises a customer phone to an international number (Sudan default). Returns "" when it cannot be a mobile WhatsApp number. */
function customerIntlPhone(raw: string) {
  const digits = (raw || "").replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("00")) return digits.slice(2);
  if (digits.startsWith("249")) return digits;
  if (digits.startsWith("0") && digits.length === 10) return `249${digits.slice(1)}`;
  if (digits.length === 9 && /^[19]/.test(digits)) return `249${digits}`;
  return digits.length >= 10 && digits.length <= 15 ? digits : "";
}

function customerTelHref(raw: string) {
  const intl = customerIntlPhone(raw);
  return intl ? `tel:+${intl}` : `tel:${(raw || "").replace(/[^\d+]/g, "")}`;
}

function customerWhatsappHref(raw: string, order?: { orderCode?: string; categoryNameSnapshot?: string; productNameSnapshot?: string; customerName?: string }) {
  const intl = customerIntlPhone(raw);
  if (!intl) return "";
  const text = order?.orderCode ? [
    `السلام عليكم ${order.customerName || ""}`.trim() + "،",
    `بخصوص طلبك رقم ${order.orderCode} من أبو قمري للعلامات العسكرية`,
    order.categoryNameSnapshot ? `الصنف: ${order.categoryNameSnapshot}` : "",
    order.productNameSnapshot ? `الطلب: ${order.productNameSnapshot}` : "",
  ].filter(Boolean).join("\n") : "";
  return `https://wa.me/${intl}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}

function SectionHeading({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="section-heading"><div><h2 className="section-title">{title}</h2>{subtitle && <p className="section-subtitle">{subtitle}</p>}</div>{action}</div>;
}

export default function StoreApp() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<CommerceSettings>(DEFAULT_SETTINGS);
  const [brandLogo, setBrandLogo] = useState("");
  const [promo, setPromo] = useState<PromoBanner>(DEFAULT_PROMO);
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [catalogError, setCatalogError] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderOpen, setOrderOpen] = useState(false);
  const [form, setForm] = useState<OrderFormState>(EMPTY_FORM);
  const [receiptData, setReceiptData] = useState("");
  const [retryIdentity, setRetryIdentity] = useState<{ key: string; token: string } | null>(null);
  const [submittingOrder, setSubmittingOrder] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [profile, setProfile] = useState({ name: "", phone: "" });
  const [profileDraft, setProfileDraft] = useState({ name: "", phone: "" });
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileWasSaved, setProfileWasSaved] = useState(false);
  const [savedOrders, setSavedOrders] = useState<CustomerCredential[]>([]);
  const [trackOpen, setTrackOpen] = useState(false);
  const [trackingOrder, setTrackingOrder] = useState<OrderRecord | null>(null);
  const [trackingError, setTrackingError] = useState("");
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [successOrder, setSuccessOrder] = useState<{ code: string; category: string; product: string; token: string } | null>(null);
  const [toast, setToast] = useState("");
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);

  const [adminOpen, setAdminOpen] = useState(false);
  const [adminChecking, setAdminChecking] = useState(false);
  const [adminAuthed, setAdminAuthed] = useState(false);
  const [adminName, setAdminName] = useState("المسؤول");
  const [adminGate, setAdminGate] = useState<{ setupRequired: boolean; passkeyLoginAvailable: boolean } | null>(null);
  const [identityChecking, setIdentityChecking] = useState(false);
  const [adminTab, setAdminTab] = useState<AdminTab>("orders");
  const [adminOrders, setAdminOrders] = useState<AdminOrderRow[]>([]);
  const [adminOrdersLoading, setAdminOrdersLoading] = useState(false);
  const [adminFilters, setAdminFilters] = useState({ q: "", category: "", orderStatus: "", paymentStatus: "", from: "", to: "" });
  const [adminSelectedOrder, setAdminSelectedOrder] = useState<OrderRecord | null>(null);
  const [contactSheet, setContactSheet] = useState<{ phone: string; name: string; order?: OrderRecord } | null>(null);
  const [adminDetailLoading, setAdminDetailLoading] = useState(false);
  const [adminSaveBusy, setAdminSaveBusy] = useState(false);
  const [adminDraft, setAdminDraft] = useState({ orderStatus: "جديد", paymentStatus: "غير مدفوع", adminNotes: "" });
  const [adminCatalogLoading, setAdminCatalogLoading] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryDraft, setCategoryDraft] = useState({ name: "", slug: "", description: "", sortOrder: "10", visible: true, customFieldsText: "" });
  const [catalogSaveBusy, setCatalogSaveBusy] = useState(false);
  const [adminSettingsDraft, setAdminSettingsDraft] = useState<CommerceSettings>(DEFAULT_SETTINGS);
  const [settingsSaveBusy, setSettingsSaveBusy] = useState(false);
  const [reportScope, setReportScope] = useState<ReportScope>("overall");
  const [reportCategoryId, setReportCategoryId] = useState("");
  const [reportFilters, setReportFilters] = useState({ q: "", orderStatus: "", paymentStatus: "", from: "", to: "" });
  const [reportRows, setReportRows] = useState<AdminOrderRow[]>([]);
  const [reportLoading, setReportLoading] = useState(false);
  const [reportBusy, setReportBusy] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);
  const retryLock = useRef(false);
  const activeCategory = categories.find((category) => category.id === selectedCategoryId) || null;
  const customFields = useMemo(() => [...(activeCategory?.customFields || []), ...(selectedProduct?.customFields || [])], [activeCategory, selectedProduct]);
  const reportVisibleRows = useMemo(() => reportRows.filter((row) => {
    if (reportScope === "overall") {
      const category = categories.find((item) => item.id === row.order.categoryId);
      if (category?.includeInOverall === false || category?.slug === "other") return false;
    }
    if (reportScope === "category" && (!reportCategoryId || String(row.order.categoryId) !== reportCategoryId)) return false;
    if (reportScope === "designer" && reportCategoryId && String(row.order.categoryId) !== reportCategoryId) return false;
    return true;
  }), [categories, reportRows, reportScope, reportCategoryId]);
  const adminPendingPaymentCount = useMemo(() => adminOrders.filter((row) => row.order.adminPaymentFollowup && row.order.paymentStatus !== "مدفوع ومؤكد").length, [adminOrders]);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3400);
  }, []);

  const loadCatalog = useCallback(async () => {
    setCatalogLoading(true);
    setCatalogError("");
    try {
      const response = await fetch("/api/catalog", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل الأصناف.");
      setCategories(data.categories || []);
      setProducts(data.products || []);
      setSettings({ ...DEFAULT_SETTINGS, ...(data.settings || {}) });
      setBrandLogo(typeof data.brandLogoUrl === "string" ? data.brandLogoUrl : "");
      if (data.promo) setPromo({ ...DEFAULT_PROMO, ...data.promo });
    } catch (error) {
      setCatalogError(error instanceof Error ? error.message : "تعذر الاتصال بالخادم.");
    } finally { setCatalogLoading(false); }
  }, []);

  useEffect(() => {
    void loadCatalog();
    const storedProfile = jsonFromStorage<{ name?: string; phone?: string } | null>("abuqomari-profile", null);
    if (storedProfile?.name && storedProfile.phone) {
      const restored = { name: storedProfile.name, phone: storedProfile.phone };
      setProfile(restored);
      setProfileDraft(restored);
      setProfileWasSaved(true);
      fetch("/api/admin/identify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(restored) })
        .then((response) => response.json())
        .then((data) => { if (data?.isAdmin) setAdminGate({ setupRequired: Boolean(data.setupRequired), passkeyLoginAvailable: Boolean(data.passkeyLoginAvailable) }); })
        .catch(() => undefined);
    } else {
      setProfileOpen(true);
    }
    const orders = jsonFromStorage<CustomerCredential[]>("abuqomari-my-orders", []);
    setSavedOrders(Array.isArray(orders) ? orders : []);
    if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    const installHandler = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", installHandler);
    return () => window.removeEventListener("beforeinstallprompt", installHandler);
  }, [loadCatalog]);

  useEffect(() => {
    if (!orderOpen || !activeCategory) return;
    const draft = { categoryId: activeCategory.id, productId: selectedProduct?.id ?? null, form, receiptData, retryIdentity };
    try { localStorage.setItem("abuqomari-order-draft", JSON.stringify(draft)); } catch { /* Device storage may be unavailable. */ }
  }, [activeCategory, form, orderOpen, receiptData, retryIdentity, selectedProduct]);

  useEffect(() => {
    if (!adminOpen) return;
    let cancelled = false;
    setAdminChecking(true);
    fetch("/api/admin/session", { cache: "no-store" }).then((response) => response.json()).then((data) => {
      if (!cancelled) {
        setAdminAuthed(Boolean(data.authenticated));
        if (data.admin?.name) setAdminName(data.admin.name);
      }
    }).catch(() => { if (!cancelled) setAdminAuthed(false); }).finally(() => { if (!cancelled) setAdminChecking(false); });
    return () => { cancelled = true; };
  }, [adminOpen]);

  const loadAdminCatalog = useCallback(async () => {
    setAdminCatalogLoading(true);
    try {
      const response = await fetch("/api/admin/catalog", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل بيانات الإدارة.");
      setCategories(data.categories || []);
      setProducts(data.products || []);
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تحميل الأصناف."); }
    finally { setAdminCatalogLoading(false); }
  }, [showToast]);

  const queryForOrders = useCallback((filters: typeof adminFilters, limit = 1000, offset = 0) => {
    const params = new URLSearchParams({ limit: String(limit), offset: String(offset) });
    for (const [key, value] of Object.entries(filters)) {
      if (value) params.set(key, value);
    }
    return params.toString();
  }, []);

  const loadAdminOrders = useCallback(async (filters = adminFilters) => {
    setAdminOrdersLoading(true);
    try {
      const response = await fetch(`/api/admin/orders?${queryForOrders(filters, 5000)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل الطلبات.");
      setAdminOrders(data.orders || []);
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تحميل الطلبات."); }
    finally { setAdminOrdersLoading(false); }
  }, [adminFilters, queryForOrders, showToast]);

  useEffect(() => {
    if (!adminOpen || !adminAuthed) return;
    if (adminTab === "orders") {
      const timer = window.setTimeout(() => void loadAdminOrders(), 180);
      return () => window.clearTimeout(timer);
    }
    if (adminTab === "catalog") void loadAdminCatalog();
    if (adminTab === "settings") {
      fetch("/api/admin/settings", { cache: "no-store" }).then((response) => response.json()).then((data) => {
        if (data.settings) setAdminSettingsDraft({ ...DEFAULT_SETTINGS, ...data.settings });
      }).catch(() => showToast("تعذر تحميل إعدادات الدفع."));
    }
  }, [adminAuthed, adminOpen, adminTab, adminFilters, loadAdminCatalog, loadAdminOrders, showToast]);

  useEffect(() => {
    if (!adminOpen || !adminAuthed || adminTab !== "reports") return;
    const timer = window.setTimeout(async () => {
      setReportLoading(true);
      try {
        const filters = {
          q: reportFilters.q, category: reportCategoryId, orderStatus: reportFilters.orderStatus,
          paymentStatus: reportFilters.paymentStatus, from: reportFilters.from, to: reportFilters.to,
        };
        const allRows: AdminOrderRow[] = [];
        let offset = 0;
        while (true) {
          const response = await fetch(`/api/admin/orders?${queryForOrders(filters, 5000, offset)}`, { cache: "no-store" });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "تعذر تحميل التقرير.");
          const page = (data.orders || []) as AdminOrderRow[];
          allRows.push(...page);
          if (!page.length || data.nextOffset === null || data.nextOffset === undefined) break;
          offset = Number(data.nextOffset);
        }
        setReportRows(allRows);
      } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تحميل التقرير."); }
      finally { setReportLoading(false); }
    }, 180);
    return () => window.clearTimeout(timer);
  }, [adminAuthed, adminOpen, adminTab, reportCategoryId, reportFilters, queryForOrders, showToast]);

  function closeAdmin() { setAdminOpen(false); setAdminTab("orders"); setAdminSelectedOrder(null); }

  async function signOutAdmin() {
    await fetch("/api/admin/logout", { method: "POST" }).catch(() => undefined);
    setAdminAuthed(false);
    setAdminSelectedOrder(null);
    setAdminOpen(false);
  }

  function openProfile() {
    setProfileDraft(profile);
    setProfileOpen(true);
  }

  function saveProfile(event: FormEvent) {
    event.preventDefault();
    if (!profileDraft.name.trim() || profileDraft.phone.replace(/[^0-9]/g, "").length < 6) {
      showToast("أدخل الاسم ورقم هاتف صحيحًا.");
      return;
    }
    const clean = { name: profileDraft.name.trim().slice(0, 120), phone: profileDraft.phone.trim().slice(0, 40) };
    setProfile(clean);
    setProfileDraft(clean);
    setProfileWasSaved(true);
    setProfileOpen(false);
    try { localStorage.setItem("abuqomari-profile", JSON.stringify(clean)); } catch { showToast("تعذر حفظ البيانات على هذا الجهاز."); }
    void identifyOwner(clean);
  }

  async function identifyOwner(person: { name: string; phone: string }) {
    setIdentityChecking(true);
    try {
      const response = await fetch("/api/admin/identify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(person) });
      const data = await response.json();
      if (!response.ok || !data.isAdmin) return;
      const session = await fetch("/api/admin/session", { cache: "no-store" }).then((result) => result.json()).catch(() => ({}));
      setAdminGate({ setupRequired: Boolean(data.setupRequired), passkeyLoginAvailable: Boolean(data.passkeyLoginAvailable) });
      setAdminAuthed(Boolean(session.authenticated));
      if (session.admin?.name) setAdminName(session.admin.name);
      setAdminOpen(true);
    } catch { /* Network failure: stay in the customer view. */ }
    finally { setIdentityChecking(false); }
  }

  function openOrder(category: Category, product: Product | null = null) {
    if (category.archived || !category.visible) return;
    setSelectedCategoryId(category.id);
    setSelectedProduct(product);
    setReceiptData("");
    setRetryIdentity(null);
    setLocationError("");
    setLocationLoading(true);
    setForm({ ...EMPTY_FORM, productName: product?.name || "" });
    try {
      const draft = jsonFromStorage<{ categoryId?: number; productId?: number | null; form?: OrderFormState; receiptData?: string; retryIdentity?: { key: string; token: string } } | null>("abuqomari-order-draft", null);
      if (draft && draft.categoryId === category.id && (draft.productId ?? null) === (product?.id ?? null)) {
        if (draft.form) setForm({ ...EMPTY_FORM, ...draft.form });
        setReceiptData(draft.receiptData || "");
        setRetryIdentity(draft.retryIdentity || null);
      }
    } catch { /* Start with a fresh form if local storage is unavailable. */ }
    updateForm("latitude", null);
    updateForm("longitude", null);
    setOrderOpen(true);
    void locateBuyer();
  }

  function updateForm<K extends keyof OrderFormState>(key: K, value: OrderFormState[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function saveMyOrder(record: CustomerCredential) {
    const next = [record, ...savedOrders.filter((item) => item.code !== record.code)].slice(0, 20);
    setSavedOrders(next);
    try { localStorage.setItem("abuqomari-my-orders", JSON.stringify(next)); } catch { /* The server record is still safely saved. */ }
  }

  async function placeOrder(event: FormEvent) {
    event.preventDefault();
    if (retryLock.current || submittingOrder) return;
    if (!profile.name.trim() || profile.phone.replace(/[^0-9]/g, "").length < 6) {
      setProfileDraft(profile);
      setProfileOpen(true);
      showToast("أدخل اسمك ورقم هاتفك للمتابعة.");
      return;
    }
    if (!activeCategory) return;
    if (form.latitude === null || form.longitude === null) {
      const message = locationError || "جارٍ تحديد GPS. أكمِل تحديد الموقع قبل إرسال الطلب.";
      showToast(message);
      if (!locationLoading) void locateBuyer();
      return;
    }
    if (activeCategory.slug === "military-names" && !form.printedName.trim()) {
      showToast("اكتب الاسم المطلوب طباعته حرفيًا.");
      return;
    }
    if (!form.designDescription.trim()) {
      showToast("اكتب وصف الطلب.");
      return;
    }
    const requiredMissing = customFields.find((field) => field.required && !form.customValues[field.key]?.trim());
    if (requiredMissing) { showToast(`يرجى تعبئة: ${requiredMissing.label}`); return; }
    const quantity = Number(form.quantity);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10000) { showToast("أدخل كمية صحيحة."); return; }

    const identity = retryIdentity || { key: crypto.randomUUID(), token: `${crypto.randomUUID()}${crypto.randomUUID()}` };
    setRetryIdentity(identity);
    retryLock.current = true;
    setSubmittingOrder(true);
    const details = makeFormDetails(form, customFields);
    try {
      localStorage.setItem("abuqomari-order-draft", JSON.stringify({ categoryId: activeCategory.id, productId: selectedProduct?.id ?? null, form, receiptData, retryIdentity: identity }));
    } catch { /* A fresh network request can still continue. */ }
    try {
      const response = await fetch("/api/orders", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          idempotencyKey: identity.key, accessToken: identity.token, customerName: profile.name, customerPhone: profile.phone,
          categoryId: activeCategory.id, productId: selectedProduct?.id ?? null,
          productName: form.productName || selectedProduct?.name || "", printedName: form.printedName,
          quantity, details, customerNotes: form.notes,
          locationLat: form.latitude, locationLng: form.longitude,
          paymentMethod: activeCategory.slug === "military-names" ? form.paymentMethod : "",
          transactionReference: activeCategory.slug === "military-names" ? form.transactionReference : "",
          receiptData: activeCategory.slug === "military-names" ? receiptData : null,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "لم يصل الطلب إلى الإدارة.");
      const credential = { code: data.orderCode as string, token: data.accessToken as string };
      saveMyOrder(credential);
      try { localStorage.removeItem("abuqomari-order-draft"); } catch { /* Ignore local-storage errors. */ }
      setSuccessOrder({ code: credential.code, category: activeCategory.name, product: selectedProduct?.name || form.productName || activeCategory.name, token: credential.token });
      setOrderOpen(false);
      setTrackingOrder(null);
      showToast("تم حفظ الطلب لدى الإدارة.");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "تعذر إرسال الطلب. أعد المحاولة.");
    } finally {
      retryLock.current = false;
      setSubmittingOrder(false);
    }
  }

  async function loadTrackingOrder(credential: CustomerCredential) {
    setTrackingLoading(true);
    setTrackingError("");
    setTrackingOrder(null);
    try {
      const response = await fetch(`/api/orders/${encodeURIComponent(credential.code)}?token=${encodeURIComponent(credential.token)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر العثور على الطلب.");
      setTrackingOrder(data.order);
    } catch (error) { setTrackingError(error instanceof Error ? error.message : "تعذر تحميل حالة الطلب."); }
    finally { setTrackingLoading(false); }
  }

  function openSavedOrder(credential: CustomerCredential) {
    setTrackOpen(true);
    void loadTrackingOrder(credential);
  }

  function whatsappLink(order?: Partial<OrderRecord> & { customerName?: string; categoryNameSnapshot?: string; productNameSnapshot?: string }) {
    const base = (settings.whatsappUrl || DEFAULT_SETTINGS.whatsappUrl).replace(/\/$/, "");
    if (!order?.orderCode) return base;
    const summary = [
      `السلام عليكم، أستفسر عن طلبي رقم ${order.orderCode}`,
      order.customerName || profile.name ? `الزبون: ${order.customerName || profile.name}` : "",
      order.categoryNameSnapshot ? `الصنف: ${order.categoryNameSnapshot}` : "",
      order.productNameSnapshot ? `ملخص الطلب: ${order.productNameSnapshot}` : "",
    ].filter(Boolean).join("\n");
    return `${base}?text=${encodeURIComponent(summary)}`;
  }

  function openWhatsapp(order?: Partial<OrderRecord> & { customerName?: string; categoryNameSnapshot?: string; productNameSnapshot?: string }) {
    window.open(whatsappLink(order), "_blank", "noopener,noreferrer");
  }

  async function copyValue(value: string, label: string) {
    try {
      await navigator.clipboard.writeText(value);
      showToast(`تم نسخ ${label}.`);
    } catch { showToast("تعذر النسخ تلقائيًا؛ اضغط مطولًا على الرقم لنسخه."); }
  }

  function chooseCategory(category: Category) {
    setSelectedCategoryId(category.id);
    setTimeout(() => document.getElementById("category-products")?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  }

  async function locateBuyer() {
    setLocationError("");
    setLocationLoading(true);
    if (!navigator.geolocation) {
      const message = "خدمة تحديد GPS غير مدعومة على هذا الجهاز أو تحتاج اتصالًا آمنًا HTTPS.";
      setLocationError(message);
      setLocationLoading(false);
      showToast(message);
      return;
    }
    navigator.geolocation.getCurrentPosition((position) => {
      updateForm("latitude", position.coords.latitude);
      updateForm("longitude", position.coords.longitude);
      setLocationError("");
      setLocationLoading(false);
      showToast("تم تحديد الموقع عبر GPS وربطه بالطلب.");
    }, (error) => {
      const message = error.code === error.PERMISSION_DENIED
        ? "يلزم السماح بإذن الموقع لتحديد GPS وإرسال الطلب. فعّل الإذن ثم أعد المحاولة."
        : "تعذر تحديد GPS. تحقق من تشغيل خدمات الموقع ثم أعد المحاولة.";
      setLocationError(message);
      setLocationLoading(false);
      showToast(message);
    }, { enableHighAccuracy: true, timeout: 25000, maximumAge: 0 });
  }

  async function openAdminOrder(row: AdminOrderRow) {
    setAdminDetailLoading(true);
    try {
      const response = await fetch(`/api/admin/orders/${row.order.id}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل تفاصيل الطلب.");
      setAdminSelectedOrder(data.order);
      setAdminDraft({ orderStatus: data.order.orderStatus, paymentStatus: data.order.paymentStatus, adminNotes: data.order.adminNotes || "" });
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تحميل تفاصيل الطلب."); }
    finally { setAdminDetailLoading(false); }
  }

  async function saveAdminOrder(event: FormEvent) {
    event.preventDefault();
    if (!adminSelectedOrder) return;
    setAdminSaveBusy(true);
    try {
      const response = await fetch("/api/admin/orders", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: adminSelectedOrder.id, ...adminDraft }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر حفظ الطلب.");
      setAdminSelectedOrder({ ...adminSelectedOrder, ...adminDraft, updatedAt: new Date().toISOString() });
      showToast("تم حفظ حالة الطلب والدفع كلٌّ على حدة.");
      await loadAdminOrders();
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ التغييرات."); }
    finally { setAdminSaveBusy(false); }
  }

  function openCategoryEditor(category?: Category) {
    setEditingCategory(category || null);
    setCategoryDraft(category ? {
      name: category.name, slug: category.slug, description: category.description || "", sortOrder: String(category.sortOrder),
      visible: category.visible, customFieldsText: buildFieldEditor(category.customFields),
    } : { name: "", slug: "", description: "", sortOrder: String(categories.length + 1), visible: true, customFieldsText: "" });
    setShowCategoryForm(true);
  }

  async function saveCategory(event: FormEvent) {
    event.preventDefault();
    const payload = {
      name: categoryDraft.name, slug: categoryDraft.slug, description: categoryDraft.description,
      sortOrder: Number(categoryDraft.sortOrder) || 0, visible: categoryDraft.visible,
      customFields: parseFieldEditor(categoryDraft.customFieldsText, "category_field"),
    };
    setCatalogSaveBusy(true);
    try {
      const response = await fetch(editingCategory ? `/api/admin/catalog/${editingCategory.id}` : "/api/admin/catalog", {
        method: editingCategory ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر حفظ الصنف.");
      setShowCategoryForm(false);
      await loadAdminCatalog();
      showToast("تم حفظ الصنف والحقول المخصصة.");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ الصنف."); }
    finally { setCatalogSaveBusy(false); }
  }

  async function archiveCategory(category: Category) {
    const nextArchived = !category.archived;
    try {
      const response = nextArchived
        ? await fetch(`/api/admin/catalog/${category.id}`, { method: "DELETE" })
        : await fetch(`/api/admin/catalog/${category.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ archived: false, visible: true }) });
      if (!response.ok) throw new Error("تعذر أرشفة الصنف.");
      await loadAdminCatalog();
      showToast(nextArchived ? "أُرشف الصنف مع الاحتفاظ بسجلاته." : "أُعيد إظهار الصنف.");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر تحديث الصنف."); }
  }

  async function changeCategory(category: Category, changes: Record<string, unknown>) {
    const response = await fetch(`/api/admin/catalog/${category.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(changes) });
    if (!response.ok) throw new Error("تعذر تحديث الصنف.");
    await loadAdminCatalog();
  }

  async function saveAdminSettings(event: FormEvent) {
    event.preventDefault();
    setSettingsSaveBusy(true);
    try {
      const response = await fetch("/api/admin/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(adminSettingsDraft) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر حفظ الإعدادات.");
      setAdminSettingsDraft({ ...DEFAULT_SETTINGS, ...data.settings });
      setSettings({ ...DEFAULT_SETTINGS, ...data.settings });
      showToast("تم حفظ أرقام الدفع ورابط واتساب.");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر حفظ الإعدادات."); }
    finally { setSettingsSaveBusy(false); }
  }

  async function exportReport(share: boolean) {
    if (!reportRef.current) { showToast("تعذر العثور على التقرير لإنشائه."); return; }
    setReportBusy(true);
    try {
      const blob = await createArabicReportPdf(reportRef.current);
      const fileName = `abu-qomari-report-${new Date().toISOString().slice(0, 10)}.pdf`;
      const file = new File([blob], fileName, { type: "application/pdf" });
      if (share) {
        const result = await shareReportFile(file);
        if (result === "shared") showToast("تم فتح قائمة مشاركة الملف.");
        else if (result === "cancelled") showToast("أُلغيت المشاركة؛ لم يُرسل الملف.");
        else {
          downloadBlob(blob, fileName);
          showToast("تعذرت المشاركة المباشرة؛ بدأ تنزيل ملف PDF للمشاركة يدويًا.");
        }
      } else {
        downloadBlob(blob, fileName);
        showToast("تم إنشاء ملف PDF وبدأ تنزيله.");
      }
    } catch (error) {
      console.error("PDF export failed", error);
      showToast("تعذر إنشاء PDF الآن. أعد المحاولة بعد تحميل التقرير بالكامل.");
    } finally { setReportBusy(false); }
  }

  function exportCsv() {
    const header = ["رقم الطلب", "التاريخ", "الزبون", "الهاتف", "الصنف", "الطلب", "الاسم المطلوب طباعته", "المواصفات", "الكمية", "حالة الطلب", "حالة الدفع", "وسيلة الدفع", "رقم العملية", "ملاحظات الزبون"];
    const lines = reportVisibleRows.map(({ order, customerName, customerPhone }) => [
      order.orderCode, formatDate(order.createdAt), customerName, customerPhone, order.categoryNameSnapshot,
      order.productNameSnapshot, order.printedName || "", Object.entries(order.details || {}).filter(([key]) => !isForbiddenDimensionKey(key)).map(([key, value]) => `${fieldLabel(key)}: ${String(value)}`).join(" | "),
      order.quantity, order.orderStatus, order.paymentStatus, order.paymentMethod || "", order.transactionReference || "", order.customerNotes,
    ].map(escapeCsv).join(","));
    const blob = new Blob([`\uFEFF${[header.map(escapeCsv).join(","), ...lines].join("\r\n")}`], { type: "text/csv;charset=utf-8" });
    downloadBlob(blob, `abu-qomari-report-${new Date().toISOString().slice(0, 10)}.csv`);
    showToast("تم إنشاء CSV وبدأ تنزيله.");
  }

  async function exportBackup() {
    try {
      const response = await fetch("/api/admin/export", { cache: "no-store" });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || "تعذر إنشاء النسخة الاحتياطية.");
      }
      const blob = await response.blob();
      downloadBlob(blob, `abu-qomari-backup-${new Date().toISOString().slice(0, 10)}.json`);
      showToast("تم إنشاء نسخة JSON الاحتياطية وبدأ تنزيلها. احفظها في مكان آمن.");
    } catch (error) { showToast(error instanceof Error ? error.message : "تعذر إنشاء النسخة الاحتياطية."); }
  }

  const reportTitle = reportScope === "overall" ? "التقرير الكلي للطلبات" : reportScope === "category" ? `تقرير الصنف: ${categories.find((item) => String(item.id) === reportCategoryId)?.name || "اختر صنفًا"}` : "تقرير المصمم – جميع الطلبات";
  const reportHeading = reportScope === "designer" ? "تقرير المصمم – جميع الطلبات" : reportTitle;

  function renderReportCard(row: AdminOrderRow, index: number, designerOnly: boolean) {
    const order = row.order;
    const detailsEntries = Object.entries(order.details || {}).filter(([key, value]) =>
      value !== "" && value !== null && value !== undefined && !isForbiddenDimensionKey(key) && (!designerOnly || isDesignerDetail(key))
    );
    return <article className="report-card" data-pdf-block key={`${order.id}-${index}`}>
      <div className="report-card-title"><div><h3>{designerOnly ? `الطلب رقم ${index + 1}` : `${order.categoryNameSnapshot} · ${order.productNameSnapshot}`}</h3><small className="helper">{formatDate(order.createdAt)}</small></div><span>{order.orderCode}</span></div>
      {designerOnly ? <>
        <div className="definition-grid">
          <div className="definition"><strong>الصنف</strong><span>{order.categoryNameSnapshot} · {order.productNameSnapshot}</span></div>
          {order.printedName && <div className="definition"><strong>الاسم المطلوب طباعته حرفيًا</strong><span>{order.printedName}</span></div>}
          {detailsEntries.map(([key, value]) => <div className="definition" key={key}><strong>{fieldLabel(key)}</strong><span>{String(value)}</span></div>)}
          <div className="definition"><strong>الكمية</strong><span>{order.quantity}</span></div>
          {order.customerNotes && <div className="definition"><strong>ملاحظات التنفيذ</strong><span>{order.customerNotes}</span></div>}
        </div>
      </> : <>
        <div className="definition-grid">
          <div className="definition"><strong>الزبون</strong><span>{row.customerName}</span></div>
          <div className="definition"><strong>رقم الهاتف</strong><span dir="ltr">{row.customerPhone}</span></div>
          <div className="definition"><strong>الصنف</strong><span>{order.categoryNameSnapshot} · {order.productNameSnapshot}</span></div>
          {order.printedName && <div className="definition"><strong>الاسم المطلوب طباعته</strong><span>{order.printedName}</span></div>}
          {detailsEntries.map(([key, value]) => <div className="definition" key={key}><strong>{fieldLabel(key)}</strong><span>{String(value)}</span></div>)}
          <div className="definition"><strong>الكمية</strong><span>{order.quantity}</span></div>
          <div className="definition"><strong>حالة الطلب</strong><span>{order.orderStatus}</span></div>
          <div className="definition"><strong>حالة الدفع</strong><span>{order.paymentStatus}</span></div>
          {order.paymentMethod && <div className="definition"><strong>وسيلة الدفع</strong><span>{order.paymentMethod}</span></div>}
          {order.transactionReference && <div className="definition"><strong>رقم العملية</strong><span>{order.transactionReference}</span></div>}
          {order.unitPrice && <div className="definition"><strong>سعر الوحدة</strong><span>{order.unitPrice}</span></div>}
          {order.customerNotes && <div className="definition"><strong>ملاحظات الزبون</strong><span>{order.customerNotes}</span></div>}
          {order.adminNotes && <div className="definition"><strong>ملاحظات الإدارة</strong><span>{order.adminNotes}</span></div>}
          {order.receiptAvailable && <div className="definition"><strong>الإيصال</strong><span>إيصال مرفق، بانتظار التحقق اليدوي</span></div>}
        </div>
      </>}
    </article>;
  }

  const renderReportActions = () => <div className="report-actions">
    <button className="btn btn-primary" type="button" disabled={reportBusy || reportLoading} onClick={() => void exportReport(false)}>{reportBusy ? <><span className="spinner" /> جارٍ إنشاء PDF</> : "⬇ حفظ التقرير PDF"}</button>
    <button className="btn btn-secondary" type="button" disabled={reportBusy || reportLoading} onClick={() => void exportReport(true)}>↗ مشاركة التقرير</button>
    <button className="btn btn-secondary" type="button" disabled={reportLoading} onClick={exportCsv}>⇩ تصدير CSV</button>
  </div>;

  const publicCategories = categories.filter((category) => category.visible && !category.archived).sort((a, b) => a.sortOrder - b.sortOrder);

  return <div className="app-shell">
    <header className="topbar">
      <div className="topbar-inner">
        <a className="brand" href="#home" aria-label="أبو قمري للعلامات العسكرية - الرئيسية">
          {brandLogo ? <img className="brand-logo" src={brandLogo} alt="شعار أبو قمري للعلامات العسكرية" width={46} height={46} /> : <span className="brand-mark">أ</span>}<span><strong className="brand-title">أبو قمري للعلامات العسكرية</strong><small className="brand-caption">طلبات واضحة… وتواصل مباشر</small></span>
        </a>
        <div className="top-actions">
          {installPrompt && <button className="btn btn-secondary btn-small" type="button" onClick={async () => { await installPrompt.prompt(); setInstallPrompt(null); }}>＋ تثبيت</button>}
          <button className="icon-button" type="button" title="بياناتي" aria-label="بياناتي" onClick={openProfile}>♙</button>
          <button className="btn btn-secondary btn-small" type="button" onClick={() => setTrackOpen(true)}>طلباتي</button>
          {adminGate && !adminOpen && <button className="icon-button" type="button" title="لوحة الإدارة" aria-label="لوحة الإدارة" onClick={() => void identifyOwner(profile)}>⚙</button>}
        </div>
      </div>
    </header>

    {!adminOpen ? <>
      <main id="home" className="page-container">
        {catalogError && <div className="notice warning" style={{ marginTop: 15 }}><strong>تعذر الاتصال بالخادم.</strong> {catalogError} <button className="btn-link" type="button" onClick={() => void loadCatalog()}>إعادة المحاولة</button></div>}
        <PromoBannerView banner={promo} onWhatsapp={() => openWhatsapp()} />

        {!profileWasSaved && <div className="notice info" style={{ marginBottom: 20 }}>
          أضف اسمك ورقم هاتفك مرة واحدة لتسهيل تعبئة الطلبات على هذا الجهاز. <button type="button" className="btn-link" onClick={openProfile}>إضافة بياناتي</button>
        </div>}

        <section id="categories" className="section">
          <SectionHeading title="تصفّح الأصناف" subtitle="اختر الصنف ثم اكتب الوصف والكمية لإرسال طلبك." action={catalogLoading ? <span className="helper">جارٍ التحديث…</span> : undefined} />
          {catalogLoading && categories.length === 0 ? <div className="category-grid">{Array.from({ length: 5 }, (_, index) => <div key={index} className="category-card" style={{ opacity: .5 }}><span className="category-icon">◌</span><span className="category-name">جارٍ التحميل</span></div>)}</div> : publicCategories.length ? <div className="category-grid">
            {publicCategories.map((category) => <button type="button" key={category.id} className={`category-card ${selectedCategoryId === category.id ? "active" : ""}`} onClick={() => chooseCategory(category)}>
              <span className="category-icon">{CATEGORY_ICONS[category.slug] || "✦"}</span>
              <span className="category-name">{category.name}</span>
              <span className="category-count">{category.description || "اطلب بالوصف والكمية"}</span>
              <span className="category-arrow">←</span>
            </button>)}
          </div> : <div className="empty-state"><div className="empty-icon">▤</div><h3>تعذر تحميل الأصناف</h3><p>تحقق من الإنترنت ثم أعد المحاولة.</p><button className="btn btn-secondary" onClick={() => void loadCatalog()}>إعادة المحاولة</button></div>}
        </section>

        {activeCategory && <section id="category-products" className="section">
          <SectionHeading title={activeCategory.name} subtitle={activeCategory.description || "اكتب وصف طلبك والكمية وأرسله للإدارة."} action={<button className="btn-link" type="button" onClick={() => setSelectedCategoryId(null)}>إغلاق ×</button>} />
          <div className="empty-state"><div className="empty-icon">{CATEGORY_ICONS[activeCategory.slug] || "✦"}</div><h3>{activeCategory.slug === "military-names" ? "اكتب الاسم المطلوب والوصف والكمية" : "اكتب الوصف والكمية"}</h3><p>{activeCategory.slug === "military-names" ? "اكتب الاسم حرفيًا كما تريد طباعته، ثم الوصف والكمية." : "صف ما تريد تنفيذه بالتفصيل وحدد الكمية، وسيصل طلبك إلى الإدارة مباشرة."}</p><button className="btn btn-primary" type="button" onClick={() => openOrder(activeCategory)}>اطلب الآن</button></div>
        </section>}

        <section className="info-strip" aria-label="معلومات الخدمة">
          <div className="info-item"><span className="info-icon">⌖</span><div><strong>موقعك اختياري</strong><span>أرسله فقط بموافقتك</span></div></div>
          <div className="info-item"><span className="info-icon">✓</span><div><strong>اطلب دون دفع إلكتروني</strong><span>اتفق مع الإدارة على التفاصيل</span></div></div>
          <div className="info-item"><span className="info-icon">◉</span><div><strong>تواصل مباشر</strong><span>واتساب الإدارة الرسمي</span></div></div>
        </section>
      </main>
      <footer className="footer"><div className="footer-inner"><span>© أبو قمري للعلامات العسكرية</span><span>{settings.contactName} · <span dir="ltr">{settings.contactPhone}</span> · <span dir="ltr">{settings.contactEmail}</span></span><a href={settings.whatsappUrl || DEFAULT_SETTINGS.whatsappUrl} target="_blank" rel="noreferrer">تواصل معنا عبر واتساب</a></div></footer>
    </> : <>
      <main className="page-container admin-wrap">
        {adminChecking ? <div className="empty-state"><span className="spinner" style={{ color: "var(--red)" }} /><p>جارٍ التحقق من جلسة الإدارة…</p></div> : !adminAuthed ? <AdminAuth identity={profile} setupRequired={Boolean(adminGate?.setupRequired)} passkeyLoginAvailable={Boolean(adminGate?.passkeyLoginAvailable)} logoUrl={brandLogo} onAuthenticated={(admin) => { if (admin.name) setAdminName(admin.name); setAdminAuthed(true); setAdminGate((gate) => gate ? { ...gate, setupRequired: false } : gate); }} onClose={closeAdmin} /> : <>
          <div className="admin-header"><div><h1>لوحة الإدارة</h1><p>مرحبًا، {adminName} · إدارة الطلبات والكتالوج</p></div><div className="top-actions"><button className="btn btn-secondary btn-small" type="button" onClick={() => void loadAdminOrders()}>↻ تحديث</button><button className="btn btn-secondary btn-small" type="button" onClick={closeAdmin}>العودة للمتجر</button><button className="btn btn-danger btn-small" type="button" onClick={() => void signOutAdmin()}>خروج</button></div></div>
          <nav className="admin-tabs" aria-label="أقسام الإدارة">
            {([["orders", "الطلبات"], ["catalog", "الأصناف"], ["settings", "الإعدادات"], ["reports", "التقارير"], ["security", "الإعدادات والخصوصية"]] as [AdminTab, string][]).map(([tab, title]) => <button key={tab} type="button" className={`admin-tab ${adminTab === tab ? "active" : ""}`} onClick={() => setAdminTab(tab)}>{title}{tab === "orders" && adminPendingPaymentCount > 0 ? ` · ${adminPendingPaymentCount}` : ""}</button>)}
          </nav>

          {adminTab === "orders" && <section className="admin-panel">
            {adminPendingPaymentCount > 0 && <div className="notice warning admin-alert"><strong>متابعة الدفع المقدم:</strong> {adminPendingPaymentCount} طلبًا من الأسماء العسكرية بانتظار المتابعة. الطلبات وصلت دون اشتراط الدفع.</div>}
            <div className="admin-toolbar"><h2>جميع الطلبات <span className="helper">({adminOrders.length})</span></h2><span className="helper">تحديث الحالات منفصل عن حالة الدفع</span></div>
            <div className="admin-tools">
              <input className="input search-field" placeholder="بحث برقم الطلب أو الاسم أو الهاتف" value={adminFilters.q} onChange={(event) => setAdminFilters((value) => ({ ...value, q: event.target.value }))} />
              <select className="select" value={adminFilters.category} onChange={(event) => setAdminFilters((value) => ({ ...value, category: event.target.value }))}><option value="">كل الأصناف</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select>
              <select className="select" value={adminFilters.orderStatus} onChange={(event) => setAdminFilters((value) => ({ ...value, orderStatus: event.target.value }))}><option value="">كل حالات الطلب</option>{ORDER_STATUSES.map((status) => <option key={status}>{status}</option>)}</select>
              <select className="select" value={adminFilters.paymentStatus} onChange={(event) => setAdminFilters((value) => ({ ...value, paymentStatus: event.target.value }))}><option value="">كل حالات الدفع</option>{PAYMENT_STATUSES.map((status) => <option key={status}>{status}</option>)}</select>
              <input className="input" type="date" aria-label="من تاريخ" value={adminFilters.from} onChange={(event) => setAdminFilters((value) => ({ ...value, from: event.target.value }))} />
              <input className="input" type="date" aria-label="إلى تاريخ" value={adminFilters.to} onChange={(event) => setAdminFilters((value) => ({ ...value, to: event.target.value }))} />
            </div>
            {adminOrdersLoading && <p className="helper">جارٍ تحديث الطلبات…</p>}
            <div className="order-list">
              {adminOrders.map((row) => <article key={row.order.id} className="admin-order-card" onClick={() => void openAdminOrder(row)}>
                <div className="admin-order-grid"><div><div className="order-code">{row.order.orderCode}</div><div className="admin-order-name">{row.customerName} · <button type="button" className="phone-chip" dir="ltr" onClick={(event) => { event.stopPropagation(); setContactSheet({ phone: row.customerPhone, name: row.customerName, order: { ...row.order, customerName: row.customerName, customerPhone: row.customerPhone } }); }}>{row.customerPhone}</button></div></div><div className="admin-order-meta">{row.order.categoryNameSnapshot}<br />{row.order.productNameSnapshot}</div><div className="admin-order-meta">{formatDate(row.order.createdAt)}</div><div><span className={`status-pill ${statusTone(row.order.orderStatus)}`}>{row.order.orderStatus}</span></div></div>
                <div className="admin-order-statuses"><span className={`status-pill ${statusTone(row.order.paymentStatus)}`}>الدفع: {row.order.paymentStatus}</span>{row.order.adminPaymentFollowup && row.order.paymentStatus !== "مدفوع ومؤكد" && <span className="status-pill amber">متابعة الدفع المقدم</span>}{row.order.locationLat !== null && row.order.locationLng !== null && <span className="status-pill green">موقع متاح</span>}</div>
              </article>)}
              {!adminOrdersLoading && adminOrders.length === 0 && <div className="empty-state"><div className="empty-icon">▤</div><h3>لا توجد طلبات مطابقة</h3><p>ستظهر هنا الطلبات التي يحفظها الخادم، سواء دُفعت أم لم تُدفع.</p></div>}
            </div>
          </section>}

          {adminTab === "catalog" && <section className="admin-panel">
            <div className="admin-toolbar"><h2>الأصناف</h2><span className="helper">الحذف يؤرشف ولا يمس الطلبات السابقة</span></div>
            {adminCatalogLoading ? <p className="helper">جارٍ تحميل الكتالوج…</p> : <>
              <div className="admin-toolbar"><h3 style={{ margin: 0 }}>الأصناف ({categories.length})</h3><button className="btn btn-primary btn-small" type="button" onClick={() => openCategoryEditor()}>＋ إضافة صنف</button></div>
              <div className="admin-card-grid">
                {categories.map((category) => <article className="manage-card" key={category.id}><div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}><h3>{category.name}</h3><span className={`status-pill ${category.archived ? "red" : category.visible ? "green" : "amber"}`}>{category.archived ? "مؤرشف" : category.visible ? "ظاهر" : "مخفي"}</span></div><p>{category.description || "دون وصف"} · الترتيب {category.sortOrder} · {category.customFields.length} حقول مخصصة</p><div className="manage-card-actions"><button className="btn btn-secondary btn-small" onClick={() => openCategoryEditor(category)}>تعديل</button><button className="btn btn-secondary btn-small" onClick={() => void changeCategory(category, { visible: !category.visible })}>{category.visible ? "إخفاء" : "إظهار"}</button><button className="btn btn-secondary btn-small" onClick={() => void changeCategory(category, { sortOrder: category.sortOrder - 1 })}>↑ ترتيب</button><button className="btn btn-secondary btn-small" onClick={() => void changeCategory(category, { sortOrder: category.sortOrder + 1 })}>↓ ترتيب</button><button className="btn btn-danger btn-small" onClick={() => void archiveCategory(category)}>{category.archived ? "إلغاء الأرشفة" : "أرشفة"}</button></div></article>)}
              </div>
            </>}
          </section>}

          {adminTab === "settings" && <section className="admin-panel">
            <div className="admin-toolbar"><div><h2>إعدادات الدفع والتواصل</h2><p className="section-subtitle">الدفع اختياري لكل الأصناف، والتنبيه المقدم يظهر للأسماء العسكرية فقط.</p></div></div>
            <form onSubmit={saveAdminSettings}><div className="form-grid">
              <div className="field"><label>حساب بنكك</label><input className="input" value={adminSettingsDraft.bankak} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, bankak: event.target.value }))} /></div>
              <div className="field"><label>حساب فوري</label><input className="input" value={adminSettingsDraft.fawry} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, fawry: event.target.value }))} /></div>
              <div className="field"><label>حساب أوكاش</label><input className="input" value={adminSettingsDraft.okash} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, okash: event.target.value }))} /></div>
              <div className="field"><label>رابط واتساب الرسمي</label><input className="input" dir="ltr" value={adminSettingsDraft.whatsappUrl} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, whatsappUrl: event.target.value }))} /><small className="helper">القيمة الافتراضية: https://wa.me/249129834873</small></div>
              <div className="field full"><label>اسم صاحب الحسابات (يظهر فوق أرقام الدفع)</label><input className="input" value={adminSettingsDraft.accountOwner} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, accountOwner: event.target.value }))} required /></div>
              <div className="field full"><label>تعليمات الدفع</label><textarea className="textarea" value={adminSettingsDraft.paymentInstructions} onChange={(event) => setAdminSettingsDraft((value) => ({ ...value, paymentInstructions: event.target.value }))} /></div>
              <div className="field full"><label>صورة إرشادية لوسائل الدفع · اختيارية</label><input className="input" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; try { const image = await readImage(file); setAdminSettingsDraft((value) => ({ ...value, paymentImageUrl: image })); } catch (error) { showToast(error instanceof Error ? error.message : "تعذر قراءة الصورة."); } }} />{adminSettingsDraft.paymentImageUrl && <div><img className="upload-preview" src={adminSettingsDraft.paymentImageUrl} alt="معاينة صورة تعليمات الدفع" /><button type="button" className="btn-link" onClick={() => setAdminSettingsDraft((value) => ({ ...value, paymentImageUrl: "" }))}>إزالة الصورة</button></div>}</div>
             </div><div className="form-actions"><button className="btn btn-primary" disabled={settingsSaveBusy}>{settingsSaveBusy ? "جارٍ الحفظ…" : "حفظ الإعدادات"}</button></div></form>
             <div className="form-actions"><button type="button" className="btn btn-secondary" onClick={() => void exportBackup()}>⬇ تنزيل نسخة بيانات JSON</button></div>
             <div className="notice warning" style={{ marginTop: 10 }}>النسخة الاحتياطية تتضمن بيانات الزبائن والمواقع والإيصالات؛ احفظها في مكان آمن ولا تشاركها علنًا.</div>
             <div className="notice info" style={{ marginTop: 18 }}>إيصال الدفع ورقم العملية لا يؤكدان الدفع تلقائيًا. حدّث حالة الدفع إلى «مدفوع ومؤكد» بعد التحقق الفعلي فقط.</div>
          </section>}

          {adminTab === "security" && <section className="admin-panel">
            <div className="admin-toolbar"><div><h2>الإعدادات والخصوصية</h2><p className="section-subtitle">حساب المسؤول، كلمة المرور، البصمة، الجلسات، الاستعادة، الخصوصية والنسخ الاحتياطي.</p></div></div>
            <SecurityCenter notify={showToast} onContactSaved={() => void loadCatalog()} onBrandChanged={(url) => { setBrandLogo(url); void loadCatalog(); }} onPromoSaved={(banner) => setPromo(banner)} onSignedOut={() => { setAdminAuthed(false); setAdminOpen(false); }} />
          </section>}

          {adminTab === "reports" && <section className="admin-panel">
            <div className="admin-toolbar"><div><h2>{reportHeading}</h2><p className="section-subtitle">تفاصيل الطلبات محفوظة من الخادم؛ لا تُجمع الأسعار.</p></div></div>
            <div className="report-filters">
              <input className="input search-field" placeholder="بحث برقم الطلب أو الزبون أو الهاتف" value={reportFilters.q} onChange={(event) => setReportFilters((value) => ({ ...value, q: event.target.value }))} />
              <select className="select" value={reportScope} onChange={(event) => setReportScope(event.target.value as ReportScope)}><option value="overall">التقرير الكلي للطلبات</option><option value="category">تقرير مستقل لصنف</option><option value="designer">تقرير المصمم – جميع الطلبات</option></select>
              <select className="select" value={reportCategoryId} onChange={(event) => setReportCategoryId(event.target.value)}><option value="">كل الأصناف</option>{categories.map((category) => <option value={category.id} key={category.id}>{category.name}{category.slug === "other" ? " · مستقل" : ""}</option>)}</select>
              <select className="select" value={reportFilters.orderStatus} onChange={(event) => setReportFilters((value) => ({ ...value, orderStatus: event.target.value }))}><option value="">كل حالات الطلب</option>{ORDER_STATUSES.map((status) => <option key={status}>{status}</option>)}</select>
              <select className="select" value={reportFilters.paymentStatus} onChange={(event) => setReportFilters((value) => ({ ...value, paymentStatus: event.target.value }))}><option value="">كل حالات الدفع</option>{PAYMENT_STATUSES.map((status) => <option key={status}>{status}</option>)}</select>
              <input className="input" type="date" aria-label="من تاريخ" value={reportFilters.from} onChange={(event) => setReportFilters((value) => ({ ...value, from: event.target.value }))} />
              <input className="input" type="date" aria-label="إلى تاريخ" value={reportFilters.to} onChange={(event) => setReportFilters((value) => ({ ...value, to: event.target.value }))} />
            </div>
            {renderReportActions()}
            <div className="report-document" ref={reportRef}>
              <header className="report-header" data-pdf-block><h2>{reportHeading}</h2><p>أبو قمري للعلامات العسكرية · تاريخ الإنشاء {formatDate(new Date())} · عدد الطلبات الظاهرة: {reportVisibleRows.length}</p></header>
              {reportLoading ? <div className="empty-state"><p>جارٍ تحميل الطلبات للتقرير…</p></div> : reportVisibleRows.length ? <>
                {reportScope === "category" ? <>
                  <div data-pdf-block><h3 style={{ color: "var(--red)", margin: "4px 0 12px" }}>تقرير كل التفاصيل</h3></div>
                  {reportVisibleRows.map((row, index) => renderReportCard(row, index, false))}
                  <div data-pdf-block><h3 style={{ color: "var(--red)", margin: "18px 0 12px" }}>تقرير المصمم</h3></div>
                  {reportVisibleRows.map((row, index) => renderReportCard(row, index, true))}
                </> : reportVisibleRows.map((row, index) => renderReportCard(row, index, reportScope === "designer"))}
              </> : <div className="empty-state"><h3>لا توجد طلبات ظاهرة في التقرير</h3><p>عدّل البحث أو التصفية، أو أرسل طلبًا ليظهر في التقرير.</p></div>}
            </div>
            {renderReportActions()}
          </section>}
        </>}
      </main>
    </>}

    {orderOpen && activeCategory && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !submittingOrder) setOrderOpen(false); }}>
      <section className="modal-card modal-wide" role="dialog" aria-modal="true" aria-labelledby="order-title">
        <div className="modal-head"><div><h2 id="order-title">تقديم طلب · {activeCategory.name}</h2><p>{selectedProduct ? selectedProduct.name : "اكتب الوصف والكمية، وسيُحدد GPS تلقائيًا قبل إرسال الطلب."}</p></div><button className="close-button" type="button" onClick={() => setOrderOpen(false)} aria-label="إغلاق">×</button></div>
        <form onSubmit={placeOrder}>
          <div className="form-grid">
            <div className="field"><label htmlFor="customer-name">اسم الزبون *</label><input id="customer-name" className="input" autoComplete="name" value={profile.name} onChange={(event) => { const next = { ...profile, name: event.target.value }; setProfile(next); setProfileDraft(next); try { localStorage.setItem("abuqomari-profile", JSON.stringify(next)); } catch { /* optional local convenience */ } }} required /></div>
            <div className="field"><label htmlFor="customer-phone">رقم الهاتف *</label><input id="customer-phone" className="input" type="tel" inputMode="tel" autoComplete="tel" value={profile.phone} onChange={(event) => { const next = { ...profile, phone: event.target.value }; setProfile(next); setProfileDraft(next); try { localStorage.setItem("abuqomari-profile", JSON.stringify(next)); } catch { /* optional local convenience */ } }} required /></div>
            {activeCategory.slug === "military-names" && <div className="field full"><label htmlFor="printed-name">الاسم المطلوب طباعته حرفيًا *</label><input id="printed-name" className="input" value={form.printedName} onChange={(event) => updateForm("printedName", event.target.value)} placeholder="اكتب الاسم تمامًا كما تريد طباعته" required /></div>}
             <div className="field full"><label htmlFor="design-description">الوصف *</label><textarea id="design-description" className="textarea" value={form.designDescription} onChange={(event) => updateForm("designDescription", event.target.value)} placeholder="اكتب وصف الطلب أو تفاصيل التصميم…" required /></div>
            <div className="field"><label htmlFor="quantity">الكمية *</label><input id="quantity" className="input" type="number" min="1" max="10000" inputMode="numeric" value={form.quantity} onChange={(event) => updateForm("quantity", event.target.value)} required /></div>
            {customFields.map((field) => <div className="field" key={field.key}><label htmlFor={`custom-${field.key}`}>{field.label}{field.required ? " *" : ""}</label>{field.type === "textarea" ? <textarea id={`custom-${field.key}`} className="textarea" value={form.customValues[field.key] || ""} onChange={(event) => updateForm("customValues", { ...form.customValues, [field.key]: event.target.value })} required={field.required} /> : field.type === "select" ? <select id={`custom-${field.key}`} className="select" value={form.customValues[field.key] || ""} onChange={(event) => updateForm("customValues", { ...form.customValues, [field.key]: event.target.value })} required={field.required}><option value="">اختر</option>{field.options?.map((option) => <option key={option}>{option}</option>)}</select> : <input id={`custom-${field.key}`} className="input" value={form.customValues[field.key] || ""} onChange={(event) => updateForm("customValues", { ...form.customValues, [field.key]: event.target.value })} required={field.required} />}</div>)}
            <div className="field full"><label htmlFor="customer-notes">ملاحظات الزبون</label><textarea id="customer-notes" className="textarea" value={form.notes} onChange={(event) => updateForm("notes", event.target.value)} placeholder="أي توضيحات أو ملاحظات إضافية…" /></div>
          </div>

          <div className="location-card">
            <strong style={{ fontSize: 13 }}>تحديد الموقع عبر GPS</strong>
            <p className="helper" style={{ margin: "3px 0 8px" }}>يُطلب إذن الموقع عند فتح نموذج الطلب، ويُربط الموقع بهذا الطلب لعرضه للإدارة فقط.</p>
            {form.latitude !== null && form.longitude !== null
              ? <div className="notice success">✓ تم تحديد الموقع. سيُرسل مع الطلب إلى الإدارة.</div>
              : <div className={`notice ${locationError ? "warning" : "info"}`}>{locationLoading ? "جارٍ تحديد الموقع عبر GPS…" : locationError || "جارٍ طلب إذن الموقع وتحديده تلقائيًا…"}</div>}
            {(!locationLoading && (locationError || (form.latitude === null || form.longitude === null))) && <button type="button" className="btn btn-secondary btn-small" style={{ marginTop: 9 }} onClick={() => void locateBuyer()}>⌖ إعادة تحديد الموقع</button>}
          </div>

          {activeCategory.slug === "military-names" && <div className="payment-box">
            <div className="notice"><strong>تنبيه:</strong> الدفع مقدمًا للأسماء العسكرية. يمكنك اختيار وسيلة الدفع المتاحة، كما يمكنك تقديم طلبك أولًا ليصل إلى الإدارة، ثم الاتفاق معها على تفاصيل الدفع.</div>
            <p className="helper" style={{ margin: "10px 0 0" }}>اختيار وسيلة الدفع وإدخال رقم العملية ورفع الإيصال أمور اختيارية عند إرسال الطلب.</p>
            <div className="payment-options">{PAYMENT_METHODS.map((method) => <button type="button" key={method} className={`payment-choice ${form.paymentMethod === method ? "selected" : ""}`} onClick={() => updateForm("paymentMethod", form.paymentMethod === method ? "" : method)}>{method}</button>)}</div>
            <div className="owner-strip"><span className="owner-label">اسم صاحب الحسابات</span><strong className="owner-name">{settings.accountOwner}</strong></div>
            {(["بنكك", "فوري", "أوكاش"] as const).map((method) => {
              const account = method === "بنكك" ? settings.bankak : method === "فوري" ? settings.fawry : settings.okash;
              return <div className="account-row" key={method}><span>{method}</span><span className="account-number">{account}</span><button className="btn btn-secondary btn-small" type="button" onClick={() => void copyValue(account, `رقم ${method}`)}>نسخ</button></div>;
            })}
            {settings.paymentInstructions && <p className="helper" style={{ marginTop: 10 }}>{settings.paymentInstructions}</p>}
            {settings.paymentImageUrl && <img className="upload-preview" style={{ display: "block", maxWidth: 340, maxHeight: 220 }} src={settings.paymentImageUrl} alt="صورة إرشادية لوسائل الدفع" loading="lazy" />}
            <div className="form-grid" style={{ marginTop: 12 }}><div className="field"><label htmlFor="transaction-reference">رقم العملية <span className="optional">(اختياري)</span></label><input id="transaction-reference" className="input" value={form.transactionReference} onChange={(event) => updateForm("transactionReference", event.target.value)} /></div><div className="field"><label htmlFor="receipt-upload">صورة الإيصال <span className="optional">(اختيارية)</span></label><input id="receipt-upload" className="input" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; try { setReceiptData(await readImage(file)); } catch (error) { showToast(error instanceof Error ? error.message : "تعذر رفع الإيصال."); } }} />{receiptData && <><img className="upload-preview" src={receiptData} alt="معاينة الإيصال" /><button type="button" className="btn-link" onClick={() => setReceiptData("")}>إزالة الإيصال</button></>}</div></div>
          </div>}

          <div className="form-actions"><button className="btn btn-primary" type="submit" disabled={submittingOrder || locationLoading || form.latitude === null || form.longitude === null} style={{ flex: 1 }}>{submittingOrder ? <><span className="spinner" /> جارٍ إرسال الطلب بأمان…</> : locationLoading ? "جارٍ تحديد الموقع…" : form.latitude === null || form.longitude === null ? "حدّد GPS لإرسال الطلب" : "إرسال الطلب للإدارة"}</button><button className="btn btn-secondary" type="button" disabled={submittingOrder} onClick={() => setOrderOpen(false)}>إلغاء</button></div>
          <p className="helper" style={{ marginTop: 10 }}>لن نعرض تأكيدًا إلا بعد تأكيد حفظ الخادم للطلب. بيانات النموذج تبقى على هذا الجهاز عند تعذر الاتصال.</p>
        </form>
      </section>
    </div>}

    {profileOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && profileWasSaved) setProfileOpen(false); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="profile-title">
        <div className="modal-head"><div><h2 id="profile-title">بيانات الزبون</h2><p>الاسم ورقم الهاتف فقط؛ احفظهما على هذا الجهاز لتسهيل الطلبات.</p></div>{profileWasSaved && <button className="close-button" type="button" onClick={() => setProfileOpen(false)}>×</button>}</div>
        <form onSubmit={saveProfile}><div className="form-grid"><div className="field full"><label htmlFor="profile-name">الاسم</label><input id="profile-name" className="input" autoComplete="name" value={profileDraft.name} onChange={(event) => setProfileDraft((value) => ({ ...value, name: event.target.value }))} required /></div><div className="field full"><label htmlFor="profile-phone">رقم الهاتف</label><input id="profile-phone" className="input" type="tel" inputMode="tel" autoComplete="tel" value={profileDraft.phone} onChange={(event) => setProfileDraft((value) => ({ ...value, phone: event.target.value }))} required /></div></div><div className="form-actions"><button className="btn btn-primary" type="submit">حفظ ومتابعة</button>{!profileWasSaved && <button className="btn btn-secondary" type="button" onClick={() => setProfileOpen(false)}>التصفح أولًا</button>}</div><p className="helper" style={{ marginTop: 12 }}>{identityChecking ? "جارٍ التحقق…" : "تُحفظ بياناتك على هذا الجهاز لتسهيل الطلبات."}</p></form>
      </section>
    </div>}

    {trackOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setTrackOpen(false); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="tracking-title">
        <div className="modal-head"><div><h2 id="tracking-title">طلباتي وحالة الطلب</h2><p>يمكن فتح الطلب على هذا الجهاز باستخدام رمز الوصول المحفوظ محليًا.</p></div><button className="close-button" type="button" onClick={() => setTrackOpen(false)}>×</button></div>
        {savedOrders.length === 0 ? <div className="empty-state"><div className="empty-icon">⌕</div><h3>لا توجد طلبات محفوظة على هذا الجهاز</h3><p>بعد إرسال الطلب ستجد رقمه هنا، ويمكنك متابعة حالته.</p></div> : <div className="order-list">{savedOrders.map((credential) => <div className="order-summary" key={credential.code}><div className="order-summary-top"><span className="order-code">{credential.code}</span><button className="btn btn-secondary btn-small" onClick={() => void loadTrackingOrder(credential)}>عرض الحالة</button></div></div>)}</div>}
        {trackingLoading && <div className="notice info" style={{ marginTop: 13 }}>جارٍ تحميل حالة الطلب من الخادم…</div>}
        {trackingError && <div className="notice" style={{ marginTop: 13 }}>{trackingError}</div>}
        {trackingOrder && <div className="order-summary" style={{ marginTop: 14 }}><div className="order-summary-top"><span className="order-code">{trackingOrder.orderCode}</span><span className={`status-pill ${statusTone(trackingOrder.orderStatus)}`}>{trackingOrder.orderStatus}</span></div><h3>{trackingOrder.categoryNameSnapshot} · {trackingOrder.productNameSnapshot}</h3><p>حالة الدفع: {trackingOrder.paymentStatus} · الكمية: {trackingOrder.quantity}</p><p style={{ marginTop: 5 }}>تاريخ الطلب: {formatDate(trackingOrder.createdAt)}</p><div className="order-summary-actions"><button className="btn btn-secondary btn-small" type="button" onClick={() => openWhatsapp(trackingOrder)}>التواصل عبر واتساب بشأن الطلب</button><button className="btn btn-secondary btn-small" type="button" onClick={() => void loadTrackingOrder({ code: trackingOrder.orderCode, token: savedOrders.find((item) => item.code === trackingOrder.orderCode)?.token || successOrder?.token || "" })}>تحديث الحالة</button></div></div>}
      </section>
    </div>}

    {successOrder && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSuccessOrder(null); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="success-title">
        <div className="modal-head"><div><h2 id="success-title">وصل طلبك إلى الإدارة</h2><p>تأكد الخادم من حفظ الطلب بنجاح.</p></div><button className="close-button" type="button" onClick={() => setSuccessOrder(null)}>×</button></div>
        <div className="notice success"><strong>رقم طلبك</strong><div className="order-code" style={{ fontSize: 21, marginTop: 5 }}>{successOrder.code}</div></div>
        <div className="definition-grid" style={{ marginTop: 13 }}><div className="definition"><strong>الصنف</strong><span>{successOrder.category}</span></div><div className="definition"><strong>المنتج</strong><span>{successOrder.product}</span></div><div className="definition"><strong>حالة الطلب</strong><span>جديد</span></div><div className="definition"><strong>حالة الدفع</strong><span>غير مدفوع أو بانتظار الدفع عند الاختيار</span></div></div>
        <div className="form-actions"><button className="btn btn-primary" type="button" onClick={() => openWhatsapp({ orderCode: successOrder.code, customerName: profile.name, categoryNameSnapshot: successOrder.category, productNameSnapshot: successOrder.product })}>متابعة عبر واتساب</button><button className="btn btn-secondary" type="button" onClick={() => { setSuccessOrder(null); setTrackOpen(true); void loadTrackingOrder({ code: successOrder.code, token: successOrder.token }); }}>متابعة حالة الطلب</button></div>
      </section>
    </div>}

    {adminSelectedOrder && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setAdminSelectedOrder(null); }}>
      <section className="modal-card modal-wide" role="dialog" aria-modal="true" aria-labelledby="admin-order-title">
        <div className="modal-head"><div><h2 id="admin-order-title">تفاصيل الطلب · <span className="order-code">{adminSelectedOrder.orderCode}</span></h2><p>{formatDate(adminSelectedOrder.createdAt)} · {adminSelectedOrder.categoryNameSnapshot} · {adminSelectedOrder.productNameSnapshot}</p></div><button className="close-button" type="button" onClick={() => setAdminSelectedOrder(null)}>×</button></div>
        <div className="definition-grid">
          <div className="definition"><strong>اسم الزبون</strong><span>{adminSelectedOrder.customerName}</span></div><div className="definition"><strong>الهاتف</strong><span><button type="button" className="phone-chip" dir="ltr" onClick={() => setContactSheet({ phone: adminSelectedOrder.customerPhone, name: adminSelectedOrder.customerName, order: adminSelectedOrder })}>{adminSelectedOrder.customerPhone}</button></span></div>
          {adminSelectedOrder.printedName && <div className="definition"><strong>الاسم المطلوب طباعته حرفيًا</strong><span>{adminSelectedOrder.printedName}</span></div>}
          {Object.entries(adminSelectedOrder.details || {}).filter(([key]) => !isForbiddenDimensionKey(key)).map(([key, value]) => <div className="definition" key={key}><strong>{fieldLabel(key)}</strong><span>{String(value)}</span></div>)}
          <div className="definition"><strong>الكمية</strong><span>{adminSelectedOrder.quantity}</span></div>{adminSelectedOrder.unitPrice && <div className="definition"><strong>سعر الوحدة</strong><span>{adminSelectedOrder.unitPrice}</span></div>}
          <div className="definition"><strong>وسيلة الدفع</strong><span>{adminSelectedOrder.paymentMethod || "لم تُحدد"}</span></div><div className="definition"><strong>رقم العملية</strong><span>{adminSelectedOrder.transactionReference || "—"}</span></div>
          <div className="definition"><strong>حالة الطلب</strong><span>{adminSelectedOrder.orderStatus}</span></div><div className="definition"><strong>حالة الدفع</strong><span>{adminSelectedOrder.paymentStatus}</span></div>
          {adminSelectedOrder.customerNotes && <div className="definition"><strong>ملاحظات الزبون</strong><span>{adminSelectedOrder.customerNotes}</span></div>}
        </div>
        {adminSelectedOrder.receiptData && <div className="location-card"><strong>إيصال مرفق (غير مؤكد تلقائيًا)</strong><br /><img className="upload-preview" style={{ maxWidth: 300, maxHeight: 240 }} src={adminSelectedOrder.receiptData} alt="إيصال دفع مرفق" /></div>}
        {adminSelectedOrder.locationLat !== null && adminSelectedOrder.locationLng !== null && <div className="location-card"><strong>موقع المشتري المشارك</strong><p className="helper">الإحداثيات محفوظة لهذا الطلب فقط.</p><a className="btn btn-secondary btn-small" href={`https://www.google.com/maps?q=${adminSelectedOrder.locationLat},${adminSelectedOrder.locationLng}`} target="_blank" rel="noreferrer">⌖ عرض موقع المشتري</a></div>}
        {adminSelectedOrder.adminPaymentFollowup && adminSelectedOrder.paymentStatus !== "مدفوع ومؤكد" && <div className="notice warning" style={{ margin: "12px 0" }}>متابعة الدفع المقدم للأسماء العسكرية: تواصل مع الزبون للاتفاق والتحقق. لا يمنع ذلك وصول الطلب.</div>}
        <form onSubmit={saveAdminOrder} style={{ marginTop: 15 }}><div className="form-grid"><div className="field"><label>حالة الطلب</label><select className="select" value={adminDraft.orderStatus} onChange={(event) => setAdminDraft((value) => ({ ...value, orderStatus: event.target.value }))}>{ORDER_STATUSES.map((status) => <option key={status}>{status}</option>)}</select></div><div className="field"><label>حالة الدفع مستقلة</label><select className="select" value={adminDraft.paymentStatus} onChange={(event) => setAdminDraft((value) => ({ ...value, paymentStatus: event.target.value }))}>{PAYMENT_STATUSES.map((status) => <option key={status}>{status}</option>)}</select></div><div className="field full"><label>ملاحظات إدارية</label><textarea className="textarea" value={adminDraft.adminNotes} onChange={(event) => setAdminDraft((value) => ({ ...value, adminNotes: event.target.value }))} /></div></div><div className="form-actions"><button className="btn btn-primary" disabled={adminSaveBusy}>{adminSaveBusy ? "جارٍ الحفظ…" : "حفظ التغييرات"}</button><button type="button" className="btn btn-secondary" onClick={() => setContactSheet({ phone: adminSelectedOrder.customerPhone, name: adminSelectedOrder.customerName, order: adminSelectedOrder })}>التواصل مع الزبون</button></div></form>
      </section>
    </div>}

    {showCategoryForm && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowCategoryForm(false); }}>
      <section className="modal-card modal-wide" role="dialog" aria-modal="true" aria-labelledby="catalog-form-title">
        {<><div className="modal-head"><div><h2 id="catalog-form-title">{editingCategory ? "تعديل الصنف" : "إضافة صنف جديد"}</h2><p>الطلبات السابقة تحتفظ باسم الصنف وتفاصيله التاريخية.</p></div><button className="close-button" onClick={() => setShowCategoryForm(false)}>×</button></div>
          <form onSubmit={saveCategory}><div className="form-grid"><div className="field"><label>اسم الصنف</label><input className="input" value={categoryDraft.name} onChange={(event) => setCategoryDraft((value) => ({ ...value, name: event.target.value }))} required /></div><div className="field"><label>معرّف لاتيني اختياري</label><input className="input" dir="ltr" value={categoryDraft.slug} onChange={(event) => setCategoryDraft((value) => ({ ...value, slug: event.target.value }))} placeholder="custom-category" disabled={Boolean(editingCategory)} /></div><div className="field"><label>الترتيب</label><input className="input" type="number" value={categoryDraft.sortOrder} onChange={(event) => setCategoryDraft((value) => ({ ...value, sortOrder: event.target.value }))} /></div><div className="field"><label>الظهور في المتجر</label><select className="select" value={categoryDraft.visible ? "yes" : "no"} onChange={(event) => setCategoryDraft((value) => ({ ...value, visible: event.target.value === "yes" }))}><option value="yes">ظاهر</option><option value="no">مخفي</option></select></div><div className="field full"><label>وصف الصنف</label><textarea className="textarea" value={categoryDraft.description} onChange={(event) => setCategoryDraft((value) => ({ ...value, description: event.target.value }))} /></div><div className="field full"><label>حقول مخصصة · سطر لكل حقل</label><textarea className="textarea" value={categoryDraft.customFieldsText} onChange={(event) => setCategoryDraft((value) => ({ ...value, customFieldsText: event.target.value }))} placeholder={'الرتبة|select|جندي,عريف,رقيب|مطلوب\nالتفاصيل|textarea||اختياري\nتفاصيل إضافية|textarea||اختياري'} /><small className="helper">الصيغة: الاسم|text أو textarea أو select|خيارات مفصولة بفاصلة|مطلوب أو اختياري</small></div></div><div className="form-actions"><button className="btn btn-primary" disabled={catalogSaveBusy}>{catalogSaveBusy ? "جارٍ الحفظ…" : "حفظ الصنف"}</button></div></form>
        </>}
      </section>
    </div>}

    {contactSheet && (() => {
      const wa = customerWhatsappHref(contactSheet.phone, contactSheet.order ? { ...contactSheet.order, customerName: contactSheet.name } : undefined);
      const tel = customerTelHref(contactSheet.phone);
      return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setContactSheet(null); }}>
        <section className="modal-card contact-sheet" role="dialog" aria-modal="true" aria-labelledby="contact-sheet-title">
          <div className="modal-head"><div><h2 id="contact-sheet-title">التواصل مع {contactSheet.name}</h2><p dir="ltr" style={{ textAlign: "right" }}>{contactSheet.phone}{contactSheet.order?.orderCode ? ` · ${contactSheet.order.orderCode}` : ""}</p></div><button className="close-button" type="button" onClick={() => setContactSheet(null)} aria-label="إغلاق">×</button></div>
          <div className="contact-actions">
            {wa && <a className="contact-action contact-whatsapp" href={wa} target="_blank" rel="noreferrer noopener" onClick={() => setContactSheet(null)}><span className="contact-icon">◉</span><span><strong>واتساب</strong><small>يفتح محادثة مع رقم الزبون ورسالة جاهزة للمراجعة قبل الإرسال</small></span></a>}
            <a className="contact-action contact-call" href={tel} onClick={() => setContactSheet(null)}><span className="contact-icon">✆</span><span><strong>اتصال مباشر</strong><small>{wa ? "مكالمة هاتفية عادية" : "الرقم ليس بصيغة جوال دولية؛ متاح الاتصال فقط"}</small></span></a>
            <button type="button" className="contact-action" onClick={() => void copyValue(contactSheet.phone, "رقم الزبون")}><span className="contact-icon">⧉</span><span><strong>نسخ الرقم</strong><small>للصقه في أي تطبيق آخر</small></span></button>
          </div>
          {wa && <p className="helper" style={{ marginTop: 10 }}>إن لم يكن لدى الزبون واتساب فسيُخبرك التطبيق بذلك عند فتح المحادثة؛ استخدم الاتصال المباشر حينها.</p>}
        </section>
      </div>;
    })()}

    {toast && <div className="toast" role="status">{toast}</div>}
  </div>;
}

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }> };
