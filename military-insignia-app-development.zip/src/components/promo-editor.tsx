"use client";

import { useCallback, useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import PromoBannerView from "@/components/promo-banner";
import type { PromoBanner } from "@/lib/promo-shared";

type Props = { notify: (message: string) => void; onSaved: (banner: PromoBanner) => void };

const LINK_PRESETS = [
  { value: "#categories", label: "الانتقال إلى الأصناف" },
  { value: "whatsapp", label: "فتح واتساب الإدارة" },
  { value: "custom", label: "رابط خارجي (https://…)" },
];

function presetFor(link: string) {
  return link === "#categories" || link === "whatsapp" ? link : link ? "custom" : "#categories";
}

export default function PromoEditor({ notify, onSaved }: Props) {
  const [banner, setBanner] = useState<PromoBanner | null>(null);
  const [draft, setDraft] = useState<PromoBanner | null>(null);
  const [defaults, setDefaults] = useState<PromoBanner | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/promo", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل اللافتة.");
      setBanner(data.banner); setDraft(data.banner); setDefaults(data.defaults); setError("");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر تحميل اللافتة."); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const dirty = banner && draft ? JSON.stringify(banner) !== JSON.stringify(draft) : false;
  const update = <K extends keyof PromoBanner>(key: K, value: PromoBanner[K]) => setDraft((current) => current ? { ...current, [key]: value } : current);

  async function pickImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) { notify("الصيغة غير مدعومة. استخدم PNG أو JPG أو WebP."); return; }
    if (file.size > 1_200_000) { notify("حجم الصورة يتجاوز 1.2 ميغابايت."); return; }
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === "string") update("imageUrl", reader.result); };
    reader.readAsDataURL(file);
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    if (!draft) return;
    setBusy(true); setError(""); setStatus("");
    try {
      const response = await fetch("/api/admin/promo", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر حفظ اللافتة.");
      setBanner(data.banner); setDraft(data.banner);
      onSaved(data.banner);
      setStatus(`تم الحفظ في قاعدة البيانات وتحديث الصفحة الرئيسية (${new Date().toLocaleTimeString("ar")}).`);
      notify("تم حفظ اللافتة الترويجية.");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر حفظ اللافتة."); }
    finally { setBusy(false); }
  }

  async function reset() {
    if (!window.confirm("ستُستعاد اللافتة الافتراضية وتُحفظ فورًا. متابعة؟")) return;
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/admin/promo", { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر الاستعادة.");
      setBanner(data.banner); setDraft(data.banner); onSaved(data.banner);
      setStatus("تمت استعادة اللافتة الافتراضية وحفظها.");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر الاستعادة."); }
    finally { setBusy(false); }
  }

  if (error && !draft) return <div className="notice">{error} <button className="btn-link" onClick={() => void load()}>إعادة المحاولة</button></div>;
  if (!draft) return <p className="helper">جارٍ تحميل اللافتة…</p>;

  const linkField = (textKey: "primaryButtonText" | "secondaryButtonText", linkKey: "primaryButtonLink" | "secondaryButtonLink", label: string) => {
    const preset = presetFor(draft[linkKey]);
    return <div className="promo-button-group">
      <strong>{label}</strong>
      <div className="form-grid">
        <div className="field"><label>نص الزر</label><input className="input" maxLength={40} value={draft[textKey]} onChange={(event) => update(textKey, event.target.value)} placeholder="اتركه فارغًا لإخفاء الزر" /></div>
        <div className="field"><label>وجهة الزر</label><select className="select" value={preset} onChange={(event) => update(linkKey, event.target.value === "custom" ? "https://" : event.target.value)}>{LINK_PRESETS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></div>
        {preset === "custom" && <div className="field full"><label>الرابط الخارجي</label><input className="input" dir="ltr" value={draft[linkKey]} onChange={(event) => update(linkKey, event.target.value)} placeholder="https://example.com" /></div>}
      </div>
    </div>;
  };

  return <form onSubmit={save}>
    <div className="promo-preview-wrap"><span className="report-designer-label">معاينة حية</span><PromoBannerView banner={draft} onWhatsapp={() => undefined} compact /></div>
    <div className="form-grid" style={{ marginTop: 14 }}>
      <div className="field"><label>السطر العلوي الصغير</label><input className="input" maxLength={80} value={draft.kicker} onChange={(event) => update("kicker", event.target.value)} /></div>
      <div className="field"><label>العنوان *</label><input className="input" maxLength={120} value={draft.title} onChange={(event) => update("title", event.target.value)} required /></div>
      <div className="field full"><label>الوصف</label><textarea className="textarea" maxLength={400} value={draft.description} onChange={(event) => update("description", event.target.value)} /></div>
      <div className="field full"><label>صورة الخلفية <span className="optional">(اختيارية)</span></label>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <input className="input" dir="ltr" style={{ flex: 1, minWidth: 200 }} value={draft.imageUrl.startsWith("data:") ? "(صورة مرفوعة من الجهاز)" : draft.imageUrl} onChange={(event) => update("imageUrl", event.target.value)} placeholder="https://… أو ارفع صورة" readOnly={draft.imageUrl.startsWith("data:")} />
          <label className="btn btn-secondary btn-small" style={{ cursor: "pointer" }}>رفع صورة<input type="file" accept="image/png,image/jpeg,image/webp" style={{ display: "none" }} onChange={(event) => void pickImage(event)} /></label>
          {draft.imageUrl && <button type="button" className="btn btn-danger btn-small" onClick={() => update("imageUrl", "")}>إزالة الصورة</button>}
        </div>
        <small className="helper">تُعرض كخلفية خلف النص مع تدرج أحمر للحفاظ على وضوح الكتابة. PNG/JPG/WebP حتى 1.2 ميغابايت.</small>
      </div>
    </div>
    {linkField("primaryButtonText", "primaryButtonLink", "الزر الأول (أبيض)")}
    {linkField("secondaryButtonText", "secondaryButtonLink", "الزر الثاني (شفاف)")}
    <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12, fontSize: 12 }}><input type="checkbox" checked={draft.enabled} onChange={(event) => update("enabled", event.target.checked)} /> إظهار اللافتة في الصفحة الرئيسية</label>
    {error && <div className="notice" style={{ marginTop: 12 }}>{error}</div>}
    {status && !error && <div className="notice success" style={{ marginTop: 12 }}>{status}</div>}
    <div className="form-actions">
      <button className="btn btn-primary" disabled={busy || !dirty}>{busy ? "جارٍ الحفظ…" : "حفظ التغييرات"}</button>
      <button type="button" className="btn btn-secondary" disabled={busy || !dirty} onClick={() => { if (banner) setDraft(banner); setError(""); setStatus(""); }}>إلغاء التعديلات</button>
      {defaults && <button type="button" className="btn btn-danger" disabled={busy} onClick={() => void reset()}>استعادة الافتراضية</button>}
    </div>
    <p className="helper" style={{ marginTop: 8 }}>{dirty ? "توجد تغييرات غير محفوظة." : banner?.updatedAt ? `آخر حفظ: ${new Date(banner.updatedAt).toLocaleString("ar")}` : "اللافتة الافتراضية (لم تُعدَّل بعد)."}</p>
  </form>;
}
