"use client";

import type { PromoBanner } from "@/lib/promo-shared";

type Props = { banner: PromoBanner; onWhatsapp: () => void; compact?: boolean };

function isExternal(link: string) {
  return /^https:\/\//.test(link);
}

export default function PromoBannerView({ banner, onWhatsapp, compact = false }: Props) {
  if (!banner.enabled) return null;

  const renderButton = (text: string, link: string, variant: "btn-primary" | "btn-ghost") => {
    if (!text) return null;
    if (link === "whatsapp") return <button key={variant} className={`btn ${variant}`} type="button" onClick={onWhatsapp}>{variant === "btn-ghost" ? "◉ " : ""}{text}</button>;
    if (link.startsWith("#")) {
      return <button key={variant} className={`btn ${variant}`} type="button" onClick={() => document.getElementById(link.slice(1))?.scrollIntoView({ behavior: "smooth" })}>{text} <span>←</span></button>;
    }
    return <a key={variant} className={`btn ${variant}`} href={link} target={isExternal(link) ? "_blank" : undefined} rel={isExternal(link) ? "noreferrer noopener" : undefined}>{text}</a>;
  };

  return <section className={`hero ${banner.imageUrl ? "hero-with-image" : ""} ${compact ? "hero-compact" : ""}`} aria-label="اللافتة الترويجية">
    {banner.imageUrl && <img className="hero-image" src={banner.imageUrl} alt="" aria-hidden="true" loading="eager" />}
    <div className="hero-content">
      {banner.kicker && <span className="hero-kicker">{banner.kicker}</span>}
      <h1>{banner.title}</h1>
      {banner.description && <p>{banner.description}</p>}
      {(banner.primaryButtonText || banner.secondaryButtonText) && <div className="hero-actions">
        {renderButton(banner.primaryButtonText, banner.primaryButtonLink, "btn-primary")}
        {renderButton(banner.secondaryButtonText, banner.secondaryButtonLink, "btn-ghost")}
      </div>}
    </div>
  </section>;
}
