"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import { browserSupportsWebAuthn, platformAuthenticatorIsAvailable, startAuthentication, startRegistration } from "@simplewebauthn/browser";

type Mode = "loading" | "setup" | "passkey-offer" | "login" | "recovery" | "error";

export const PASSWORD_RULES = ["12 حرفًا على الأقل", "حروف وأرقام معًا", "ليست كلمة شائعة أو متسلسلة", "لا تتضمن اسمك أو بريدك أو هاتفك"];

export function passwordHints(password: string) {
  const hints: string[] = [];
  if (password.length < 12) hints.push("أقل من 12 حرفًا");
  if (!/[\p{L}]/u.test(password) || !/\d/.test(password)) hints.push("يلزم حروف وأرقام معًا");
  if (/(password|123456|qwerty|admin)/i.test(password)) hints.push("تحتوي على مقطع شائع");
  return hints;
}

export function FingerprintIcon({ size = 64, active = false }: { size?: number; active?: boolean }) {
  return <svg className={`fingerprint-icon ${active ? "active" : ""}`} width={size} height={size} viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M14 22c4-7 10.5-11 18-11 4 0 7.6 1 10.8 2.8" />
    <path d="M9 36c0-5 1.4-9.6 3.9-13.5M50 20.5A22 22 0 0 1 55 34c0 3.4-.3 6.7-.9 9.9" />
    <path d="M15.5 44.5c-.7-2.7-1-5.5-1-8.5 0-9.7 7.8-17.5 17.5-17.5S49.5 26.3 49.5 36c0 6-.9 11.8-2.6 17.2" />
    <path d="M21 52.5c-.9-2.6-1.6-5.4-2-8.3M43.6 54.6c1.3-6 2-12.2 2-18.6 0-7.5-6-13.5-13.6-13.5S18.4 28.5 18.4 36" />
    <path d="M26.5 56.3c-1.1-2.3-2-4.8-2.6-7.4M38 55.6c1.5-6.4 2.2-13 2.2-19.6 0-4.5-3.7-8.2-8.2-8.2S23.8 31.5 23.8 36c0 2.4.2 4.7.6 7" />
    <path d="M32 57.5c1-4.5 1.7-9.2 2-14M29.3 36c0-1.5 1.2-2.7 2.7-2.7s2.7 1.2 2.7 2.7c0 2.6-.1 5.1-.4 7.6" />
  </svg>;
}

type Props = {
  identity: { name: string; phone: string };
  passkeyLoginAvailable: boolean;
  setupRequired: boolean;
  logoUrl?: string;
  onAuthenticated: (admin: { name: string; email: string }) => void;
  onClose: () => void;
};

export default function AdminAuth({ identity, passkeyLoginAvailable, setupRequired, logoUrl = "", onAuthenticated, onClose }: Props) {
  const [mode, setMode] = useState<Mode>(setupRequired ? "setup" : "login");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [token, setToken] = useState("");
  const [showPasswordLogin, setShowPasswordLogin] = useState(!passkeyLoginAvailable);
  const [webauthn, setWebauthn] = useState({ supported: false, platform: false });
  const [pendingAdmin, setPendingAdmin] = useState<{ name: string; email: string } | null>(null);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    const supported = browserSupportsWebAuthn();
    setWebauthn({ supported, platform: false });
    if (supported) platformAuthenticatorIsAvailable().then((platform) => setWebauthn({ supported, platform })).catch(() => undefined);
  }, []);

  async function post(path: string, body: Record<string, unknown>) {
    const response = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "تعذر إتمام العملية.");
    return data;
  }

  async function handleSetup(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      const data = await post("/api/admin/setup", { name: identity.name, phone: identity.phone, password, confirmPassword: confirm });
      setPassword(""); setConfirm("");
      setPendingAdmin(data.admin);
      setMode("passkey-offer");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر إكمال الإعداد."); }
    finally { setBusy(false); }
  }

  async function registerPasskey() {
    setBusy(true); setError("");
    try {
      const start = await post("/api/admin/security/passkeys", { action: "register-options" });
      let attestation;
      try { attestation = await startRegistration({ optionsJSON: start.options }); }
      catch (caught) { throw new Error(caught instanceof Error && caught.name === "NotAllowedError" ? "أُلغيت العملية أو لم يُمنح الإذن؛ لم تُربط البصمة. يمكنك ربطها لاحقًا من الإعدادات والخصوصية." : "تعذر ربط البصمة على هذا الجهاز. يمكنك المتابعة بكلمة المرور."); }
      await post("/api/admin/security/passkeys", { action: "register-verify", challengeId: start.challengeId, response: attestation, label: "جهاز المسؤول" });
      onAuthenticated(pendingAdmin || { name: identity.name, email: "" });
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر ربط البصمة."); }
    finally { setBusy(false); }
  }

  const loginWithPasskey = useCallback(async () => {
    setBusy(true); setScanning(true); setError("");
    try {
      const start = await post("/api/admin/passkey-login", { action: "options" });
      const assertion = await startAuthentication({ optionsJSON: start.options });
      const data = await post("/api/admin/passkey-login", { action: "verify", challengeId: start.challengeId, response: assertion });
      onAuthenticated(data.admin);
    } catch (caught) {
      setError(caught instanceof Error && caught.name === "NotAllowedError" ? "لم يُتعرف على البصمة أو أُلغيت. حاول مجددًا أو ادخل بكلمة المرور." : caught instanceof Error ? caught.message : "فشل الدخول بالبصمة.");
      setShowPasswordLogin(true);
    } finally { setBusy(false); setScanning(false); }
  }, [onAuthenticated]);

  useEffect(() => {
    if (mode === "login" && passkeyLoginAvailable && webauthn.supported) {
      const timer = window.setTimeout(() => void loginWithPasskey(), 350);
      return () => window.clearTimeout(timer);
    }
  }, [mode, passkeyLoginAvailable, webauthn.supported, loginWithPasskey]);

  async function handleLogin(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      const data = await post("/api/admin/login", { name: identity.name, phone: identity.phone, password });
      setPassword("");
      onAuthenticated(data.admin);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر تسجيل الدخول."); }
    finally { setBusy(false); }
  }

  async function handleRecovery(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      await post("/api/admin/recovery", { name: identity.name, phone: identity.phone, recoveryToken: token, password, confirmPassword: confirm });
      setPassword(""); setConfirm(""); setToken("");
      onAuthenticated({ name: identity.name, email: "" });
    } catch (caught) { setError(caught instanceof Error ? caught.message : "تعذر استعادة الحساب."); }
    finally { setBusy(false); }
  }

  const hints = passwordHints(password);
  const newPasswordFields = <>
    <div className="field" style={{ marginTop: 13 }}><label htmlFor="auth-password">كلمة المرور الجديدة</label><input id="auth-password" className="input" type="password" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required /></div>
    <div className="field" style={{ marginTop: 13 }}><label htmlFor="auth-confirm">تأكيد كلمة المرور</label><input id="auth-confirm" className="input" type="password" autoComplete="new-password" value={confirm} onChange={(event) => setConfirm(event.target.value)} required /></div>
    <div className="notice info" style={{ marginTop: 12 }}><strong>شروط كلمة المرور:</strong><ul style={{ margin: "6px 0 0", paddingInlineStart: 18 }}>{PASSWORD_RULES.map((rule) => <li key={rule}>{rule}</li>)}</ul>{password && (hints.length ? <p style={{ margin: "8px 0 0", color: "#b52738" }}>ينقصها: {hints.join("، ")}</p> : <p style={{ margin: "8px 0 0", color: "#187558" }}>✓ كلمة المرور قوية</p>)}{confirm && confirm !== password && <p style={{ margin: "6px 0 0", color: "#b52738" }}>كلمتا المرور غير متطابقتين.</p>}</div>
  </>;

  const titles: Record<Mode, string> = { loading: "", setup: "مرحبًا بك يا مسؤول التطبيق", "passkey-offer": "ربط البصمة (اختياري)", login: "دخول المسؤول", recovery: "استعادة حساب المسؤول", error: "خطأ" };

  return <section className="modal-card" style={{ margin: "30px auto", maxWidth: 520 }}>
    <div className="login-logo">{logoUrl ? <img src={logoUrl} alt="شعار أبو قمري للعلامات العسكرية" /> : null}<strong>أبو قمري للعلامات العسكرية</strong></div>
    <div className="modal-head"><div><h2>{titles[mode]}</h2><p>{identity.name} · <span dir="ltr">{identity.phone}</span></p></div><button className="close-button" type="button" onClick={onClose} aria-label="إغلاق">×</button></div>

    {mode === "setup" && <form onSubmit={handleSetup}>
      <div className="notice info">تعرّف النظام على بياناتك بوصفك مسؤول التطبيق. أنشئ الآن كلمة مرور قوية لحماية لوحة الإدارة؛ هذه الخطوة تتم مرة واحدة فقط.</div>
      {newPasswordFields}
      {error && <div className="notice" style={{ marginTop: 12 }}>{error}</div>}
      <div className="form-actions"><button className="btn btn-primary btn-block" disabled={busy || hints.length > 0 || confirm !== password}>{busy ? <><span className="spinner" /> جارٍ الحفظ</> : "حفظ كلمة المرور والمتابعة"}</button></div>
    </form>}

    {mode === "passkey-offer" && <div>
      <div className="fingerprint-stage"><FingerprintIcon size={88} /></div>
      <p style={{ textAlign: "center", margin: "6px 0 14px", fontSize: 13 }}>اربط بصمة هذا الجهاز لتدخل لاحقًا بلمسة واحدة. الخطوة اختيارية، وكلمة المرور تبقى وسيلة دخول دائمًا.</p>
      {!webauthn.supported && <div className="notice warning" style={{ marginBottom: 10 }}>هذا المتصفح لا يدعم المصادقة بالبصمة. يمكنك المتابعة بكلمة المرور.</div>}
      {error && <div className="notice" style={{ marginBottom: 10 }}>{error}</div>}
      <div className="form-actions"><button type="button" className="btn btn-primary" style={{ flex: 1 }} disabled={busy || !webauthn.supported} onClick={() => void registerPasskey()}>{busy ? "جارٍ الربط…" : "ربط البصمة الآن"}</button><button type="button" className="btn btn-secondary" disabled={busy} onClick={() => onAuthenticated(pendingAdmin || { name: identity.name, email: "" })}>تخطي الآن</button></div>
    </div>}

    {mode === "login" && <div>
      {passkeyLoginAvailable && webauthn.supported && <button type="button" className="fingerprint-stage as-button" disabled={busy} onClick={() => void loginWithPasskey()} aria-label="الدخول بالبصمة"><FingerprintIcon size={96} active={scanning} /><span>{scanning ? "ضع إصبعك على مستشعر البصمة…" : "اضغط للدخول بالبصمة"}</span></button>}
      {passkeyLoginAvailable && !webauthn.supported && <div className="notice warning">هذا المتصفح لا يدعم الدخول بالبصمة؛ استخدم كلمة المرور.</div>}
      {error && <div className="notice" style={{ marginTop: 10 }}>{error}</div>}
      {(showPasswordLogin || !passkeyLoginAvailable) ? <form onSubmit={handleLogin} style={{ marginTop: 12 }}>
        <div className="field"><label htmlFor="admin-password">كلمة المرور</label><input id="admin-password" className="input" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} autoFocus={!passkeyLoginAvailable} required /></div>
        <div className="form-actions"><button className="btn btn-primary btn-block" disabled={busy}>{busy && !scanning ? <><span className="spinner" /> جارٍ التحقق</> : "دخول بكلمة المرور"}</button></div>
      </form> : <div style={{ textAlign: "center", marginTop: 12 }}><button type="button" className="btn-link" onClick={() => setShowPasswordLogin(true)}>الدخول بكلمة المرور بدلًا من البصمة</button></div>}
      <div style={{ marginTop: 10, textAlign: "center" }}><button type="button" className="btn-link" onClick={() => { setMode("recovery"); setError(""); setPassword(""); }}>نسيت كلمة المرور؟ استعادة الحساب</button></div>
    </div>}

    {mode === "recovery" && <form onSubmit={handleRecovery}>
      <div className="notice info">الاستعادة تتم برمز لمرة واحدة صالح 30 دقيقة يُنشأ من خادم التطبيق بالأمر <code dir="ltr">node scripts/admin-token.mjs recovery</code>. الاستعادة عبر البريد غير مهيأة حاليًا.</div>
      <div className="field" style={{ marginTop: 13 }}><label htmlFor="recovery-token">رمز الاستعادة</label><input id="recovery-token" className="input" dir="ltr" autoComplete="one-time-code" value={token} onChange={(event) => setToken(event.target.value)} required /></div>
      {newPasswordFields}
      {error && <div className="notice" style={{ marginTop: 12 }}>{error}</div>}
      <div className="form-actions"><button className="btn btn-primary" disabled={busy || hints.length > 0 || confirm !== password} style={{ flex: 1 }}>{busy ? "جارٍ الاستعادة…" : "استعادة وتعيين كلمة المرور"}</button><button type="button" className="btn btn-secondary" onClick={() => { setMode("login"); setError(""); }}>رجوع</button></div>
    </form>}
  </section>;
}
