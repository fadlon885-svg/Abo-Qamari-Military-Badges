"use client";

import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { browserSupportsWebAuthn, platformAuthenticatorIsAvailable, startAuthentication, startRegistration } from "@simplewebauthn/browser";
import { PASSWORD_RULES, passwordHints } from "@/components/admin-auth";
import PromoEditor from "@/components/promo-editor";
import type { PromoBanner } from "@/lib/promo-shared";

type Overview = {
  admin: { name: string; email: string; phone: string; passwordChangedAt: string };
  reauthFresh: boolean;
  contact: { adminName: string; contactPhone: string; contactEmail: string; whatsappNumber: string; whatsappUrl: string };
  sessions: { id: number; userAgent: string; ipAddress: string; createdAt: string; lastSeenAt: string; current: boolean }[];
  passkeys: { id: number; label: string; deviceType: string; backedUp: boolean; createdAt: string; lastUsedAt: string | null }[];
  audit: { id: number; event: string; result: string; detail: string; ipAddress: string; createdAt: string }[];
  alerts: { recentFailures24h: number };
  recovery: { adminTokenMethod: boolean; activeToken: boolean; emailMethodConfigured: boolean };
  backup: { manualExport: boolean; scheduled: boolean; lastExportAt: string | null };
  privacy: { customers: number; orders: number; withLocation: number; withReceipts: number };
};

const EVENT_LABELS: Record<string, string> = {
  login_success: "تسجيل دخول", login_failed: "محاولة دخول فاشلة", login_blocked: "إيقاف مؤقت للمحاولات", logout: "تسجيل خروج",
  logout_others: "خروج من الأجهزة الأخرى", session_revoked: "إبطال جلسة", password_changed: "تغيير كلمة المرور", password_change_failed: "فشل تغيير كلمة المرور",
  passkey_added: "ربط البصمة", passkey_removed: "حذف ربط البصمة", passkey_tested: "اختبار البصمة", passkey_test_failed: "فشل اختبار البصمة",
  passkey_add_failed: "فشل ربط البصمة", passkey_login_failed: "فشل الدخول بالبصمة", passkey_error: "خطأ في البصمة", contact_updated: "تحديث بيانات التواصل",
  setup_completed: "تهيئة حساب المسؤول", setup_failed: "محاولة تهيئة فاشلة", recovery_used: "استعادة الحساب", recovery_failed: "محاولة استعادة فاشلة",
  recovery_token_created: "إنشاء رمز استعادة", owner_identified: "التعرف على هوية المالك", reauth_success: "إعادة تحقق", reauth_failed: "فشل إعادة التحقق", backup_exported: "تصدير نسخة بيانات", brand_logo_updated: "اعتماد لوقو جديد", brand_logo_removed: "استعادة اللوقو الأصلي", brand_logo_rejected: "رفض ملف لوقو", promo_banner_updated: "تحديث اللافتة الترويجية", promo_banner_reset: "استعادة اللافتة الافتراضية",
};

function formatDate(value: string | null | undefined) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("ar", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function describeAgent(agent: string) {
  if (!agent) return "جهاز غير معروف";
  const os = /Android/i.test(agent) ? "Android" : /iPhone|iPad/i.test(agent) ? "iOS" : /Windows/i.test(agent) ? "Windows" : /Mac/i.test(agent) ? "macOS" : /Linux/i.test(agent) ? "Linux" : "جهاز";
  const browser = /Edg\//.test(agent) ? "Edge" : /Chrome\//.test(agent) ? "Chrome" : /Firefox\//.test(agent) ? "Firefox" : /Safari\//.test(agent) ? "Safari" : "متصفح";
  return `${browser} على ${os}`;
}

function Card({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return <section className="manage-card" style={{ marginBottom: 12 }}><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}<div style={{ marginTop: 12 }}>{children}</div></section>;
}

type BrandInfo = { hasCustomLogo: boolean; logoUrl: string; iconUrls: { "icon-192": string; "icon-512": string; maskable: string; splash: string } | null; width: number | null; height: number | null; mimeType: string | null; updatedAt: string | null };

function BrandIdentityCard({ notify, onBrandChanged }: { notify: (message: string) => void; onBrandChanged: (url: string) => void }) {
  const [info, setInfo] = useState<BrandInfo | null>(null);
  const [loadError, setLoadError] = useState("");
  const [draft, setDraft] = useState<{ data: string; name: string; size: number; width: number; height: number } | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ tone: "info" | "success" | "warning" | ""; text: string }>({ tone: "", text: "" });
  const [changing, setChanging] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/brand", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل بيانات الهوية.");
      setInfo(data); setLoadError("");
    } catch (error) { setLoadError(error instanceof Error ? error.message : "تعذر تحميل بيانات الهوية."); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function pickFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setStatus({ tone: "", text: "" });
    try {
      if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) throw new Error("الصيغة غير مدعومة. استخدم PNG أو JPG أو WebP.");
      if (file.size > 2_000_000) throw new Error("حجم الملف يتجاوز 2 ميغابايت.");
      const data = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("تعذر قراءة الملف.")); reader.onerror = () => reject(new Error("تعذر قراءة الملف.")); reader.readAsDataURL(file); });
      const dims = await new Promise<{ width: number; height: number }>((resolve, reject) => { const image = new Image(); image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight }); image.onerror = () => reject(new Error("الملف ليس صورة صالحة.")); image.src = data; });
      if (dims.width < 192 || dims.height < 192) throw new Error("دقة الصورة منخفضة؛ يلزم 192 بكسل على الأقل في كل بعد.");
      setDraft({ data, name: file.name, size: file.size, ...dims });
      setPreviewing(false);
      setStatus({ tone: "info", text: "تم اختيار الصورة ولم تُعتمد بعد. اضغط «معاينة قبل الاعتماد» ثم «اعتماد اللوقو»." });
    } catch (error) { setDraft(null); setStatus({ tone: "warning", text: error instanceof Error ? error.message : "تعذر اختيار الصورة." }); }
  }

  async function approve() {
    if (!draft) return;
    setBusy(true);
    setStatus({ tone: "info", text: "جارٍ رفع الصورة وتوليد الأيقونات…" });
    try {
      const response = await fetch("/api/admin/brand", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ logoData: draft.data }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر اعتماد اللوقو.");
      // Verify the stored logo is actually servable before declaring success.
      const check = await fetch(data.logoUrl, { cache: "no-store" });
      if (!check.ok) throw new Error("حُفظت الصورة لكن تعذر عرضها من الخادم؛ لم يُطبَّق التغيير.");
      setInfo(data); setDraft(null); setPreviewing(false); setChanging(false);
      onBrandChanged(data.logoUrl);
      if ("serviceWorker" in navigator) { try { const registration = await navigator.serviceWorker.getRegistration(); await registration?.update(); } catch { /* optional */ } }
      setStatus({ tone: "success", text: "تم الحفظ والتطبيق: الصفحة الرئيسية وشاشة الدخول وملف الأيقونات (manifest) تحدّثت الآن. أيقونة التطبيق المثبت على الهاتف تُحدَّث عند إعادة تثبيته من المتصفح." });
      notify("تم اعتماد اللوقو الجديد.");
    } catch (error) { setStatus({ tone: "warning", text: error instanceof Error ? error.message : "تعذر اعتماد اللوقو؛ اللوقو السابق ما زال فعالًا." }); }
    finally { setBusy(false); }
  }

  async function restoreOriginal() {
    if (!window.confirm("ستُستعاد الهوية الأصلية للتطبيق (الأيقونة الافتراضية) ويُحذف اللوقو المخصص. متابعة؟")) return;
    setBusy(true);
    try {
      const response = await fetch("/api/admin/brand", { method: "DELETE" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر استعادة اللوقو الأصلي.");
      setInfo(data); setDraft(null); setChanging(false);
      onBrandChanged("");
      setStatus({ tone: "success", text: "تمت استعادة اللوقو الأصلي وتطبيقه." });
    } catch (error) { setStatus({ tone: "warning", text: error instanceof Error ? error.message : "تعذر الاستعادة." }); }
    finally { setBusy(false); }
  }

  function cancel() { setDraft(null); setPreviewing(false); setChanging(false); setStatus({ tone: "info", text: "أُلغي التغيير؛ اللوقو الحالي كما هو." }); }

  if (loadError) return <Card title="إدارة هوية التطبيق"><div className="notice">{loadError} <button className="btn-link" onClick={() => void load()}>إعادة المحاولة</button></div></Card>;
  if (!info) return <Card title="إدارة هوية التطبيق"><p className="helper">جارٍ التحميل…</p></Card>;

  const currentSrc = info.hasCustomLogo ? info.logoUrl : "/icon-512.png";
  return <Card title="إدارة هوية التطبيق" subtitle="مصدر مركزي واحد للشعار: الصفحة الرئيسية، شاشة الدخول، أيقونة التطبيق وشاشة التشغيل. تُولَّد أحجام الأيقونات تلقائيًا من الصورة المعتمدة دون قص، مع الاحتفاظ بالأصل.">
    <input ref={fileInput} type="file" accept="image/png,image/jpeg,image/webp" style={{ display: "none" }} onChange={(event) => void pickFile(event)} />
    <div style={{ display: "flex", gap: 16, alignItems: "flex-start", flexWrap: "wrap" }}>
      <div style={{ textAlign: "center" }}><div className="brand-preview"><img src={currentSrc} alt="اللوقو الحالي" /></div><small className="helper">اللوقو الحالي{info.hasCustomLogo ? ` · ${info.width}×${info.height}` : " · الافتراضي"}</small></div>
      {draft && <div style={{ textAlign: "center" }}><div className="brand-preview" style={{ borderColor: "var(--red)", borderStyle: "solid" }}><img src={draft.data} alt="الصورة الجديدة" /></div><small className="helper">الجديدة · {draft.width}×{draft.height} · {(draft.size / 1024).toFixed(0)} ك.ب</small></div>}
    </div>
    {previewing && draft && <div className="brand-stage">
      <div className="brand-stage-item"><div className="topbar-inner" style={{ height: "auto", width: "100%", padding: "8px 0" }}><span className="brand"><img className="brand-logo" src={draft.data} alt="" /><span><strong className="brand-title">أبو قمري للعلامات العسكرية</strong><small className="brand-caption">معاينة الرأس</small></span></span></div></div>
      <div className="brand-stage-item login-logo" style={{ margin: 0 }}><img src={draft.data} alt="" /><strong>معاينة شاشة الدخول</strong></div>
      <div className="brand-stage-item"><div className="brand-app-icon"><img src={draft.data} alt="" /></div><small className="helper">معاينة أيقونة التطبيق</small></div>
    </div>}
    {status.text && <div className={`notice ${status.tone}`} style={{ marginTop: 12 }}>{status.text}</div>}
    <div className="manage-card-actions">
      {!changing && <button type="button" className="btn btn-primary btn-small" disabled={busy} onClick={() => { setChanging(true); fileInput.current?.click(); }}>تغيير اللوقو</button>}
      {changing && <button type="button" className="btn btn-secondary btn-small" disabled={busy} onClick={() => fileInput.current?.click()}>{draft ? "اختيار صورة أخرى" : "اختيار صورة جديدة"}</button>}
      {draft && <button type="button" className="btn btn-secondary btn-small" disabled={busy} onClick={() => setPreviewing((value) => !value)}>{previewing ? "إخفاء المعاينة" : "معاينة قبل الاعتماد"}</button>}
      {draft && <button type="button" className="btn btn-primary btn-small" disabled={busy} onClick={() => void approve()}>{busy ? "جارٍ الاعتماد…" : "اعتماد اللوقو"}</button>}
      {changing && <button type="button" className="btn btn-secondary btn-small" disabled={busy} onClick={cancel}>إلغاء</button>}
      {info.hasCustomLogo && !draft && <button type="button" className="btn btn-danger btn-small" disabled={busy} onClick={() => void restoreOriginal()}>استعادة اللوقو الأصلي</button>}
    </div>
    <p className="helper" style={{ marginTop: 10 }}>الحالة: {info.hasCustomLogo ? `لوقو مخصص محفوظ ومطبّق منذ ${formatDate(info.updatedAt)}` : "يُستخدم اللوقو الأصلي للتطبيق"}{draft ? " · يوجد تغيير غير معتمد" : ""}. تحديث أيقونة التطبيق المثبت على Android لا يتم تلقائيًا من المتصفح: أزل التطبيق من الشاشة الرئيسية ثم أعد تثبيته من Chrome.</p>
  </Card>;
}

export default function SecurityCenter({ onContactSaved, onSignedOut, notify, onBrandChanged, onPromoSaved }: { onContactSaved: () => void; onSignedOut: () => void; notify: (message: string) => void; onBrandChanged: (url: string) => void; onPromoSaved: (banner: PromoBanner) => void }) {
  const [overview, setOverview] = useState<Overview | null>(null);
  const [loadError, setLoadError] = useState("");
  const [busy, setBusy] = useState("");
  const [contactEditing, setContactEditing] = useState(false);
  const [contactDraft, setContactDraft] = useState({ adminName: "", contactPhone: "", contactEmail: "", whatsappNumber: "", whatsappUrl: "" });
  const [passwordForm, setPasswordForm] = useState({ currentPassword: "", password: "", confirmPassword: "", signOutOthers: true });
  const [reauthPrompt, setReauthPrompt] = useState<{ retry: () => Promise<void> } | null>(null);
  const [reauthPassword, setReauthPassword] = useState("");
  const [webauthn, setWebauthn] = useState({ supported: false, platform: false });

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/security", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل مركز الأمان.");
      setOverview(data);
      setContactDraft(data.contact);
      setLoadError("");
    } catch (error) { setLoadError(error instanceof Error ? error.message : "تعذر تحميل مركز الأمان."); }
  }, []);

  useEffect(() => {
    void load();
    const supported = browserSupportsWebAuthn();
    setWebauthn({ supported, platform: false });
    if (supported) platformAuthenticatorIsAvailable().then((platform) => setWebauthn({ supported, platform })).catch(() => undefined);
  }, [load]);

  async function call(path: string, init: RequestInit, retry: () => Promise<void>) {
    const response = await fetch(path, { headers: { "Content-Type": "application/json" }, ...init });
    const data = await response.json().catch(() => ({}));
    if (response.status === 428) { setReauthPrompt({ retry }); throw new Error("__reauth__"); }
    if (!response.ok) throw new Error(data.error || "تعذر إتمام العملية.");
    return data;
  }

  function run(key: string, action: () => Promise<void>) {
    return async () => {
      setBusy(key);
      try { await action(); } catch (error) { if (!(error instanceof Error && error.message === "__reauth__")) notify(error instanceof Error ? error.message : "تعذر إتمام العملية."); }
      finally { setBusy(""); }
    };
  }

  async function submitReauth(event: FormEvent) {
    event.preventDefault();
    const retry = reauthPrompt?.retry;
    setBusy("reauth");
    try {
      const response = await fetch("/api/admin/security/reauth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: reauthPassword }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر التحقق.");
      setReauthPrompt(null); setReauthPassword("");
      if (retry) await retry();
    } catch (error) { if (!(error instanceof Error && error.message === "__reauth__")) notify(error instanceof Error ? error.message : "تعذر التحقق."); }
    finally { setBusy(""); }
  }

  const saveContact = run("contact", async function saveContactAction() {
    const data = await call("/api/admin/security/contact", { method: "PUT", body: JSON.stringify(contactDraft) }, saveContactAction);
    setContactEditing(false);
    notify("تم حفظ بيانات التواصل، وسيُستخدم رابط واتساب الجديد في كل أزرار التواصل.");
    setOverview((current) => current ? { ...current, contact: data.contact } : current);
    onContactSaved();
    await load();
  });

  const changePassword = run("password", async () => {
    const data = await call("/api/admin/security/password", { method: "POST", body: JSON.stringify(passwordForm) }, async () => undefined);
    setPasswordForm({ currentPassword: "", password: "", confirmPassword: "", signOutOthers: true });
    notify(data.revokedSessions ? `تم تغيير كلمة المرور وإبطال ${data.revokedSessions} جلسة أخرى.` : "تم تغيير كلمة المرور بنجاح.");
    await load();
  });

  const signOutOthers = run("sessions-others", async function signOutOthersAction() {
    const data = await call("/api/admin/security/sessions", { method: "DELETE", body: JSON.stringify({ scope: "others" }) }, signOutOthersAction);
    notify(`تم تسجيل الخروج من ${data.revoked} جهاز آخر وإبطال جلساتها على الخادم.`);
    await load();
  });

  const revokeOne = (sessionId: number, current: boolean) => run(`session-${sessionId}`, async () => {
    const data = await call("/api/admin/security/sessions", { method: "DELETE", body: JSON.stringify({ sessionId }) }, async () => undefined);
    if (current || data.signedOut) { notify("تم تسجيل الخروج من هذا الجهاز."); onSignedOut(); return; }
    notify("تم إبطال الجلسة على الخادم.");
    await load();
  });

  const registerPasskey = (replaceOthers: boolean) => run("passkey-register", async function registerAction() {
    if (!webauthn.supported) { notify("هذا المتصفح لا يدعم مفاتيح المرور/البصمة. تبقى كلمة المرور وسيلة الدخول."); return; }
    const start = await call("/api/admin/security/passkeys", { method: "POST", body: JSON.stringify({ action: "register-options" }) }, registerAction);
    let attestation;
    try { attestation = await startRegistration({ optionsJSON: start.options }); }
    catch (error) { throw new Error(error instanceof Error && error.name === "NotAllowedError" ? "أُلغيت العملية أو لم يُمنح الإذن؛ لم تُفعّل البصمة." : "تعذر تسجيل البصمة على هذا الجهاز؛ لم تُفعّل."); }
    await call("/api/admin/security/passkeys", { method: "POST", body: JSON.stringify({ action: "register-verify", challengeId: start.challengeId, response: attestation, label: describeAgent(navigator.userAgent), replaceOthers }) }, async () => undefined);
    notify(replaceOthers ? "تمت إعادة ربط البصمة بنجاح وتأكيدها من الخادم." : "تم ربط البصمة بنجاح وتأكيدها من الخادم.");
    await load();
  });

  const testPasskey = run("passkey-test", async () => {
    const start = await call("/api/admin/security/passkeys", { method: "POST", body: JSON.stringify({ action: "test-options" }) }, async () => undefined);
    let assertion;
    try { assertion = await startAuthentication({ optionsJSON: start.options }); }
    catch { throw new Error("فشل اختبار البصمة أو أُلغي. كلمة المرور ما زالت متاحة."); }
    await call("/api/admin/security/passkeys", { method: "POST", body: JSON.stringify({ action: "test-verify", challengeId: start.challengeId, response: assertion }) }, async () => undefined);
    notify("نجح اختبار البصمة والتحقق من الخادم.");
    await load();
  });

  const removePasskey = (id: number) => run(`passkey-${id}`, async function removeAction() {
    if (!window.confirm("سيُحذف اعتماد البصمة الخاص بالتطبيق فقط (لا يمس بصمة هاتفك). ستبقى كلمة المرور وسيلة الدخول. متابعة؟")) return;
    await call("/api/admin/security/passkeys", { method: "DELETE", body: JSON.stringify({ id }) }, removeAction);
    notify("تم حذف ربط البصمة. الحالة الآن: البصمة غير مفعّلة.");
    await load();
  });

  const exportBackup = run("backup", async () => {
    const response = await fetch("/api/admin/export", { cache: "no-store" });
    if (!response.ok) throw new Error("تعذر إنشاء نسخة البيانات.");
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = `abu-qomari-backup-${new Date().toISOString().slice(0, 10)}.json`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    notify("تم إنشاء نسخة JSON وبدأ تنزيلها. احفظها في مكان آمن.");
    await load();
  });

  if (loadError) return <div className="notice">{loadError} <button className="btn-link" onClick={() => void load()}>إعادة المحاولة</button></div>;
  if (!overview) return <p className="helper">جارٍ تحميل مركز الإعدادات والخصوصية…</p>;

  const hints = passwordHints(passwordForm.password);
  const passkeyActive = overview.passkeys.length > 0;

  return <div>
    <div className="notice success" style={{ marginBottom: 12 }}><strong>حالة الحماية:</strong> كلمة المرور مفعّلة · {passkeyActive ? "البصمة مفعّلة" : "البصمة غير مفعّلة"} · {overview.sessions.length} جلسة نشطة · {overview.alerts.recentFailures24h ? `${overview.alerts.recentFailures24h} محاولة فاشلة خلال 24 ساعة` : "لا محاولات فاشلة خلال 24 ساعة"}</div>

    <Card title="بيانات التواصل" subtitle="المصدر المركزي لرابط واتساب وبيانات المسؤول في التطبيق كله.">
      {!contactEditing ? <>
        <div className="definition-grid">
          <div className="definition"><strong>اسم المسؤول</strong><span>{overview.contact.adminName}</span></div>
          <div className="definition"><strong>الهاتف الأساسي</strong><span dir="ltr">{overview.contact.contactPhone}</span></div>
          <div className="definition"><strong>البريد الإلكتروني</strong><span dir="ltr">{overview.contact.contactEmail}</span></div>
          <div className="definition"><strong>رقم واتساب</strong><span dir="ltr">{overview.contact.whatsappNumber}</span></div>
          <div className="definition" style={{ gridColumn: "1/-1" }}><strong>رابط واتساب</strong><span dir="ltr">{overview.contact.whatsappUrl}</span></div>
        </div>
        <div className="manage-card-actions"><button className="btn btn-primary btn-small" onClick={() => { setContactDraft(overview.contact); setContactEditing(true); }}>تعديل</button><a className="btn btn-secondary btn-small" href={overview.contact.whatsappUrl} target="_blank" rel="noreferrer">اختبار رابط واتساب</a></div>
      </> : <form onSubmit={(event) => { event.preventDefault(); void saveContact(); }}>
        <div className="form-grid">
          <div className="field"><label>اسم المسؤول</label><input className="input" value={contactDraft.adminName} onChange={(event) => setContactDraft((value) => ({ ...value, adminName: event.target.value }))} required /></div>
          <div className="field"><label>رقم الهاتف الأساسي</label><input className="input" dir="ltr" inputMode="tel" value={contactDraft.contactPhone} onChange={(event) => setContactDraft((value) => ({ ...value, contactPhone: event.target.value }))} required /><small className="helper">تغيير الهاتف لا يغيّر رقم واتساب تلقائيًا.</small><button type="button" className="btn-link" style={{ alignSelf: "start" }} onClick={() => { const digits = contactDraft.contactPhone.replace(/\D/g, ""); const number = digits.startsWith("0") && digits.length === 10 ? `249${digits.slice(1)}` : digits; setContactDraft((value) => ({ ...value, whatsappNumber: number, whatsappUrl: `https://wa.me/${number}` })); }}>تحديث رقم واتساب أيضًا</button></div>
          <div className="field"><label>البريد الإلكتروني</label><input className="input" type="email" dir="ltr" value={contactDraft.contactEmail} onChange={(event) => setContactDraft((value) => ({ ...value, contactEmail: event.target.value }))} required /></div>
          <div className="field"><label>رقم واتساب (دولي بدون +)</label><input className="input" dir="ltr" inputMode="numeric" value={contactDraft.whatsappNumber} onChange={(event) => { const number = event.target.value.replace(/\D/g, ""); setContactDraft((value) => ({ ...value, whatsappNumber: number, whatsappUrl: number ? `https://wa.me/${number}` : "" })); }} required /></div>
          <div className="field full"><label>رابط واتساب</label><input className="input" dir="ltr" value={contactDraft.whatsappUrl} onChange={(event) => setContactDraft((value) => ({ ...value, whatsappUrl: event.target.value }))} required /><small className="helper">الافتراضي: https://wa.me/249129834873 — يجب أن يطابق رقم واتساب.</small></div>
        </div>
        <div className="form-actions"><button className="btn btn-primary" disabled={busy === "contact"}>{busy === "contact" ? "جارٍ الحفظ…" : "حفظ"}</button><button type="button" className="btn btn-secondary" onClick={() => { setContactDraft(overview.contact); setContactEditing(false); }}>إلغاء</button></div>
        <p className="helper">تغيير البريد أو الهاتف يتطلب إعادة التحقق بكلمة المرور.</p>
      </form>}
    </Card>

    <BrandIdentityCard notify={notify} onBrandChanged={onBrandChanged} />

    <Card title="اللافتة الترويجية" subtitle="اللافتة الحمراء في أعلى الصفحة الرئيسية: العنوان والوصف والصورة والزرّان. تُحفظ في جدول promo_banner وتظهر للزبائن فور الحفظ.">
      <PromoEditor notify={notify} onSaved={onPromoSaved} />
    </Card>

    <Card title="كلمة المرور" subtitle={`آخر تغيير: ${formatDate(overview.admin.passwordChangedAt)}`}>
      <form onSubmit={(event) => { event.preventDefault(); void changePassword(); }}>
        <div className="form-grid">
          <div className="field full"><label>كلمة المرور الحالية</label><input className="input" type="password" autoComplete="current-password" value={passwordForm.currentPassword} onChange={(event) => setPasswordForm((value) => ({ ...value, currentPassword: event.target.value }))} required /></div>
          <div className="field"><label>كلمة المرور الجديدة</label><input className="input" type="password" autoComplete="new-password" value={passwordForm.password} onChange={(event) => setPasswordForm((value) => ({ ...value, password: event.target.value }))} required /></div>
          <div className="field"><label>إعادة كتابة الجديدة</label><input className="input" type="password" autoComplete="new-password" value={passwordForm.confirmPassword} onChange={(event) => setPasswordForm((value) => ({ ...value, confirmPassword: event.target.value }))} required /></div>
        </div>
        <div className="notice info" style={{ marginTop: 10 }}>الشروط: {PASSWORD_RULES.join(" · ")}{passwordForm.password && (hints.length ? <p style={{ margin: "6px 0 0", color: "#b52738" }}>ينقصها: {hints.join("، ")}</p> : <p style={{ margin: "6px 0 0", color: "#187558" }}>✓ قوية</p>)}</div>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 10, fontSize: 12 }}><input type="checkbox" checked={passwordForm.signOutOthers} onChange={(event) => setPasswordForm((value) => ({ ...value, signOutOthers: event.target.checked }))} /> تسجيل الخروج من الأجهزة الأخرى بعد التغيير (موصى به)</label>
        <div className="form-actions"><button className="btn btn-primary" disabled={busy === "password" || hints.length > 0 || passwordForm.password !== passwordForm.confirmPassword}>{busy === "password" ? "جارٍ الحفظ…" : "تغيير كلمة المرور"}</button></div>
      </form>
    </Card>

    <Card title="إدارة البصمة" subtitle="تُستخدم مفاتيح المرور (WebAuthn) الخاصة بالتطبيق؛ لا تُجمع صور البصمة ولا تُخزَّن في قاعدة البيانات، وكلمة المرور تبقى وسيلة الدخول البديلة.">
      <div className={`notice ${passkeyActive ? "success" : "info"}`}><strong>الحالة:</strong> {passkeyActive ? "البصمة مفعّلة" : "البصمة غير مفعّلة"}{!webauthn.supported && " · هذا المتصفح لا يدعم المصادقة الحيوية"}{webauthn.supported && !webauthn.platform && " · لا توجد بصمة/قفل جهاز متاح في هذا المتصفح حاليًا"}</div>
      {overview.passkeys.map((key) => <div className="account-row" key={key.id}><span>{key.label || "اعتماد"} · {key.backedUp ? "مزامن" : "على الجهاز"}</span><span className="helper">آخر استخدام: {formatDate(key.lastUsedAt)}</span><button className="btn btn-danger btn-small" disabled={busy === `passkey-${key.id}`} onClick={() => void removePasskey(key.id)()}>حذف ربط البصمة</button></div>)}
      <div className="manage-card-actions">
        {!passkeyActive && <button className="btn btn-primary btn-small" disabled={busy === "passkey-register" || !webauthn.supported} onClick={() => void registerPasskey(false)()}>{busy === "passkey-register" ? "جارٍ الربط…" : "ربط البصمة"}</button>}
        {passkeyActive && <>
          <button className="btn btn-primary btn-small" disabled={busy === "passkey-test" || !webauthn.supported} onClick={() => void testPasskey()}>اختبار البصمة</button>
          <button className="btn btn-secondary btn-small" disabled={busy === "passkey-register" || !webauthn.supported} onClick={() => void registerPasskey(true)()}>إعادة ربط البصمة</button>
          <button className="btn btn-secondary btn-small" disabled={busy === "passkey-register" || !webauthn.supported} onClick={() => void registerPasskey(false)()}>إضافة جهاز آخر</button>
        </>}
      </div>
    </Card>

    <Card title="استعادة الحساب" subtitle="لا تعتمد الاستعادة على الاسم أو الهاتف.">
      <div className="definition-grid">
        <div className="definition"><strong>رمز استعادة إداري</strong><span>متاح · {overview.recovery.activeToken ? "يوجد رمز نشط غير مستخدم" : "لا يوجد رمز نشط"}</span></div>
        <div className="definition"><strong>الاستعادة عبر البريد</strong><span>{overview.recovery.emailMethodConfigured ? "مهيأة" : "غير مهيأة — تحتاج ربط خدمة بريد (SMTP/Resend) على الخادم"}</span></div>
      </div>
      <p className="helper" style={{ marginTop: 8 }}>الإرشادات: من خادم التطبيق نفّذ <code dir="ltr">node scripts/admin-token.mjs recovery</code>، ثم من شاشة دخول المسؤول اختر «استعادة الحساب» وأدخل الرمز (صالح 30 دقيقة ولمرة واحدة) وكلمة مرور جديدة. ستُبطل كل الجلسات السابقة.</p>
    </Card>

    <Card title="الجلسات النشطة" subtitle="الخروج يُبطل الجلسة على الخادم فعليًا.">
      {overview.sessions.map((session) => <div className="account-row" key={session.id}><span>{describeAgent(session.userAgent)}{session.current ? " · هذا الجهاز" : ""}</span><span className="helper">آخر نشاط: {formatDate(session.lastSeenAt)}{session.ipAddress ? ` · ${session.ipAddress}` : ""}</span><button className="btn btn-secondary btn-small" disabled={busy === `session-${session.id}`} onClick={() => void revokeOne(session.id, session.current)()}>{session.current ? "تسجيل الخروج من هذا الجهاز" : "إنهاء الجلسة"}</button></div>)}
      <div className="manage-card-actions"><button className="btn btn-danger btn-small" disabled={busy === "sessions-others" || overview.sessions.length < 2} onClick={() => void signOutOthers()}>تسجيل الخروج من الأجهزة الأخرى</button></div>
    </Card>

    <Card title="تنبيهات الأمان وسجل الأنشطة" subtitle="يُسجَّل الوقت ونوع العملية والنتيجة فقط؛ لا تُسجَّل كلمات المرور أو الرموز.">
      {overview.alerts.recentFailures24h > 0 && <div className="notice warning" style={{ marginBottom: 10 }}>رُصدت {overview.alerts.recentFailures24h} محاولة فاشلة خلال 24 ساعة. بعد 8 محاولات فاشلة من العنوان نفسه (أو 30 على الحساب) خلال 15 دقيقة تُوقف المحاولات مؤقتًا.</div>}
      <div style={{ maxHeight: 320, overflow: "auto" }}>{overview.audit.length === 0 ? <p className="helper">لا توجد أحداث مسجلة بعد.</p> : overview.audit.map((entry) => <div className="account-row" key={entry.id}><span><span className={`status-pill ${entry.result === "success" ? "green" : entry.result === "info" ? "" : "red"}`}>{EVENT_LABELS[entry.event] || entry.event}</span> {entry.detail && entry.detail.includes("@") && entry.result !== "success" ? "" : entry.detail}</span><span className="helper">{formatDate(entry.createdAt)}</span></div>)}</div>
    </Card>

    <Card title="إعدادات الخصوصية وبيانات الزبائن" subtitle="كل بند أدناه يعكس سلوكًا مطبقًا فعليًا في الخادم.">
      <div className="definition-grid">
        <div className="definition"><strong>الزبائن المسجلون</strong><span>{overview.privacy.customers}</span></div>
        <div className="definition"><strong>الطلبات</strong><span>{overview.privacy.orders}</span></div>
        <div className="definition"><strong>طلبات بموقع GPS</strong><span>{overview.privacy.withLocation}</span></div>
        <div className="definition"><strong>طلبات بإيصال مرفق</strong><span>{overview.privacy.withReceipts}</span></div>
      </div>
      <ul style={{ margin: "10px 0 0", paddingInlineStart: 18, fontSize: 12, lineHeight: 1.9 }}>
        <li><b>ما نجمعه:</b> اسم الزبون وهاتفه، تفاصيل الطلب والكمية، موقع GPS وقت الطلب، وإيصال الدفع إن رُفع — لغرض تنفيذ الطلب والتواصل فقط.</li>
        <li><b>وصول الزبون:</b> يرى طلبه فقط عبر رمز وصول خاص يُنشأ على جهازه؛ تخمين رقم الطلب لا يكشفه (مطبّق).</li>
        <li><b>بيانات الإدارة والمواقع والإيصالات:</b> لا تُعرض إلا لجلسة مسؤول صالحة على الخادم (مطبّق).</li>
        <li><b>التصدير:</b> متاح للمسؤول فقط من قسم النسخ الاحتياطي أدناه ويُسجَّل في سجل الأنشطة.</li>
        <li><b>الاحتفاظ والحذف:</b> الأرشفة لا تحذف سجلات الطلبات التاريخية لأغراض التوثيق التجاري؛ لا يوجد حذف تلقائي مجدول حاليًا.</li>
        <li><b>المشاركة مع جهات خارجية:</b> لا تُرسل بيانات الزبائن لأي خدمة خارجية؛ لا يوجد تكامل بريد أو دفع أو تتبع.</li>
      </ul>
    </Card>

    <Card title="إعدادات التطبيق العامة" subtitle="روابط إلى الإعدادات المتاحة فعليًا.">
      <div className="definition-grid">
        <div className="definition"><strong>اسم التطبيق</strong><span>أبو قمري للعلامات العسكرية</span></div>
        <div className="definition"><strong>اللغة والاتجاه</strong><span>العربية · RTL (ثابت)</span></div>
        <div className="definition"><strong>الأصناف</strong><span>من تبويب «الأصناف»</span></div>
        <div className="definition"><strong>وسائل الدفع وأرقام الحسابات</strong><span>من تبويب «الإعدادات»</span></div>
        <div className="definition"><strong>التقارير</strong><span>من تبويب «التقارير» (PDF/CSV/مشاركة)</span></div>
        <div className="definition"><strong>الإشعارات</strong><span>غير متاحة حاليًا — تحتاج خدمة دفع إشعارات خارجية</span></div>
      </div>
    </Card>

    <Card title="النسخ الاحتياطي والاستعادة" subtitle="تصدير يدوي متاح؛ لا توجد جدولة تلقائية مهيأة.">
      <div className="definition-grid">
        <div className="definition"><strong>حالة الخدمة</strong><span>تصدير يدوي JSON · النسخ المجدول غير مهيأ (يُضبط لدى مزود PostgreSQL)</span></div>
        <div className="definition"><strong>آخر تصدير ناجح</strong><span>{formatDate(overview.backup.lastExportAt)}</span></div>
      </div>
      <p className="helper" style={{ marginTop: 8 }}>الاستعادة: ملف JSON يحتوي الأصناف والزبائن والطلبات والإعدادات والصور؛ يُستعاد بإدراجه في قاعدة PostgreSQL عبر مسؤول النظام. لا يتضمن كلمات المرور أو رموز الجلسات.</p>
      <div className="manage-card-actions"><button className="btn btn-primary btn-small" disabled={busy === "backup"} onClick={() => void exportBackup()}>{busy === "backup" ? "جارٍ الإنشاء…" : "إنشاء نسخة وتنزيلها"}</button></div>
    </Card>

    {reauthPrompt && <div className="modal-backdrop" role="presentation"><section className="modal-card" role="dialog" aria-modal="true"><div className="modal-head"><div><h2>إعادة التحقق من هويتك</h2><p>هذه العملية حساسة؛ أدخل كلمة المرور الحالية للمتابعة.</p></div><button className="close-button" type="button" onClick={() => { setReauthPrompt(null); setReauthPassword(""); }}>×</button></div><form onSubmit={submitReauth}><div className="field"><label htmlFor="reauth-password">كلمة المرور</label><input id="reauth-password" className="input" type="password" autoComplete="current-password" value={reauthPassword} onChange={(event) => setReauthPassword(event.target.value)} autoFocus required /></div><div className="form-actions"><button className="btn btn-primary" disabled={busy === "reauth"}>{busy === "reauth" ? "جارٍ التحقق…" : "تأكيد ومتابعة"}</button><button type="button" className="btn btn-secondary" onClick={() => { setReauthPrompt(null); setReauthPassword(""); }}>إلغاء</button></div></form></section></div>}
  </div>;
}
