/** Client-safe promo banner types and defaults (no database imports). */
export type PromoBanner = {
  kicker: string;
  title: string;
  description: string;
  imageUrl: string;
  primaryButtonText: string;
  primaryButtonLink: string;
  secondaryButtonText: string;
  secondaryButtonLink: string;
  enabled: boolean;
  updatedAt?: string;
};

/** Default banner = the original hero so the existing look is preserved until the admin edits it. */
export const DEFAULT_PROMO: PromoBanner = {
  kicker: "✦ متجر العلامات والتجهيزات العسكرية",
  title: "علامتك… على ذوقك",
  description: "اختر الصنف، وضّح مواصفاتك، وأرسل طلبك للإدارة مباشرة. الدفع ليس شرطًا لإرسال الطلب، والدفع المقدم تنبيه خاص بالأسماء العسكرية فقط.",
  imageUrl: "",
  primaryButtonText: "استعرض الأصناف",
  primaryButtonLink: "#categories",
  secondaryButtonText: "تواصل معنا عبر واتساب",
  secondaryButtonLink: "whatsapp",
  enabled: true,
};
