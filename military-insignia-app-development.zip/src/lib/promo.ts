import { eq } from "drizzle-orm";
import { db } from "@/db";
import { promoBanner } from "@/db/schema";

export const PROMO_ID = 1;

export { DEFAULT_PROMO, type PromoBanner } from "@/lib/promo-shared";
import { DEFAULT_PROMO, type PromoBanner } from "@/lib/promo-shared";

/** Internal links (#anchor), the special "whatsapp" action, or absolute https URLs only. */
export function isSafePromoLink(value: string) {
  if (!value) return true;
  if (value === "whatsapp" || value === "#categories" || value === "#home") return true;
  if (/^#[A-Za-z0-9_-]{1,60}$/.test(value)) return true;
  if (/^\/[A-Za-z0-9/_\-?=&.%]*$/.test(value)) return true;
  return /^https:\/\/[^\s<>"']{3,500}$/.test(value);
}

export function isSafePromoImage(value: string) {
  if (!value) return true;
  return /^https:\/\/[^\s<>"']{3,800}$/.test(value) || /^\/api\/(brand\/logo|products\/\d+\/image|payment-image)/.test(value) || /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value);
}

export async function getPromoBanner(): Promise<PromoBanner> {
  try {
    const [row] = await db.select().from(promoBanner).where(eq(promoBanner.id, PROMO_ID)).limit(1);
    if (!row) return DEFAULT_PROMO;
    const { id: _id, updatedAt, ...rest } = row;
    return { ...rest, updatedAt: updatedAt.toISOString() };
  } catch {
    return DEFAULT_PROMO;
  }
}
