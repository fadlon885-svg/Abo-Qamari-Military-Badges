import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, categories, orders, products } from "@/db/schema";
import { isForbiddenDimensionField } from "@/lib/catalog-validation";

export const DEFAULT_WHATSAPP_URL = "https://wa.me/249129834873";

const defaultCategories = [
  { slug: "military-names", name: "الأسماء العسكرية", sortOrder: 1, includeInOverall: true },
  { slug: "patches", name: "الباتشات", sortOrder: 2, includeInOverall: true },
  { slug: "diaries", name: "اليوميات", sortOrder: 3, includeInOverall: true },
  { slug: "armed-forces", name: "القوات المسلحة (ق م)", sortOrder: 4, includeInOverall: true },
  { slug: "other", name: "أخرى", sortOrder: 5, includeInOverall: false },
];

let storeInitialization: Promise<void> | null = null;

async function initializeStore() {
  for (const category of defaultCategories) {
    await db.insert(categories).values({ ...category, visible: true }).onConflictDoNothing({ target: categories.slug });
  }
  await db.insert(appSettings).values({
    key: "commerce",
    value: {
      bankak: "1836656",
      fawry: "52151508",
      okash: "1604611",
      paymentInstructions: "وسائل الدفع اختيارية، ويمكن الاتفاق على تفاصيل الدفع مع الإدارة.",
      accountOwner: "محمد عثمان فضلون بابكر",
      whatsappUrl: DEFAULT_WHATSAPP_URL,
    },
  }).onConflictDoNothing({ target: appSettings.key });

  const [categoryRows, productRows] = await Promise.all([
    db.select({ id: categories.id, customFields: categories.customFields }).from(categories),
    db.select({ id: products.id, customFields: products.customFields }).from(products),
  ]);
  for (const category of categoryRows) {
    const fields = category.customFields.filter((field) => !isForbiddenDimensionField(field.label) && !isForbiddenDimensionField(field.key));
    if (fields.length !== category.customFields.length) {
      await db.update(categories).set({ customFields: fields }).where(eq(categories.id, category.id));
    }
  }
  for (const product of productRows) {
    const fields = product.customFields.filter((field) => !isForbiddenDimensionField(field.label) && !isForbiddenDimensionField(field.key));
    if (fields.length !== product.customFields.length) {
      await db.update(products).set({ customFields: fields }).where(eq(products.id, product.id));
    }
  }

  const forbiddenPattern = "(مقاس|لون|الوان|خامة|size|colou?r|material)";
  await db.execute(sql`
    UPDATE orders AS order_row
    SET details = COALESCE((
      SELECT jsonb_object_agg(detail.key, detail.value)
      FROM jsonb_each(order_row.details) AS detail
      WHERE detail.key !~* ${forbiddenPattern}
    ), '{}'::jsonb)
    WHERE EXISTS (
      SELECT 1 FROM jsonb_each(order_row.details) AS detail
      WHERE detail.key ~* ${forbiddenPattern}
    )
  `);
}

export async function ensureStoreDefaults() {
  if (!storeInitialization) {
    storeInitialization = initializeStore().catch((error: unknown) => {
      storeInitialization = null;
      throw error;
    });
  }
  await storeInitialization;
}

export async function getCommerceSettings() {
  await ensureStoreDefaults();
  const [settings] = await db.select().from(appSettings).where(eq(appSettings.key, "commerce")).limit(1);
  return settings?.value ?? {
    bankak: "1836656",
    fawry: "52151508",
    okash: "1604611",
    paymentInstructions: "",
    accountOwner: "محمد عثمان فضلون بابكر",
    whatsappUrl: DEFAULT_WHATSAPP_URL,
  };
}
