import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCallback) as (password: string, salt: Buffer, keylen: number, options: { N: number; r: number; p: number; maxmem: number }) => Promise<Buffer>;

const SCRYPT = { N: 2 ** 15, r: 8, p: 1, keylen: 64, maxmem: 128 * 1024 * 1024 };

export const PASSWORD_RULES = [
  "12 حرفًا على الأقل",
  "تحتوي على حروف وأرقام معًا",
  "ليست كلمة شائعة أو متسلسلة مثل 123456 أو password",
  "لا تتضمن اسمك أو بريدك أو رقم هاتفك",
];

const COMMON = ["password", "123456", "12345678", "123456789", "1234567890", "qwerty", "abc123", "111111", "admin", "iloveyou", "welcome", "letmein", "abuqomari", "ابوقمري"];

export function passwordProblems(password: string, context: string[] = []) {
  const problems: string[] = [];
  const value = password || "";
  const lower = value.toLowerCase();
  if (value.length < 12) problems.push("كلمة المرور قصيرة؛ يلزم 12 حرفًا على الأقل.");
  if (value.length > 128) problems.push("كلمة المرور طويلة جدًا.");
  if (!/[\p{L}]/u.test(value) || !/\d/.test(value)) problems.push("يجب أن تجمع كلمة المرور بين حروف وأرقام.");
  if (COMMON.some((common) => lower.includes(common))) problems.push("كلمة المرور تحتوي على مقطع شائع يسهل تخمينه.");
  if (/^(.)\1+$/.test(value)) problems.push("لا يجوز تكرار حرف واحد فقط.");
  if (/(0123|1234|2345|3456|4567|5678|6789|abcd|qwer)/i.test(value) && value.length < 16) problems.push("تجنب التسلسلات السهلة مثل 1234 أو abcd.");
  for (const item of context) {
    const token = (item || "").toLowerCase().trim();
    if (token.length >= 4 && lower.includes(token)) { problems.push("لا تستخدم اسمك أو بريدك أو رقم هاتفك داخل كلمة المرور."); break; }
    const local = token.split("@")[0];
    if (local.length >= 4 && lower.includes(local)) { problems.push("لا تستخدم اسمك أو بريدك أو رقم هاتفك داخل كلمة المرور."); break; }
  }
  return problems;
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const key = await scrypt(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString("base64url")}$${key.toString("base64url")}`;
}

export async function verifyPassword(password: string, stored: string) {
  try {
    const [scheme, n, r, p, saltText, keyText] = stored.split("$");
    if (scheme !== "scrypt") return false;
    const expected = Buffer.from(keyText, "base64url");
    const actual = await scrypt(password, Buffer.from(saltText, "base64url"), expected.length, { N: Number(n), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem });
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}
