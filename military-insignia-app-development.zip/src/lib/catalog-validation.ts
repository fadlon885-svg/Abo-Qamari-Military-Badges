import type { CustomFieldDefinition } from "@/db/schema";
import { cleanText } from "@/lib/order-utils";

export function isForbiddenDimensionField(value: string) {
  const normalized = value.normalize("NFKC").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[إأآ]/g, "ا").toLowerCase();
  return /(مقاس|لون|الوان|خامة|size|colou?r|material)/i.test(normalized);
}

export function normalizeFieldDefinitions(value: unknown): CustomFieldDefinition[] | null {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 20) return null;
  const fields: CustomFieldDefinition[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object" || Array.isArray(item)) return null;
    const raw = item as Record<string, unknown>;
    const key = cleanText(raw.key, 50).replace(/[^a-zA-Z0-9_-]/g, "");
    const label = cleanText(raw.label, 70);
    const type = raw.type === "textarea" || raw.type === "select" ? raw.type : "text";
    if (!key || !label || isForbiddenDimensionField(key) || isForbiddenDimensionField(label)) return null;
    const options = Array.isArray(raw.options) ? raw.options.slice(0, 30).map((option) => cleanText(option, 80)).filter(Boolean) : [];
    if (type === "select" && !options.length) return null;
    fields.push({ key, label, type, required: Boolean(raw.required), ...(type === "select" ? { options } : {}) });
  }
  return fields;
}
