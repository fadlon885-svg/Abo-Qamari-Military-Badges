/** Byte-level validation for uploaded images: declared type must match magic bytes and the file must decode. */
const MAX_BYTES = 1_500_000;
const MAX_PIXELS = 30_000_000;

export type ValidatedImage = { dataUrl: string; mimeType: string; width: number; height: number };

function sniff(bytes: Buffer): "image/png" | "image/jpeg" | "image/webp" | null {
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes.toString("ascii", 1, 4) === "PNG") return "image/png";
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  return null;
}

export async function validateImageDataUrl(value: unknown, options: { maxBytes?: number } = {}): Promise<ValidatedImage | null> {
  if (typeof value !== "string" || value.length > (options.maxBytes ?? MAX_BYTES) * 1.4) return null;
  const match = value.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return null;
  const bytes = Buffer.from(match[2], "base64");
  if (!bytes.length || bytes.length > (options.maxBytes ?? MAX_BYTES)) return null;
  const sniffed = sniff(bytes);
  if (!sniffed || sniffed !== match[1]) return null;
  try {
    const sharp = (await import("sharp")).default;
    const meta = await sharp(bytes, { failOn: "error", limitInputPixels: MAX_PIXELS }).metadata();
    if (!meta.width || !meta.height || !meta.format) return null;
    const format = meta.format === "jpeg" ? "image/jpeg" : meta.format === "png" ? "image/png" : meta.format === "webp" ? "image/webp" : null;
    if (format !== sniffed) return null;
    return { dataUrl: `data:${sniffed};base64,${match[2]}`, mimeType: sniffed, width: meta.width, height: meta.height };
  } catch {
    return null;
  }
}
