import { randomBytes } from "node:crypto";
import { headers } from "next/headers";
import { and, eq, lt } from "drizzle-orm";
import { db } from "@/db";
import { adminChallenges } from "@/db/schema";

export const RP_NAME = "أبو قمري للعلامات العسكرية";
const CHALLENGE_MINUTES = 5;

export async function relyingParty() {
  const h = await headers();
  const host = (h.get("x-forwarded-host") || h.get("host") || "localhost").split(",")[0].trim();
  const hostname = host.replace(/:\d+$/, "");
  const proto = (h.get("x-forwarded-proto") || (hostname === "localhost" || hostname === "127.0.0.1" ? "http" : "https")).split(",")[0].trim();
  const originHeader = h.get("origin");
  const expectedOrigin = originHeader && originHeader.includes(hostname) ? originHeader : `${proto}://${host}`;
  return { rpID: hostname, expectedOrigin };
}

export async function storeChallenge(purpose: string, challenge: string) {
  const id = randomBytes(18).toString("base64url");
  await db.delete(adminChallenges).where(lt(adminChallenges.expiresAt, new Date()));
  await db.insert(adminChallenges).values({ id, purpose, challenge, expiresAt: new Date(Date.now() + CHALLENGE_MINUTES * 60_000) });
  return id;
}

export async function consumeChallenge(purpose: string, id: string) {
  if (!id) return null;
  const [row] = await db.select().from(adminChallenges).where(and(eq(adminChallenges.id, id), eq(adminChallenges.purpose, purpose))).limit(1);
  if (!row) return null;
  await db.delete(adminChallenges).where(eq(adminChallenges.id, id));
  if (row.expiresAt.getTime() < Date.now()) return null;
  return row.challenge;
}
