import { createHash, randomBytes } from "node:crypto";

export const ORDER_STATUSES = ["جديد", "قيد المراجعة", "بانتظار الاتفاق", "قيد التجهيز", "جاهز", "تم التسليم", "مرفوض", "ملغى"] as const;
export const PAYMENT_STATUSES = ["غير مدفوع", "بانتظار الدفع", "بانتظار التحقق", "مدفوع ومؤكد", "مسترد"] as const;
export const PAYMENT_METHODS = ["بنكك", "فوري", "أوكاش"] as const;

export function hashAccessToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function createOrderCode() {
  const day = new Date().toISOString().slice(2, 10).replaceAll("-", "");
  return `AQ-${day}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

export function cleanText(value: unknown, maxLength = 2000) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, maxLength);
}
