export type ReportShareResult = "shared" | "unsupported" | "cancelled";

export async function createArabicReportPdf(root: HTMLElement) {
  const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
    import("html2canvas"),
    import("jspdf"),
  ]);
  const blocks = Array.from(root.querySelectorAll<HTMLElement>("[data-pdf-block]"));
  if (!blocks.length) throw new Error("لا توجد صفحات لإنشاء التقرير.");
  const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  const pageWidth = 190;
  const pageHeight = 277;

  for (const [index, block] of blocks.entries()) {
    const canvas = await html2canvas(block, {
      scale: 1.5,
      backgroundColor: "#ffffff",
      useCORS: true,
      logging: false,
      windowWidth: Math.max(document.documentElement.clientWidth, block.scrollWidth),
    });
    if (index > 0) pdf.addPage("a4", "portrait");
    const naturalHeight = (canvas.height / canvas.width) * pageWidth;
    const fit = Math.min(1, pageHeight / naturalHeight);
    const imageWidth = pageWidth * fit;
    const imageHeight = naturalHeight * fit;
    const left = (210 - imageWidth) / 2;
    const top = Math.max(10, (297 - imageHeight) / 2);
    pdf.addImage(canvas.toDataURL("image/jpeg", 0.94), "JPEG", left, top, imageWidth, imageHeight, undefined, "FAST");
  }
  return pdf.output("blob") as Blob;
}

export async function shareReportFile(file: File): Promise<ReportShareResult> {
  if (typeof navigator === "undefined" || typeof navigator.share !== "function") return "unsupported";
  try {
    if (typeof navigator.canShare === "function" && !navigator.canShare({ files: [file] })) return "unsupported";
    await navigator.share({ files: [file], title: "تقرير أبو قمري للعلامات العسكرية" });
    return "shared";
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
    return "unsupported";
  }
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.style.display = "none";
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
