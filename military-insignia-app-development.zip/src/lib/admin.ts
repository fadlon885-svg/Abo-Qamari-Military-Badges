import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { cookies, headers } from "next/headers";
import { and, desc, eq, gt, inArray, isNull, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { adminAccounts, adminAuditLog, adminSessions, adminTokens, appSettings } from "@/db/schema";

export const ADMIN_COOKIE = "abuqomari_admin";
export const DEFAULT_ADMIN = { name: "محمد عثمان فضلون", email: "mohammedfadlon885@gmail.com", phone: "0129834873" };
const SESSION_HOURS = 12;
const REAUTH_MINUTES = 10;
const FAILURE_WINDOW_MINUTES = 15;
const FAILURE_LIMIT = 8;

export type AdminAccount = typeof adminAccounts.$inferSelect;
export type AdminSession = typeof adminSessions.$inferSelect;

export function sha256(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function requestMeta() {
  const h = await headers();
  const forwarded = (h.get("x-forwarded-for") || "").split(",")[0].trim();
  return {
    ip: (forwarded || h.get("x-real-ip") || "").slice(0, 80),
    userAgent: (h.get("user-agent") || "").slice(0, 250),
  };
}

export async function getAdminAccount(): Promise<AdminAccount | null> {
  const [account] = await db.select().from(adminAccounts).orderBy(adminAccounts.id).limit(1);
  return account ?? null;
}

export async function logAudit(event: string, result: "success" | "failure" | "blocked" | "info", detail = "", adminId: number | null = null) {
  try {
    const { ip } = await requestMeta();
    await db.insert(adminAuditLog).values({ adminId, event, result, detail: detail.slice(0, 300), ipAddress: ip });
  } catch (error) {
    console.error("Audit log write failed", error);
  }
}

export async function recentFailures(email = "") {
  const { ip } = await requestMeta();
  const since = new Date(Date.now() - FAILURE_WINDOW_MINUTES * 60_000);
  const [row] = await db.select({
    byIp: sql<number>`count(*) filter (where ${adminAuditLog.ipAddress} = ${ip})::int`,
    byAccount: sql<number>`count(*) filter (where ${adminAuditLog.detail} = ${email.toLowerCase()})::int`,
  }).from(adminAuditLog)
    .where(and(inArray(adminAuditLog.result, ["failure", "blocked"]), gt(adminAuditLog.createdAt, since), or(eq(adminAuditLog.ipAddress, ip), email ? eq(adminAuditLog.detail, email.toLowerCase()) : sql`false`)));
  return { byIp: row?.byIp ?? 0, byAccount: email ? row?.byAccount ?? 0 : 0 };
}

/** 8 failures per IP, or 30 per account across all IPs, within 15 minutes. */
export async function isRateLimited(email = "") {
  const failures = await recentFailures(email);
  return failures.byIp >= FAILURE_LIMIT || failures.byAccount >= FAILURE_LIMIT * 4 - 2;
}

export const rateLimitedResponse = () => Response.json({ error: "تم إيقاف المحاولات مؤقتًا بسبب تكرار الفشل. أعد المحاولة بعد 15 دقيقة." }, { status: 429 });
export const unauthorized = () => Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
export const reauthRequired = () => Response.json({ error: "يلزم إعادة التحقق من هويتك قبل تنفيذ هذه العملية.", code: "reauth_required" }, { status: 428 });

export async function createAdminSession(adminId: number, options: { reauth?: boolean } = {}) {
  const token = randomBytes(32).toString("base64url");
  const { ip, userAgent } = await requestMeta();
  const expiresAt = new Date(Date.now() + SESSION_HOURS * 3_600_000);
  await db.insert(adminSessions).values({ adminId, tokenHash: sha256(token), ipAddress: ip, userAgent, expiresAt, reauthAt: options.reauth === false ? null : new Date() });
  const cookieStore = await cookies();
  cookieStore.set(ADMIN_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: SESSION_HOURS * 3600 });
}

export async function getAdminSession(): Promise<{ session: AdminSession; admin: AdminAccount } | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_COOKIE)?.value;
  if (!token || token.length < 20) return null;
  const [row] = await db.select({ session: adminSessions, admin: adminAccounts }).from(adminSessions)
    .innerJoin(adminAccounts, eq(adminSessions.adminId, adminAccounts.id))
    .where(and(eq(adminSessions.tokenHash, sha256(token)), isNull(adminSessions.revokedAt), gt(adminSessions.expiresAt, new Date()))).limit(1);
  if (!row) return null;
  if (Date.now() - row.session.lastSeenAt.getTime() > 60_000) {
    await db.update(adminSessions).set({ lastSeenAt: new Date() }).where(eq(adminSessions.id, row.session.id));
  }
  return row;
}

export async function isAdminRequest() {
  return Boolean(await getAdminSession());
}

export function hasRecentReauth(session: AdminSession) {
  return Boolean(session.reauthAt && Date.now() - session.reauthAt.getTime() < REAUTH_MINUTES * 60_000);
}

export async function markReauth(sessionId: number) {
  await db.update(adminSessions).set({ reauthAt: new Date() }).where(eq(adminSessions.id, sessionId));
}

export async function revokeSession(sessionId: number, adminId: number) {
  await db.update(adminSessions).set({ revokedAt: new Date() }).where(and(eq(adminSessions.id, sessionId), eq(adminSessions.adminId, adminId), isNull(adminSessions.revokedAt)));
}

export async function revokeOtherSessions(adminId: number, keepSessionId: number) {
  const revoked = await db.update(adminSessions).set({ revokedAt: new Date() })
    .where(and(eq(adminSessions.adminId, adminId), ne(adminSessions.id, keepSessionId), isNull(adminSessions.revokedAt))).returning({ id: adminSessions.id });
  return revoked.length;
}

export async function revokeAllSessions(adminId: number) {
  await db.update(adminSessions).set({ revokedAt: new Date() }).where(and(eq(adminSessions.adminId, adminId), isNull(adminSessions.revokedAt)));
}

export async function clearAdminSession() {
  const current = await getAdminSession();
  if (current) await revokeSession(current.session.id, current.admin.id);
  const cookieStore = await cookies();
  cookieStore.set(ADMIN_COOKIE, "", { httpOnly: true, sameSite: "strict", path: "/", maxAge: 0 });
}

export async function listSessions(adminId: number, currentSessionId: number) {
  const rows = await db.select().from(adminSessions)
    .where(and(eq(adminSessions.adminId, adminId), isNull(adminSessions.revokedAt), gt(adminSessions.expiresAt, new Date())))
    .orderBy(desc(adminSessions.lastSeenAt));
  return rows.map((row) => ({ id: row.id, userAgent: row.userAgent, ipAddress: row.ipAddress ? row.ipAddress.replace(/(\d+\.\d+)\.\d+\.\d+/, "$1.x.x") : "", createdAt: row.createdAt, lastSeenAt: row.lastSeenAt, expiresAt: row.expiresAt, current: row.id === currentSessionId }));
}

export async function consumeAdminToken(purpose: "recovery", token: string) {
  if (!token || token.length < 16) return false;
  const hash = sha256(token.trim());
  const [row] = await db.select().from(adminTokens).where(and(eq(adminTokens.purpose, purpose), eq(adminTokens.tokenHash, hash))).limit(1);
  if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) return false;
  const updated = await db.update(adminTokens).set({ usedAt: new Date() }).where(and(eq(adminTokens.id, row.id), isNull(adminTokens.usedAt))).returning({ id: adminTokens.id });
  return updated.length === 1;
}

export async function hasActiveToken(purpose: "recovery") {
  const [row] = await db.select({ id: adminTokens.id }).from(adminTokens)
    .where(and(eq(adminTokens.purpose, purpose), isNull(adminTokens.usedAt), gt(adminTokens.expiresAt, new Date()))).limit(1);
  return Boolean(row);
}

/** Normalises Arabic names and Sudanese phone numbers so the owner identity check tolerates spacing/hamza/prefix variants. */
export function normalizeName(value: string) {
  return value.normalize("NFKC").replace(/[\u064B-\u065F\u0670\u0640]/g, "").replace(/[إأآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/\s+/g, " ").trim().toLowerCase();
}

export function normalizePhone(value: string) {
  const digits = value.replace(/[^0-9]/g, "");
  if (digits.startsWith("00249")) return digits.slice(5);
  if (digits.startsWith("249")) return digits.slice(3);
  if (digits.startsWith("0")) return digits.slice(1);
  return digits;
}

/** The owner identity (name + phone) only opens the admin door; authentication still requires the password or a passkey. */
export function matchesOwnerIdentity(name: string, phone: string, owner: { name: string; phone: string } = DEFAULT_ADMIN) {
  return safeEqual(normalizeName(name), normalizeName(owner.name)) && normalizePhone(phone).length >= 9 && safeEqual(normalizePhone(phone), normalizePhone(owner.phone));
}
