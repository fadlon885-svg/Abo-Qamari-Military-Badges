import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";

export const BRAND_KEY = "brand";
export const BRAND_LOGO_PATH = "/api/brand/logo";
export const ICON_SIZES = [192, 512] as const;
export const SPLASH_SIZE = 1024;

export type BrandVariant = "original" | "icon-192" | "icon-512" | "maskable-512" | "splash";
export type BrandRecord = {
  logoData?: string;
  mimeType?: string;
  width?: number;
  height?: number;
  updatedAt?: string;
  version?: number;
  variants?: Partial<Record<Exclude<BrandVariant, "original">, string>>;
};

export async function getBrand(): Promise<BrandRecord> {
  try {
    const [row] = await db.select().from(appSettings).where(eq(appSettings.key, BRAND_KEY)).limit(1);
    return (row?.value as BrandRecord) ?? {};
  } catch {
    return {};
  }
}

export function brandVersion(brand: BrandRecord) {
  return brand.version || (brand.updatedAt ? new Date(brand.updatedAt).getTime() : 0);
}

export function brandLogoUrl(brand: BrandRecord, variant: BrandVariant = "original") {
  if (!brand.logoData) return "";
  return `${BRAND_LOGO_PATH}?variant=${variant}&v=${brandVersion(brand)}`;
}

export function parseDataUrl(data: string) {
  const match = data.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  return match ? { mimeType: match[1], bytes: Buffer.from(match[2], "base64") } : null;
}

/** Builds PNG icon variants from the approved logo: square padding on white, never cropped or stretched. */
export async function buildBrandVariants(original: Buffer) {
  const sharp = (await import("sharp")).default;
  const image = sharp(original, { failOn: "error" });
  const meta = await image.metadata();
  if (!meta.width || !meta.height) throw new Error("تعذر قراءة أبعاد الصورة.");
  const square = Math.max(meta.width, meta.height);
  const base = await sharp(original).flatten({ background: "#ffffff" }).resize(square, square, { fit: "contain", background: "#ffffff" }).png().toBuffer();
  const render = async (size: number, paddingRatio: number) => {
    const inner = Math.round(size * (1 - paddingRatio * 2));
    const art = await sharp(base).resize(inner, inner, { fit: "contain", background: "#ffffff" }).png().toBuffer();
    return sharp({ create: { width: size, height: size, channels: 4, background: "#ffffff" } })
      .composite([{ input: art, gravity: "centre" }]).png({ compressionLevel: 9 }).toBuffer();
  };
  const [icon192, icon512, maskable512, splash] = await Promise.all([render(192, 0.04), render(512, 0.04), render(512, 0.14), render(SPLASH_SIZE, 0.2)]);
  const toData = (buffer: Buffer) => `data:image/png;base64,${buffer.toString("base64")}`;
  return {
    width: meta.width,
    height: meta.height,
    variants: { "icon-192": toData(icon192), "icon-512": toData(icon512), "maskable-512": toData(maskable512), splash: toData(splash) },
  };
}
