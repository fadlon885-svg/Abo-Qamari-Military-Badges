import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export type CustomFieldDefinition = {
  key: string;
  label: string;
  type: "text" | "textarea" | "select";
  required?: boolean;
  options?: string[];
};

export type OrderDetails = Record<string, string | number | boolean | null>;

export const categories = pgTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    visible: boolean("visible").notNull().default(true),
    archived: boolean("archived").notNull().default(false),
    includeInOverall: boolean("include_in_overall").notNull().default(true),
    customFields: jsonb("custom_fields").$type<CustomFieldDefinition[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ slugUnique: uniqueIndex("categories_slug_unique").on(table.slug) }),
);

export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    customFields: jsonb("custom_fields").$type<CustomFieldDefinition[]>().notNull().default([]),
    unitPrice: text("unit_price"),
    imageUrl: text("image_url"),
    archived: boolean("archived").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ categoryIndex: index("products_category_id_idx").on(table.categoryId) }),
);

export const customers = pgTable(
  "customers",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ phoneIndex: index("customers_phone_idx").on(table.phone) }),
);

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderCode: text("order_code").notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    accessTokenHash: text("access_token_hash").notNull(),
    customerId: integer("customer_id").notNull().references(() => customers.id),
    categoryId: integer("category_id").references(() => categories.id, { onDelete: "set null" }),
    productId: integer("product_id").references(() => products.id, { onDelete: "set null" }),
    categoryNameSnapshot: text("category_name_snapshot").notNull(),
    productNameSnapshot: text("product_name_snapshot").notNull(),
    printedName: text("printed_name"),
    details: jsonb("details").$type<OrderDetails>().notNull().default({}),
    quantity: integer("quantity").notNull().default(1),
    unitPrice: text("unit_price"),
    paymentMethod: text("payment_method"),
    transactionReference: text("transaction_reference"),
    receiptData: text("receipt_data"),
    locationLat: doublePrecision("location_lat"),
    locationLng: doublePrecision("location_lng"),
    orderStatus: text("order_status").notNull().default("جديد"),
    paymentStatus: text("payment_status").notNull().default("غير مدفوع"),
    customerNotes: text("customer_notes").notNull().default(""),
    adminNotes: text("admin_notes").notNull().default(""),
    adminPaymentFollowup: boolean("admin_payment_followup").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    codeUnique: uniqueIndex("orders_order_code_unique").on(table.orderCode),
    idempotencyUnique: uniqueIndex("orders_idempotency_key_unique").on(table.idempotencyKey),
    customerIndex: index("orders_customer_id_idx").on(table.customerId),
    categoryIndex: index("orders_category_id_idx").on(table.categoryId),
    createdIndex: index("orders_created_at_idx").on(table.createdAt),
  }),
);

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** اللافتة الترويجية الحمراء في أعلى الصفحة الرئيسية؛ صف واحد (id = 1) يديره المسؤول. */
export const promoBanner = pgTable("promo_banner", {
  id: serial("id").primaryKey(),
  kicker: text("kicker").notNull().default(""),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  imageUrl: text("image_url").notNull().default(""),
  primaryButtonText: text("primary_button_text").notNull().default(""),
  primaryButtonLink: text("primary_button_link").notNull().default(""),
  secondaryButtonText: text("secondary_button_text").notNull().default(""),
  secondaryButtonLink: text("secondary_button_link").notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const adminAccounts = pgTable(
  "admin_accounts",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    phone: text("phone").notNull().default(""),
    passwordHash: text("password_hash").notNull(),
    passwordChangedAt: timestamp("password_changed_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ emailUnique: uniqueIndex("admin_accounts_email_unique").on(table.email) }),
);

export const adminSessions = pgTable(
  "admin_sessions",
  {
    id: serial("id").primaryKey(),
    adminId: integer("admin_id").notNull().references(() => adminAccounts.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    userAgent: text("user_agent").notNull().default(""),
    ipAddress: text("ip_address").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    reauthAt: timestamp("reauth_at", { withTimezone: true }),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (table) => ({ tokenUnique: uniqueIndex("admin_sessions_token_unique").on(table.tokenHash), adminIndex: index("admin_sessions_admin_idx").on(table.adminId) }),
);

export const adminPasskeys = pgTable(
  "admin_passkeys",
  {
    id: serial("id").primaryKey(),
    adminId: integer("admin_id").notNull().references(() => adminAccounts.id, { onDelete: "cascade" }),
    credentialId: text("credential_id").notNull(),
    publicKey: text("public_key").notNull(),
    counter: integer("counter").notNull().default(0),
    transports: jsonb("transports").$type<string[]>().notNull().default([]),
    deviceType: text("device_type").notNull().default(""),
    backedUp: boolean("backed_up").notNull().default(false),
    label: text("label").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  },
  (table) => ({ credentialUnique: uniqueIndex("admin_passkeys_credential_unique").on(table.credentialId) }),
);

export const adminTokens = pgTable(
  "admin_tokens",
  {
    id: serial("id").primaryKey(),
    purpose: text("purpose").notNull(),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ tokenUnique: uniqueIndex("admin_tokens_hash_unique").on(table.tokenHash) }),
);

export const adminChallenges = pgTable("admin_challenges", {
  id: text("id").primaryKey(),
  purpose: text("purpose").notNull(),
  challenge: text("challenge").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const adminAuditLog = pgTable(
  "admin_audit_log",
  {
    id: serial("id").primaryKey(),
    adminId: integer("admin_id"),
    event: text("event").notNull(),
    result: text("result").notNull(),
    detail: text("detail").notNull().default(""),
    ipAddress: text("ip_address").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ createdIndex: index("admin_audit_created_idx").on(table.createdAt), eventIndex: index("admin_audit_event_idx").on(table.event) }),
);
