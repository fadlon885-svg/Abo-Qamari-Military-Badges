import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { brandLogoUrl, getBrand } from "@/lib/brand";
import "./globals.css";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getBrand();
  const logo = brandLogoUrl(brand);
  return {
    title: "أبو قمري للعلامات العسكرية",
    description: "اطلب العلامات والمنتجات العسكرية بسهولة وتواصل مباشرة مع الإدارة.",
    applicationName: "أبو قمري للعلامات العسكرية",
    manifest: "/manifest.webmanifest",
    appleWebApp: { capable: true, title: "أبو قمري", statusBarStyle: "default" },
    formatDetection: { telephone: false },
    icons: logo
      ? { icon: [{ url: brandLogoUrl(brand, "icon-192"), sizes: "192x192", type: "image/png" }, { url: brandLogoUrl(brand, "icon-512"), sizes: "512x512", type: "image/png" }], apple: [{ url: brandLogoUrl(brand, "icon-512"), sizes: "512x512", type: "image/png" }], shortcut: [{ url: logo }] }
      : { icon: [{ url: "/icon-192.png", sizes: "192x192", type: "image/png" }], apple: [{ url: "/icon-192.png" }] },
  };
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#c91f32",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
