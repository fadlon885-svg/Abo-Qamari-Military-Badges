import StoreApp from "@/components/store-app";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <StoreApp />;
}
