import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return new Response("Not found", { status: 404 });
  const [row] = await db.select({ imageUrl: products.imageUrl, archived: products.archived, updatedAt: products.updatedAt, categoryVisible: categories.visible, categoryArchived: categories.archived })
    .from(products).leftJoin(categories, eq(products.categoryId, categories.id)).where(and(eq(products.id, id))).limit(1);
  if (!row?.imageUrl) return new Response("Not found", { status: 404 });
  const publiclyVisible = !row.archived && row.categoryVisible === true && row.categoryArchived === false;
  if (!publiclyVisible && !(await isAdminRequest())) return new Response("Not found", { status: 404 });
  const data = row.imageUrl.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!data) {
    if (row.imageUrl.startsWith("https://")) return Response.redirect(row.imageUrl, 302);
    return new Response("Not found", { status: 404 });
  }
  const contentType = `image/${data[1]}`;
  return new Response(Buffer.from(data[2], "base64"), {
    headers: {
      "Content-Type": contentType,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": publiclyVisible ? "public, max-age=86400" : "private, no-store",
      "Last-Modified": row.updatedAt.toUTCString(),
    },
  });
}
