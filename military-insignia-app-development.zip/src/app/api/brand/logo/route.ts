import { getBrand, parseDataUrl, type BrandVariant } from "@/lib/brand";

export const dynamic = "force-dynamic";
const VARIANTS: BrandVariant[] = ["original", "icon-192", "icon-512", "maskable-512", "splash"];

export async function GET(request: Request) {
  const brand = await getBrand();
  if (!brand.logoData) return new Response("Not found", { status: 404 });
  const requested = new URL(request.url).searchParams.get("variant") as BrandVariant | null;
  const variant = requested && VARIANTS.includes(requested) ? requested : "original";
  const data = variant === "original" ? brand.logoData : brand.variants?.[variant] || brand.logoData;
  const parsed = parseDataUrl(data);
  if (!parsed) return new Response("Not found", { status: 404 });
  return new Response(parsed.bytes, {
    headers: {
      "Content-Type": parsed.mimeType,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "public, max-age=604800, immutable",
      "Last-Modified": brand.updatedAt ? new Date(brand.updatedAt).toUTCString() : new Date().toUTCString(),
    },
  });
}
