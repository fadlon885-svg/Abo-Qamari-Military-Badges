import { getPromoBanner } from "@/lib/promo";

export const dynamic = "force-dynamic";

/** Public read of the home-page promotional banner. */
export async function GET() {
  const banner = await getPromoBanner();
  return Response.json({ banner }, { headers: { "Cache-Control": "no-store" } });
}
