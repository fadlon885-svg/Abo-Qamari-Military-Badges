import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { ensureStoreDefaults, getCommerceSettings } from "@/lib/store";
import { brandLogoUrl, getBrand } from "@/lib/brand";
import { getPromoBanner } from "@/lib/promo";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureStoreDefaults();
    const [categoryRows, productRows, settings, brand, promo] = await Promise.all([
      db.select().from(categories).where(eq(categories.visible, true)).orderBy(asc(categories.sortOrder), asc(categories.id)),
      db.select().from(products).where(eq(products.archived, false)).orderBy(asc(products.id)),
      getCommerceSettings(),
      getBrand(),
      getPromoBanner(),
    ]);
    const visibleCategories = categoryRows.filter((category) => !category.archived);
    const visibleCategoryIds = new Set(visibleCategories.map((category) => category.id));
    const publicProducts = productRows.filter((product) => product.categoryId !== null && visibleCategoryIds.has(product.categoryId)).map((product) => ({
      ...product,
      imageUrl: product.imageUrl?.startsWith("data:image/") ? `/api/products/${product.id}/image?v=${new Date(product.updatedAt).getTime()}` : product.imageUrl,
    }));
    return Response.json({
      categories: visibleCategories,
      products: publicProducts,
      brandLogoUrl: brandLogoUrl(brand),
      promo,
      settings: {
        whatsappUrl: settings.whatsappUrl,
        bankak: settings.bankak,
        fawry: settings.fawry,
        okash: settings.okash,
        paymentInstructions: settings.paymentInstructions,
        accountOwner: typeof settings.accountOwner === "string" && settings.accountOwner ? settings.accountOwner : "محمد عثمان فضلون بابكر",
        paymentImageUrl: typeof settings.paymentImageData === "string" ? "/api/payment-image" : "",
        contactName: typeof settings.adminName === "string" ? settings.adminName : "محمد عثمان فضلون",
        contactPhone: typeof settings.contactPhone === "string" ? settings.contactPhone : "0129834873",
        contactEmail: typeof settings.contactEmail === "string" ? settings.contactEmail : "mohammedfadlon885@gmail.com",
      },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Catalog could not be loaded", error);
    return Response.json({ error: "تعذر تحميل الأصناف الآن. تحقق من الاتصال ثم أعد المحاولة." }, { status: 503 });
  }
}
