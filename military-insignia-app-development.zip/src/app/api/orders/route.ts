import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, customers, orders, products } from "@/db/schema";
import { isForbiddenDimensionField } from "@/lib/catalog-validation";
import { cleanText, createOrderCode, hashAccessToken, PAYMENT_METHODS } from "@/lib/order-utils";
import { validateImageDataUrl } from "@/lib/image-validation";

export const dynamic = "force-dynamic";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function safeDetails(value: unknown) {
  if (!isRecord(value)) return {};
  const output: Record<string, string | number | boolean | null> = {};
  for (const [key, raw] of Object.entries(value).slice(0, 40)) {
    const cleanKey = cleanText(key, 80);
    if (!cleanKey || isForbiddenDimensionField(cleanKey)) continue;
    if (typeof raw === "string") output[cleanKey] = cleanText(raw, 1500);
    else if (typeof raw === "number" && Number.isFinite(raw)) output[cleanKey] = raw;
    else if (typeof raw === "boolean" || raw === null) output[cleanKey] = raw;
  }
  return output;
}


export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    const parsed: unknown = await request.json();
    if (!isRecord(parsed)) return Response.json({ error: "بيانات الطلب غير مكتملة." }, { status: 400 });
    body = parsed;
  } catch {
    return Response.json({ error: "تعذر قراءة بيانات الطلب." }, { status: 400 });
  }

  const idempotencyKey = cleanText(body.idempotencyKey, 100);
  const accessToken = cleanText(body.accessToken, 150);
  const customerName = cleanText(body.customerName, 120);
  const customerPhone = cleanText(body.customerPhone, 40);
  const categoryId = Number(body.categoryId);
  const quantity = Number(body.quantity);
  if (!idempotencyKey || idempotencyKey.length < 12 || !accessToken || accessToken.length < 20) {
    return Response.json({ error: "تعذر تأمين الطلب. أعد تحميل النموذج وحاول مجددًا." }, { status: 400 });
  }
  if (!customerName || customerPhone.replace(/[^0-9]/g, "").length < 6) {
    return Response.json({ error: "أدخل اسمك ورقم هاتف صحيحًا." }, { status: 400 });
  }
  if (!Number.isInteger(categoryId) || !Number.isInteger(quantity) || quantity < 1 || quantity > 10000) {
    return Response.json({ error: "تحقق من الصنف والكمية." }, { status: 400 });
  }

  const tokenHash = hashAccessToken(accessToken);
  const prior = await db.select().from(orders).where(eq(orders.idempotencyKey, idempotencyKey)).limit(1);
  if (prior[0]) {
    if (prior[0].accessTokenHash !== tokenHash) return Response.json({ error: "تعذر التحقق من الطلب السابق." }, { status: 409 });
    return Response.json({ orderCode: prior[0].orderCode, accessToken, alreadyReceived: true });
  }

  const [category] = await db.select().from(categories).where(and(eq(categories.id, categoryId), eq(categories.visible, true), eq(categories.archived, false))).limit(1);
  if (!category) return Response.json({ error: "هذا الصنف غير متاح حاليًا." }, { status: 400 });

  const productId = body.productId ? Number(body.productId) : null;
  let product = null;
  if (productId !== null) {
    if (!Number.isInteger(productId)) return Response.json({ error: "المنتج المحدد غير صالح." }, { status: 400 });
    const [selected] = await db.select().from(products).where(and(eq(products.id, productId), eq(products.archived, false), eq(products.categoryId, categoryId))).limit(1);
    if (!selected) return Response.json({ error: "المنتج المحدد لم يعد متاحًا." }, { status: 400 });
    product = selected;
  }

  const printedName = cleanText(body.printedName, 150);
  const enteredProductName = cleanText(body.productName, 180);
  if (category.slug === "military-names" && !printedName) {
    return Response.json({ error: "اكتب الاسم المطلوب طباعته حرفيًا." }, { status: 400 });
  }
  const productName = product?.name || enteredProductName || (category.slug === "military-names" ? `اسم عسكري: ${printedName}` : category.name);
  const details = safeDetails(body.details);
  if (!cleanText(details.designDescription, 1500)) {
    return Response.json({ error: "اكتب وصف الطلب." }, { status: 400 });
  }
  for (const field of [...category.customFields, ...(product?.customFields || [])]) {
    if (field.required && !cleanText(details[`حقل مخصص - ${field.label}`], 1500)) {
      return Response.json({ error: `يرجى تعبئة الحقل: ${field.label}` }, { status: 400 });
    }
  }
  const isMilitaryName = category.slug === "military-names";
  const requestedMethod = cleanText(body.paymentMethod, 30);
  const paymentMethod = isMilitaryName && PAYMENT_METHODS.includes(requestedMethod as (typeof PAYMENT_METHODS)[number]) ? requestedMethod : null;
  const transactionReference = isMilitaryName ? cleanText(body.transactionReference, 120) : "";
  let receiptData: string | null = null;
  if (isMilitaryName && body.receiptData) {
    const receipt = await validateImageDataUrl(body.receiptData);
    if (!receipt) return Response.json({ error: "ملف الإيصال ليس صورة PNG/JPEG/WebP صالحة أو تجاوز الحجم المسموح." }, { status: 400 });
    receiptData = receipt.dataUrl;
  }
  const paymentStatus = receiptData || transactionReference ? "بانتظار التحقق" : paymentMethod ? "بانتظار الدفع" : "غير مدفوع";
  const lat = typeof body.locationLat === "number" ? body.locationLat : Number.NaN;
  const lng = typeof body.locationLng === "number" ? body.locationLng : Number.NaN;
  const hasLocation = Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
  if (!hasLocation) {
    return Response.json({ error: "يجب تحديد موقع GPS والموافقة على مشاركته قبل إرسال الطلب." }, { status: 400 });
  }

  try {
    const created = await db.transaction(async (tx) => {
      const [customer] = await tx.insert(customers).values({ name: customerName, phone: customerPhone }).returning({ id: customers.id });
      const [order] = await tx.insert(orders).values({
        orderCode: createOrderCode(),
        idempotencyKey,
        accessTokenHash: tokenHash,
        customerId: customer.id,
        categoryId,
        productId: product?.id ?? null,
        categoryNameSnapshot: category.name,
        productNameSnapshot: productName,
        printedName: isMilitaryName ? printedName : null,
        details,
        quantity,
        unitPrice: product?.unitPrice ?? null,
        paymentMethod,
        transactionReference: transactionReference || null,
        receiptData,
        locationLat: lat,
        locationLng: lng,
        orderStatus: "جديد",
        paymentStatus,
        customerNotes: cleanText(body.customerNotes, 2000),
        adminPaymentFollowup: isMilitaryName,
      }).returning({ orderCode: orders.orderCode });
      return order;
    });
    return Response.json({ orderCode: created.orderCode, accessToken, alreadyReceived: false }, { status: 201 });
  } catch (error) {
    const maybePostgresError = error as { code?: string };
    if (maybePostgresError.code === "23505") {
      const duplicate = await db.select().from(orders).where(eq(orders.idempotencyKey, idempotencyKey)).limit(1);
      if (duplicate[0]?.accessTokenHash === tokenHash) {
        return Response.json({ orderCode: duplicate[0].orderCode, accessToken, alreadyReceived: true });
      }
      return Response.json({ error: "تعذر تكرار الطلب. أعد المحاولة باستخدام النموذج نفسه." }, { status: 409 });
    }
    console.error("Order save failed", error);
    return Response.json({ error: "لم يصل الطلب إلى الإدارة. تحقق من الإنترنت ثم أعد المحاولة؛ احتفظنا ببيانات النموذج." }, { status: 503 });
  }
}
