import { eq } from "drizzle-orm";
import { timingSafeEqual } from "node:crypto";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { hashAccessToken } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

export async function GET(request: Request, context: { params: Promise<{ code: string }> }) {
  const { code } = await context.params;
  const token = new URL(request.url).searchParams.get("token") || "";
  if (token.length < 20) return Response.json({ error: "تعذر العثور على الطلب." }, { status: 404 });
  const [result] = await db.select({
    order: orders,
    customerName: customers.name,
    customerPhone: customers.phone,
  }).from(orders).innerJoin(customers, eq(orders.customerId, customers.id)).where(eq(orders.orderCode, code)).limit(1);
  if (!result) return Response.json({ error: "تعذر العثور على الطلب." }, { status: 404 });
  const providedHash = Buffer.from(hashAccessToken(token));
  const savedHash = Buffer.from(result.order.accessTokenHash);
  if (providedHash.length !== savedHash.length || !timingSafeEqual(providedHash, savedHash)) {
    return Response.json({ error: "تعذر العثور على الطلب." }, { status: 404 });
  }
  const { accessTokenHash: _privateHash, idempotencyKey: _privateKey, adminNotes: _adminNotes, receiptData: _receiptData, ...safeOrder } = result.order;
  return Response.json({ order: { ...safeOrder, customerName: result.customerName, customerPhone: result.customerPhone } }, {
    headers: { "Cache-Control": "private, no-store" },
  });
}
