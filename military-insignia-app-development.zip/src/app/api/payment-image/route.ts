import { getCommerceSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const settings = await getCommerceSettings();
  const data = typeof settings.paymentImageData === "string" ? settings.paymentImageData.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/) : null;
  if (!data) return new Response("Not found", { status: 404 });
  const contentType = `image/${data[1]}`;
  return new Response(Buffer.from(data[2], "base64"), {
    headers: { "Content-Type": contentType, "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store" },
  });
}
