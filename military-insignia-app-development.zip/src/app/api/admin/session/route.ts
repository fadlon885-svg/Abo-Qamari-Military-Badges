import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminPasskeys } from "@/db/schema";
import { getAdminAccount, getAdminSession } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const account = await getAdminAccount();
    const current = account ? await getAdminSession() : null;
    const [passkey] = account ? await db.select({ id: adminPasskeys.id }).from(adminPasskeys).where(eq(adminPasskeys.adminId, account.id)).limit(1) : [];
    return Response.json({
      setupRequired: !account,
      authenticated: Boolean(current),
      admin: current ? { name: current.admin.name, email: current.admin.email } : null,
      passkeyLoginAvailable: Boolean(passkey),
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Session status failed", error);
    return Response.json({ error: "تعذر التحقق من حالة الإدارة." }, { status: 503 });
  }
}
