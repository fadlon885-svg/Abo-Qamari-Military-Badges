import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminPasskeys } from "@/db/schema";
import { getAdminAccount, isRateLimited, logAudit, matchesOwnerIdentity, rateLimitedResponse } from "@/lib/admin";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

/**
 * Called from the regular customer sign-in. Returns whether the entered name + phone belong to the owner.
 * It never grants a session: the caller must still complete first-time setup (password) or log in (password/passkey).
 */
export async function POST(request: Request) {
  if (await isRateLimited()) return rateLimitedResponse();
  let body: { name?: unknown; phone?: unknown };
  try { body = await request.json() as { name?: unknown; phone?: unknown }; } catch { return Response.json({ isAdmin: false }); }
  const name = cleanText(body.name, 120);
  const phone = cleanText(body.phone, 40);
  const account = await getAdminAccount();
  const owner = account ? { name: account.name, phone: account.phone } : undefined;
  const isAdmin = matchesOwnerIdentity(name, phone, owner);
  if (!isAdmin) return Response.json({ isAdmin: false });
  const [passkey] = account ? await db.select({ id: adminPasskeys.id }).from(adminPasskeys).where(eq(adminPasskeys.adminId, account.id)).limit(1) : [];
  await logAudit("owner_identified", "info", account ? "تعرف النظام على هوية المالك عند الدخول" : "تعرف النظام على هوية المالك قبل التهيئة", account?.id ?? null);
  return Response.json({ isAdmin: true, setupRequired: !account, passkeyLoginAvailable: Boolean(passkey) });
}
