import { db } from "@/db";
import { adminAccounts } from "@/db/schema";
import { createAdminSession, DEFAULT_ADMIN, getAdminAccount, isRateLimited, logAudit, matchesOwnerIdentity, rateLimitedResponse } from "@/lib/admin";
import { hashPassword, passwordProblems } from "@/lib/password";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

/** First-time setup: the owner's name + phone open the door once; a strong password is created and hashed. */
export async function POST(request: Request) {
  if (await getAdminAccount()) return Response.json({ error: "تمت تهيئة حساب المسؤول مسبقًا. استخدم تسجيل الدخول أو استعادة الحساب." }, { status: 409 });
  if (await isRateLimited()) return rateLimitedResponse();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const name = cleanText(body.name, 120);
  const phone = cleanText(body.phone, 40);
  const password = typeof body.password === "string" ? body.password : "";
  const confirm = typeof body.confirmPassword === "string" ? body.confirmPassword : "";
  const email = (process.env.ADMIN_EMAIL || DEFAULT_ADMIN.email).toLowerCase();

  if (!matchesOwnerIdentity(name, phone)) {
    await logAudit("setup_failed", "failure", "محاولة تهيئة بهوية غير مطابقة");
    return Response.json({ error: "هذه البيانات لا تخص مسؤول التطبيق." }, { status: 401 });
  }
  if (password !== confirm) return Response.json({ error: "كلمتا المرور غير متطابقتين." }, { status: 400 });
  const problems = passwordProblems(password, [DEFAULT_ADMIN.name, email, DEFAULT_ADMIN.phone, phone]);
  if (problems.length) return Response.json({ error: problems[0], problems }, { status: 400 });

  try {
    const [account] = await db.insert(adminAccounts).values({ name: DEFAULT_ADMIN.name, email, phone: DEFAULT_ADMIN.phone, passwordHash: await hashPassword(password) }).returning();
    await createAdminSession(account.id);
    await logAudit("setup_completed", "success", "تمت تهيئة حساب المسؤول وإنشاء كلمة المرور", account.id);
    return Response.json({ ok: true, admin: { name: account.name, email: account.email } }, { status: 201 });
  } catch (error) {
    console.error("Setup failed", error);
    return Response.json({ error: "تعذر إكمال التهيئة. حاول تسجيل الدخول." }, { status: 409 });
  }
}
