import { eq } from "drizzle-orm";
import { generateAuthenticationOptions, verifyAuthenticationResponse, type AuthenticationResponseJSON } from "@simplewebauthn/server";
import { db } from "@/db";
import { adminPasskeys } from "@/db/schema";
import { createAdminSession, getAdminAccount, isRateLimited, logAudit, rateLimitedResponse } from "@/lib/admin";
import { cleanText } from "@/lib/order-utils";
import { consumeChallenge, relyingParty, storeChallenge } from "@/lib/webauthn";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const account = await getAdminAccount();
  if (!account) return Response.json({ error: "لم تتم تهيئة حساب المسؤول بعد.", code: "setup_required" }, { status: 409 });
  if (await isRateLimited(account.email)) return rateLimitedResponse();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const { rpID, expectedOrigin } = await relyingParty();
  const keys = await db.select().from(adminPasskeys).where(eq(adminPasskeys.adminId, account.id));
  if (!keys.length) return Response.json({ error: "لا توجد بصمة مربوطة بالحساب. استخدم كلمة المرور." }, { status: 400 });
  try {
    if (body.action === "options") {
      const options = await generateAuthenticationOptions({ rpID, userVerification: "required", allowCredentials: keys.map((key) => ({ id: key.credentialId, transports: key.transports as never })) });
      const challengeId = await storeChallenge("login", options.challenge);
      return Response.json({ options, challengeId });
    }
    if (body.action === "verify") {
      const expectedChallenge = await consumeChallenge("login", cleanText(body.challengeId, 100));
      const response = body.response as AuthenticationResponseJSON;
      const key = keys.find((item) => item.credentialId === response?.id);
      if (!expectedChallenge || !key) {
        await logAudit("passkey_login_failed", "failure", account.email);
        return Response.json({ error: "تعذر التحقق من البصمة. استخدم كلمة المرور." }, { status: 401 });
      }
      const verification = await verifyAuthenticationResponse({ response, expectedChallenge, expectedOrigin, expectedRPID: rpID, requireUserVerification: true, credential: { id: key.credentialId, publicKey: new Uint8Array(Buffer.from(key.publicKey, "base64url")), counter: key.counter, transports: key.transports as never } });
      if (!verification.verified) {
        await logAudit("passkey_login_failed", "failure", account.email);
        return Response.json({ error: "فشل الدخول بالبصمة. استخدم كلمة المرور." }, { status: 401 });
      }
      await db.update(adminPasskeys).set({ counter: verification.authenticationInfo.newCounter, lastUsedAt: new Date() }).where(eq(adminPasskeys.id, key.id));
      await createAdminSession(account.id, { reauth: false });
      await logAudit("login_success", "success", `دخول بالبصمة (${key.label})`, account.id);
      return Response.json({ ok: true, admin: { name: account.name, email: account.email } });
    }
    return Response.json({ error: "إجراء غير معروف." }, { status: 400 });
  } catch (error) {
    console.error("Passkey login failed", error);
    await logAudit("passkey_login_failed", "failure", account.email);
    return Response.json({ error: "تعذر إتمام الدخول بالبصمة. استخدم كلمة المرور." }, { status: 400 });
  }
}
