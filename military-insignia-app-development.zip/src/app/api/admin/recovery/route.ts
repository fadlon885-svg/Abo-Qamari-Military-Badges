import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminAccounts } from "@/db/schema";
import { consumeAdminToken, createAdminSession, getAdminAccount, hasActiveToken, isRateLimited, logAudit, matchesOwnerIdentity, rateLimitedResponse, revokeAllSessions } from "@/lib/admin";
import { hashPassword, passwordProblems } from "@/lib/password";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    adminTokenMethod: true,
    activeToken: await hasActiveToken("recovery"),
    emailMethodConfigured: false,
    instructions: "تُنشأ رموز الاستعادة من خادم التطبيق فقط عبر الأمر: node scripts/admin-token.mjs recovery — الرمز صالح 30 دقيقة ولمرة واحدة.",
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const account = await getAdminAccount();
  if (!account) return Response.json({ error: "لا يوجد حساب مسؤول لاستعادته.", code: "setup_required" }, { status: 409 });
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const name = cleanText(body.name, 120);
  const phone = cleanText(body.phone, 40);
  const email = account.email;
  const token = cleanText(body.recoveryToken, 200);
  const password = typeof body.password === "string" ? body.password : "";
  const confirm = typeof body.confirmPassword === "string" ? body.confirmPassword : "";
  if (await isRateLimited(email)) return rateLimitedResponse();
  if (password !== confirm) return Response.json({ error: "كلمتا المرور غير متطابقتين." }, { status: 400 });
  const problems = passwordProblems(password, [account.name, account.email, account.phone]);
  if (problems.length) return Response.json({ error: problems[0], problems }, { status: 400 });
  const identityOk = matchesOwnerIdentity(name, phone, { name: account.name, phone: account.phone });
  const tokenOk = identityOk && (await consumeAdminToken("recovery", token));
  if (!tokenOk) {
    await logAudit("recovery_failed", "failure", email);
    return Response.json({ error: "رمز الاستعادة غير صحيح أو منتهي الصلاحية." }, { status: 401 });
  }
  await db.update(adminAccounts).set({ passwordHash: await hashPassword(password), passwordChangedAt: new Date(), updatedAt: new Date() }).where(eq(adminAccounts.id, account.id));
  await revokeAllSessions(account.id);
  await createAdminSession(account.id);
  await logAudit("recovery_used", "success", "استعادة الحساب وتعيين كلمة مرور جديدة؛ أُبطلت كل الجلسات السابقة", account.id);
  return Response.json({ ok: true });
}
