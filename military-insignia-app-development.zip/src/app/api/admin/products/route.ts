import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { normalizeFieldDefinitions } from "@/lib/catalog-validation";
import { validateImageDataUrl } from "@/lib/image-validation";
import { cleanText } from "@/lib/order-utils";

export async function POST(request: Request) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const name = cleanText(body.name, 150);
    const categoryId = Number(body.categoryId);
    const customFields = normalizeFieldDefinitions(body.customFields);
    if (!name || !Number.isInteger(categoryId) || !customFields) {
      return Response.json({ error: "تحقق من اسم المنتج والصنف والحقول المخصصة." }, { status: 400 });
    }
    const [category] = await db.select({ id: categories.id }).from(categories)
      .where(and(eq(categories.id, categoryId), eq(categories.archived, false))).limit(1);
    if (!category) return Response.json({ error: "الصنف غير موجود أو مؤرشف." }, { status: 400 });
    let imageUrl: string | null = null;
    if (typeof body.imageUrl === "string" && body.imageUrl) {
      if (/^https:\/\//.test(body.imageUrl)) imageUrl = body.imageUrl.slice(0, 2000);
      else {
        const image = await validateImageDataUrl(body.imageUrl);
        if (!image) return Response.json({ error: "الصورة ليست PNG/JPEG/WebP صالحة أو تجاوزت الحجم المسموح." }, { status: 400 });
        imageUrl = image.dataUrl;
      }
    }
    const unitPrice = typeof body.unitPrice === "string" && /^\d{1,9}(\.\d{1,2})?$/.test(body.unitPrice.trim()) ? body.unitPrice.trim() : null;
    const [created] = await db.insert(products).values({
      categoryId,
      name,
      description: cleanText(body.description, 1500),
      customFields,
      unitPrice,
      imageUrl,
    }).returning();
    return Response.json({ product: created }, { status: 201 });
  } catch {
    return Response.json({ error: "تعذر إنشاء المنتج." }, { status: 400 });
  }
}
