import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { normalizeFieldDefinitions } from "@/lib/catalog-validation";
import { validateImageDataUrl } from "@/lib/image-validation";
import { cleanText } from "@/lib/order-utils";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "المنتج غير صالح." }, { status: 400 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const changes: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof body.name === "string") changes.name = cleanText(body.name, 150);
    if (typeof body.description === "string") changes.description = cleanText(body.description, 1500);
    if (typeof body.categoryId === "number" && Number.isInteger(body.categoryId)) {
      const [category] = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, body.categoryId)).limit(1);
      if (!category) return Response.json({ error: "الصنف المحدد غير موجود." }, { status: 400 });
      changes.categoryId = body.categoryId;
    }
    if (body.customFields !== undefined) {
      const fields = normalizeFieldDefinitions(body.customFields);
      if (!fields) return Response.json({ error: "الحقول المخصصة غير صالحة." }, { status: 400 });
      changes.customFields = fields;
    }
    if (body.imageUrl !== undefined) {
      if (!body.imageUrl) changes.imageUrl = null;
      else if (typeof body.imageUrl === "string" && body.imageUrl.startsWith("data:")) {
        const image = await validateImageDataUrl(body.imageUrl);
        if (!image) return Response.json({ error: "الصورة ليست PNG/JPEG/WebP صالحة أو تجاوزت الحجم المسموح." }, { status: 400 });
        changes.imageUrl = image.dataUrl;
      }
      else if (typeof body.imageUrl === "string" && body.imageUrl.startsWith(`/api/products/${id}/image`)) {
        if (!new RegExp(`^/api/products/${id}/image(?:\\?v=\\d+)?$`).test(body.imageUrl)) return Response.json({ error: "مسار الصورة غير صالح." }, { status: 400 });
      }
      else if (typeof body.imageUrl === "string" && /^https:\/\//.test(body.imageUrl)) changes.imageUrl = body.imageUrl.slice(0, 2000);
      else return Response.json({ error: "الصورة غير صالحة أو تجاوزت الحجم المسموح." }, { status: 400 });
    }
    if (body.unitPrice !== undefined) {
      if (body.unitPrice === "" || body.unitPrice === null) changes.unitPrice = null;
      else if (typeof body.unitPrice === "string" && /^\d{1,9}(\.\d{1,2})?$/.test(body.unitPrice.trim())) changes.unitPrice = body.unitPrice.trim();
      else return Response.json({ error: "سعر الوحدة غير صالح." }, { status: 400 });
    }
    if (typeof body.archived === "boolean") changes.archived = body.archived;
    const [updated] = await db.update(products).set(changes).where(eq(products.id, id)).returning();
    if (!updated) return Response.json({ error: "المنتج غير موجود." }, { status: 404 });
    return Response.json({ product: updated });
  } catch {
    return Response.json({ error: "تعذر تحديث المنتج." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "المنتج غير صالح." }, { status: 400 });
  await db.update(products).set({ archived: true, updatedAt: new Date() }).where(eq(products.id, id));
  return Response.json({ ok: true });
}
