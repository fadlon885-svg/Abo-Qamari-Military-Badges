import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { validateImageDataUrl } from "@/lib/image-validation";
import { DEFAULT_WHATSAPP_URL, getCommerceSettings } from "@/lib/store";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

function publicSettings(settings: Record<string, unknown>) {
  const { paymentImageData, ...safe } = settings;
  return { ...safe, paymentImageUrl: typeof paymentImageData === "string" ? "/api/payment-image" : "" };
}

export async function GET() {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  return Response.json({ settings: publicSettings(await getCommerceSettings()) }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function PUT(request: Request) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const url = cleanText(body.whatsappUrl, 250) || DEFAULT_WHATSAPP_URL;
    if (!/^https:\/\/wa\.me\/\d+\/?$/.test(url)) return Response.json({ error: "استخدم رابط واتساب بصيغة https://wa.me/رقم." }, { status: 400 });
    const currentSettings = await getCommerceSettings();
    let paymentImageData = typeof currentSettings.paymentImageData === "string" ? currentSettings.paymentImageData : null;
    if (body.paymentImageUrl === "") paymentImageData = null;
    else if (typeof body.paymentImageUrl === "string" && body.paymentImageUrl.startsWith("data:")) {
      const image = await validateImageDataUrl(body.paymentImageUrl);
      if (!image) return Response.json({ error: "الصورة الإرشادية ليست PNG/JPEG/WebP صالحة أو تجاوزت الحجم المسموح." }, { status: 400 });
      paymentImageData = image.dataUrl;
    }
    else if (typeof body.paymentImageUrl === "string" && body.paymentImageUrl !== "/api/payment-image") {
      return Response.json({ error: "الصورة الإرشادية غير صالحة أو تجاوزت الحجم المسموح." }, { status: 400 });
    }
    const { paymentImageData: _previousImage, ...preserved } = currentSettings;
    const value = {
      ...preserved,
      bankak: cleanText(body.bankak, 80),
      fawry: cleanText(body.fawry, 80),
      okash: cleanText(body.okash, 80),
      paymentInstructions: cleanText(body.paymentInstructions, 600),
      accountOwner: cleanText(body.accountOwner, 120) || "محمد عثمان فضلون بابكر",
      whatsappUrl: url,
      whatsappNumber: url.replace(/\D/g, ""),
      ...(paymentImageData ? { paymentImageData } : {}),
    };
    await db.insert(appSettings).values({ key: "commerce", value, updatedAt: new Date() })
      .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedAt: new Date() } });
    return Response.json({ settings: publicSettings(value) });
  } catch {
    return Response.json({ error: "تعذر حفظ الإعدادات." }, { status: 400 });
  }
}
