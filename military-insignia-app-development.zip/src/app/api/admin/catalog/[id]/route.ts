import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { normalizeFieldDefinitions } from "@/lib/catalog-validation";
import { cleanText } from "@/lib/order-utils";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "الصنف غير صالح." }, { status: 400 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const changes: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof body.name === "string") changes.name = cleanText(body.name, 90);
    if (typeof body.description === "string") changes.description = cleanText(body.description, 400);
    if (typeof body.sortOrder === "number" && Number.isInteger(body.sortOrder)) changes.sortOrder = body.sortOrder;
    if (typeof body.visible === "boolean") changes.visible = body.visible;
    if (typeof body.archived === "boolean") changes.archived = body.archived;
    if (body.customFields !== undefined) {
      const fields = normalizeFieldDefinitions(body.customFields);
      if (!fields) return Response.json({ error: "الحقول المخصصة غير صالحة." }, { status: 400 });
      changes.customFields = fields;
    }
    if (Object.keys(changes).length === 1) return Response.json({ error: "لا توجد تغييرات." }, { status: 400 });
    const [current] = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
    if (!current) return Response.json({ error: "الصنف غير موجود." }, { status: 404 });
    if (current.slug === "other") changes.includeInOverall = false;
    else changes.includeInOverall = true;
    const [updated] = await db.update(categories).set(changes).where(eq(categories.id, id)).returning();
    return Response.json({ category: updated });
  } catch {
    return Response.json({ error: "تعذر تحديث الصنف." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "الصنف غير صالح." }, { status: 400 });
  await db.update(categories).set({ archived: true, visible: false, updatedAt: new Date() }).where(eq(categories.id, id));
  return Response.json({ ok: true });
}
