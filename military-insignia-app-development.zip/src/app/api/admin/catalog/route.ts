import { asc } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { normalizeFieldDefinitions } from "@/lib/catalog-validation";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const [categoryRows, productRows] = await Promise.all([
    db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.id)),
    db.select().from(products).orderBy(asc(products.id)),
  ]);
  const safeProducts = productRows.map((product) => ({
    ...product,
    imageUrl: product.imageUrl?.startsWith("data:image/") ? `/api/products/${product.id}/image?v=${new Date(product.updatedAt).getTime()}` : product.imageUrl,
  }));
  return Response.json({ categories: categoryRows, products: safeProducts }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function POST(request: Request) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const name = cleanText(body.name, 90);
    const customFields = normalizeFieldDefinitions(body.customFields);
    if (!name || !customFields) return Response.json({ error: "أدخل اسمًا صحيحًا وحقولًا مخصصة صالحة." }, { status: 400 });
    const slugInput = typeof body.slug === "string" ? body.slug.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 60) : "";
    const slug = slugInput || `category-${crypto.randomUUID().slice(0, 8)}`;
    const [created] = await db.insert(categories).values({
      slug,
      name,
      description: cleanText(body.description, 400),
      sortOrder: Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : 100,
      visible: body.visible !== false,
      includeInOverall: slug !== "other",
      customFields,
    }).returning();
    return Response.json({ category: created }, { status: 201 });
  } catch {
    return Response.json({ error: "تعذر إنشاء الصنف. تحقق من أن الاسم المختصر غير مستخدم." }, { status: 400 });
  }
}
