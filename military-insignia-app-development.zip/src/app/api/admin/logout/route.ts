import { clearAdminSession, getAdminSession, logAudit } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function POST() {
  const current = await getAdminSession();
  await clearAdminSession();
  if (current) await logAudit("logout", "success", "تسجيل خروج من هذا الجهاز", current.admin.id);
  return Response.json({ ok: true });
}
