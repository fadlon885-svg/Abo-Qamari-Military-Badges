import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminAccounts, appSettings } from "@/db/schema";
import { getAdminSession, hasRecentReauth, logAudit, reauthRequired, unauthorized } from "@/lib/admin";
import { cleanText } from "@/lib/order-utils";
import { getCommerceSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function PUT(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const adminName = cleanText(body.adminName, 120);
  const contactPhone = cleanText(body.contactPhone, 40);
  const contactEmail = cleanText(body.contactEmail, 120).toLowerCase();
  const whatsappNumber = cleanText(body.whatsappNumber, 30).replace(/\D/g, "");
  const providedUrl = cleanText(body.whatsappUrl, 250);
  const whatsappUrl = providedUrl || (whatsappNumber ? `https://wa.me/${whatsappNumber}` : "");

  if (!adminName) return Response.json({ error: "اكتب اسم المسؤول." }, { status: 400 });
  if (contactPhone.replace(/\D/g, "").length < 9) return Response.json({ error: "رقم الهاتف غير صالح." }, { status: 400 });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) return Response.json({ error: "البريد الإلكتروني غير صالح." }, { status: 400 });
  if (whatsappNumber.length < 9 || whatsappNumber.length > 15) return Response.json({ error: "رقم واتساب يجب أن يكون بالصيغة الدولية بدون + (مثل 249129834873)." }, { status: 400 });
  if (!/^https:\/\/wa\.me\/\d{9,15}\/?$/.test(whatsappUrl)) return Response.json({ error: "رابط واتساب يجب أن يكون بصيغة https://wa.me/رقم." }, { status: 400 });
  if (whatsappUrl.replace(/\D/g, "") !== whatsappNumber) return Response.json({ error: "رقم واتساب لا يطابق الرقم الموجود في الرابط." }, { status: 400 });

  const sensitiveChanged = contactEmail !== current.admin.email.toLowerCase() || contactPhone !== current.admin.phone;
  if (sensitiveChanged && !hasRecentReauth(current.session)) return reauthRequired();

  const existing = await getCommerceSettings();
  const value = { ...existing, adminName, contactPhone, contactEmail, whatsappNumber, whatsappUrl };
  await db.insert(appSettings).values({ key: "commerce", value, updatedAt: new Date() })
    .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedAt: new Date() } });
  await db.update(adminAccounts).set({ name: adminName, email: contactEmail, phone: contactPhone, updatedAt: new Date() }).where(eq(adminAccounts.id, current.admin.id));
  const changes: string[] = [];
  if (existing.whatsappUrl !== whatsappUrl) changes.push("رابط واتساب");
  if (contactEmail !== current.admin.email.toLowerCase()) changes.push("البريد الإلكتروني");
  if (contactPhone !== current.admin.phone) changes.push("رقم الهاتف");
  if (adminName !== current.admin.name) changes.push("الاسم");
  await logAudit("contact_updated", "success", changes.length ? `تم تحديث: ${changes.join("، ")}` : "حفظ بيانات التواصل دون تغيير", current.admin.id);
  return Response.json({ ok: true, contact: { adminName, contactPhone, contactEmail, whatsappNumber, whatsappUrl } });
}
