import { clearAdminSession, getAdminSession, hasRecentReauth, listSessions, logAudit, reauthRequired, revokeOtherSessions, revokeSession, unauthorized } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  return Response.json({ sessions: await listSessions(current.admin.id, current.session.id) }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function DELETE(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  let body: { scope?: unknown; sessionId?: unknown };
  try { body = await request.json() as { scope?: unknown; sessionId?: unknown }; } catch { body = {}; }
  if (body.scope === "others") {
    if (!hasRecentReauth(current.session)) return reauthRequired();
    const count = await revokeOtherSessions(current.admin.id, current.session.id);
    await logAudit("logout_others", "success", `تم إبطال ${count} جلسة على أجهزة أخرى`, current.admin.id);
    return Response.json({ ok: true, revoked: count });
  }
  if (body.scope === "current") {
    await clearAdminSession();
    await logAudit("logout", "success", "تسجيل خروج من هذا الجهاز", current.admin.id);
    return Response.json({ ok: true, signedOut: true });
  }
  const sessionId = Number(body.sessionId);
  if (!Number.isInteger(sessionId)) return Response.json({ error: "الجلسة غير صالحة." }, { status: 400 });
  if (sessionId === current.session.id) {
    await clearAdminSession();
    await logAudit("logout", "success", "تسجيل خروج من هذا الجهاز", current.admin.id);
    return Response.json({ ok: true, signedOut: true });
  }
  await revokeSession(sessionId, current.admin.id);
  await logAudit("session_revoked", "success", `إبطال الجلسة رقم ${sessionId}`, current.admin.id);
  return Response.json({ ok: true, revoked: 1 });
}
