import { and, desc, eq, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { adminAuditLog, adminPasskeys, customers, orders } from "@/db/schema";
import { getAdminSession, hasActiveToken, hasRecentReauth, listSessions, unauthorized } from "@/lib/admin";
import { getCommerceSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  const { admin, session } = current;
  const settings = await getCommerceSettings();
  const [sessions, passkeys, audit, counts, lastExport] = await Promise.all([
    listSessions(admin.id, session.id),
    db.select({ id: adminPasskeys.id, label: adminPasskeys.label, deviceType: adminPasskeys.deviceType, backedUp: adminPasskeys.backedUp, createdAt: adminPasskeys.createdAt, lastUsedAt: adminPasskeys.lastUsedAt }).from(adminPasskeys).where(eq(adminPasskeys.adminId, admin.id)).orderBy(desc(adminPasskeys.createdAt)),
    db.select({ id: adminAuditLog.id, event: adminAuditLog.event, result: adminAuditLog.result, detail: adminAuditLog.detail, ipAddress: adminAuditLog.ipAddress, createdAt: adminAuditLog.createdAt }).from(adminAuditLog).orderBy(desc(adminAuditLog.createdAt)).limit(60),
    db.select({
      customers: sql<number>`(select count(*) from ${customers})::int`,
      orders: sql<number>`count(*)::int`,
      withLocation: sql<number>`count(*) filter (where ${orders.locationLat} is not null)::int`,
      withReceipts: sql<number>`count(*) filter (where ${orders.receiptData} is not null)::int`,
    }).from(orders),
    db.select({ createdAt: adminAuditLog.createdAt }).from(adminAuditLog).where(and(eq(adminAuditLog.event, "backup_exported"), isNotNull(adminAuditLog.createdAt))).orderBy(desc(adminAuditLog.createdAt)).limit(1),
  ]);
  const recentFailures = audit.filter((entry) => entry.result === "failure" || entry.result === "blocked").filter((entry) => Date.now() - new Date(entry.createdAt).getTime() < 24 * 3_600_000).length;
  return Response.json({
    admin: { name: admin.name, email: admin.email, phone: admin.phone, passwordChangedAt: admin.passwordChangedAt },
    reauthFresh: hasRecentReauth(session),
    contact: {
      adminName: typeof settings.adminName === "string" ? settings.adminName : admin.name,
      contactPhone: typeof settings.contactPhone === "string" ? settings.contactPhone : admin.phone,
      contactEmail: typeof settings.contactEmail === "string" ? settings.contactEmail : admin.email,
      whatsappNumber: typeof settings.whatsappNumber === "string" ? settings.whatsappNumber : String(settings.whatsappUrl || "").replace(/\D/g, ""),
      whatsappUrl: settings.whatsappUrl,
    },
    sessions,
    passkeys: passkeys.map((key) => ({ ...key, ipAddress: undefined })),
    audit: audit.map((entry) => ({ ...entry, ipAddress: entry.ipAddress.replace(/(\d+\.\d+)\.\d+\.\d+/, "$1.x.x") })),
    alerts: { recentFailures24h: recentFailures },
    recovery: { adminTokenMethod: true, activeToken: await hasActiveToken("recovery"), emailMethodConfigured: false },
    backup: { manualExport: true, scheduled: false, lastExportAt: lastExport[0]?.createdAt ?? null },
    privacy: counts[0] ?? { customers: 0, orders: 0, withLocation: 0, withReceipts: 0 },
  }, { headers: { "Cache-Control": "private, no-store" } });
}
