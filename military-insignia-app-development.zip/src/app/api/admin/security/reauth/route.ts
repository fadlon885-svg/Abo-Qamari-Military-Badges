import { getAdminSession, isRateLimited, logAudit, markReauth, rateLimitedResponse, unauthorized } from "@/lib/admin";
import { verifyPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  if (await isRateLimited(current.admin.email)) return rateLimitedResponse();
  let body: { password?: unknown };
  try { body = await request.json() as { password?: unknown }; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const password = typeof body.password === "string" ? body.password : "";
  if (!(await verifyPassword(password, current.admin.passwordHash))) {
    await logAudit("reauth_failed", "failure", current.admin.email, current.admin.id);
    return Response.json({ error: "كلمة المرور غير صحيحة." }, { status: 401 });
  }
  await markReauth(current.session.id);
  await logAudit("reauth_success", "success", "إعادة التحقق من الهوية", current.admin.id);
  return Response.json({ ok: true });
}
