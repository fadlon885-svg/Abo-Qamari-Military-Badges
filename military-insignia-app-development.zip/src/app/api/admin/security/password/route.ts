import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminAccounts } from "@/db/schema";
import { getAdminSession, isRateLimited, logAudit, markReauth, rateLimitedResponse, revokeOtherSessions, unauthorized } from "@/lib/admin";
import { hashPassword, passwordProblems, verifyPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  if (await isRateLimited(current.admin.email)) return rateLimitedResponse();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
  const password = typeof body.password === "string" ? body.password : "";
  const confirm = typeof body.confirmPassword === "string" ? body.confirmPassword : "";
  if (!(await verifyPassword(currentPassword, current.admin.passwordHash))) {
    await logAudit("password_change_failed", "failure", current.admin.email, current.admin.id);
    return Response.json({ error: "كلمة المرور الحالية غير صحيحة." }, { status: 401 });
  }
  if (password !== confirm) return Response.json({ error: "كلمتا المرور الجديدتان غير متطابقتين." }, { status: 400 });
  if (password === currentPassword) return Response.json({ error: "اختر كلمة مرور مختلفة عن الحالية." }, { status: 400 });
  const problems = passwordProblems(password, [current.admin.name, current.admin.email, current.admin.phone]);
  if (problems.length) return Response.json({ error: problems[0], problems }, { status: 400 });
  await db.update(adminAccounts).set({ passwordHash: await hashPassword(password), passwordChangedAt: new Date(), updatedAt: new Date() }).where(eq(adminAccounts.id, current.admin.id));
  await markReauth(current.session.id);
  const revoked = body.signOutOthers === false ? 0 : await revokeOtherSessions(current.admin.id, current.session.id);
  await logAudit("password_changed", "success", revoked ? `تم تغيير كلمة المرور وإبطال ${revoked} جلسة أخرى` : "تم تغيير كلمة المرور", current.admin.id);
  return Response.json({ ok: true, revokedSessions: revoked });
}
