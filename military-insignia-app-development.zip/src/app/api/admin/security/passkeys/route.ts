import { and, eq } from "drizzle-orm";
import { generateAuthenticationOptions, generateRegistrationOptions, verifyAuthenticationResponse, verifyRegistrationResponse, type AuthenticationResponseJSON, type RegistrationResponseJSON } from "@simplewebauthn/server";
import { db } from "@/db";
import { adminPasskeys } from "@/db/schema";
import { getAdminSession, hasRecentReauth, logAudit, reauthRequired, unauthorized } from "@/lib/admin";
import { cleanText } from "@/lib/order-utils";
import { consumeChallenge, relyingParty, RP_NAME, storeChallenge } from "@/lib/webauthn";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const action = body.action;
  const { rpID, expectedOrigin } = await relyingParty();
  const existing = await db.select().from(adminPasskeys).where(eq(adminPasskeys.adminId, current.admin.id));

  try {
    if (action === "register-options") {
      if (!hasRecentReauth(current.session)) return reauthRequired();
      const options = await generateRegistrationOptions({
        rpName: RP_NAME,
        rpID,
        userName: current.admin.email,
        userDisplayName: current.admin.name,
        userID: new TextEncoder().encode(`admin-${current.admin.id}`),
        attestationType: "none",
        excludeCredentials: existing.map((key) => ({ id: key.credentialId, transports: key.transports as AuthenticatorTransportFuture[] })),
        authenticatorSelection: { residentKey: "preferred", userVerification: "required" },
      });
      const challengeId = await storeChallenge("register", options.challenge);
      return Response.json({ options, challengeId });
    }

    if (action === "register-verify") {
      if (!hasRecentReauth(current.session)) return reauthRequired();
      const expectedChallenge = await consumeChallenge("register", cleanText(body.challengeId, 100));
      if (!expectedChallenge) return Response.json({ error: "انتهت مهلة العملية. ابدأ ربط البصمة من جديد." }, { status: 400 });
      const verification = await verifyRegistrationResponse({ response: body.response as RegistrationResponseJSON, expectedChallenge, expectedOrigin, expectedRPID: rpID, requireUserVerification: true });
      if (!verification.verified || !verification.registrationInfo) {
        await logAudit("passkey_add_failed", "failure", "فشل التحقق من تسجيل الاعتماد", current.admin.id);
        return Response.json({ error: "لم يُقبل اعتماد البصمة من الخادم." }, { status: 400 });
      }
      const { credential, credentialDeviceType, credentialBackedUp } = verification.registrationInfo;
      const label = cleanText(body.label, 60) || "هذا الجهاز";
      await db.insert(adminPasskeys).values({ adminId: current.admin.id, credentialId: credential.id, publicKey: Buffer.from(credential.publicKey).toString("base64url"), counter: credential.counter, transports: credential.transports || [], deviceType: credentialDeviceType, backedUp: credentialBackedUp, label });
      if (body.replaceOthers === true && existing.length) {
        for (const key of existing) await db.delete(adminPasskeys).where(eq(adminPasskeys.id, key.id));
      }
      await logAudit("passkey_added", "success", body.replaceOthers === true ? `إعادة ربط البصمة (${label})` : `ربط البصمة (${label})`, current.admin.id);
      return Response.json({ ok: true });
    }

    if (action === "test-options") {
      if (!existing.length) return Response.json({ error: "لا توجد بصمة مربوطة." }, { status: 400 });
      const options = await generateAuthenticationOptions({ rpID, userVerification: "required", allowCredentials: existing.map((key) => ({ id: key.credentialId, transports: key.transports as AuthenticatorTransportFuture[] })) });
      const challengeId = await storeChallenge("test", options.challenge);
      return Response.json({ options, challengeId });
    }

    if (action === "test-verify") {
      const expectedChallenge = await consumeChallenge("test", cleanText(body.challengeId, 100));
      const response = body.response as AuthenticationResponseJSON;
      const key = existing.find((item) => item.credentialId === response?.id);
      if (!expectedChallenge || !key) return Response.json({ error: "تعذر التحقق من البصمة. أعد المحاولة." }, { status: 400 });
      const verification = await verifyAuthenticationResponse({ response, expectedChallenge, expectedOrigin, expectedRPID: rpID, requireUserVerification: true, credential: { id: key.credentialId, publicKey: new Uint8Array(Buffer.from(key.publicKey, "base64url")), counter: key.counter, transports: key.transports as AuthenticatorTransportFuture[] } });
      if (!verification.verified) {
        await logAudit("passkey_test_failed", "failure", "فشل اختبار البصمة", current.admin.id);
        return Response.json({ error: "فشل اختبار البصمة. يمكنك استخدام كلمة المرور." }, { status: 401 });
      }
      await db.update(adminPasskeys).set({ counter: verification.authenticationInfo.newCounter, lastUsedAt: new Date() }).where(eq(adminPasskeys.id, key.id));
      await logAudit("passkey_tested", "success", `نجح اختبار البصمة (${key.label})`, current.admin.id);
      return Response.json({ ok: true });
    }
    return Response.json({ error: "إجراء غير معروف." }, { status: 400 });
  } catch (error) {
    console.error("Passkey operation failed", error);
    await logAudit("passkey_error", "failure", `خطأ أثناء ${String(action)}`, current.admin.id);
    return Response.json({ error: "تعذر إتمام عملية البصمة على هذا الجهاز أو المتصفح." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  if (!hasRecentReauth(current.session)) return reauthRequired();
  let body: { id?: unknown };
  try { body = await request.json() as { id?: unknown }; } catch { body = {}; }
  const id = Number(body.id);
  if (!Number.isInteger(id)) return Response.json({ error: "الاعتماد غير صالح." }, { status: 400 });
  // Password login always remains available, so removing a passkey never removes the last sign-in method.
  const deleted = await db.delete(adminPasskeys).where(and(eq(adminPasskeys.id, id), eq(adminPasskeys.adminId, current.admin.id))).returning({ id: adminPasskeys.id, label: adminPasskeys.label });
  if (!deleted.length) return Response.json({ error: "الاعتماد غير موجود." }, { status: 404 });
  await logAudit("passkey_removed", "success", `حذف ربط البصمة (${deleted[0].label})`, current.admin.id);
  return Response.json({ ok: true });
}

type AuthenticatorTransportFuture = NonNullable<Parameters<typeof generateAuthenticationOptions>[0]["allowCredentials"]>[number]["transports"] extends (infer T)[] | undefined ? T : never;
