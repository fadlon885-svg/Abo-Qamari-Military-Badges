import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const id = Number((await context.params).id);
  if (!Number.isInteger(id) || id < 1) return Response.json({ error: "الطلب غير صالح." }, { status: 400 });
  const [row] = await db.select({ order: orders, customerName: customers.name, customerPhone: customers.phone })
    .from(orders).innerJoin(customers, eq(orders.customerId, customers.id)).where(eq(orders.id, id)).limit(1);
  if (!row) return Response.json({ error: "الطلب غير موجود." }, { status: 404 });
  const { accessTokenHash: _hash, idempotencyKey: _key, ...safeOrder } = row.order;
  return Response.json({ order: { ...safeOrder, customerName: row.customerName, customerPhone: row.customerPhone } }, {
    headers: { "Cache-Control": "private, no-store" },
  });
}
