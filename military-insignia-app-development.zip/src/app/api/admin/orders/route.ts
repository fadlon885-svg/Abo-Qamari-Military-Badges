import { and, desc, eq, gte, ilike, lte, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { isAdminRequest } from "@/lib/admin";
import { ORDER_STATUSES, PAYMENT_STATUSES } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const conditions: SQL[] = [];
  const query = params.get("q")?.trim().slice(0, 120);
  const category = params.get("category");
  const orderStatus = params.get("orderStatus");
  const paymentStatus = params.get("paymentStatus");
  const from = params.get("from");
  const to = params.get("to");
  if (query) {
    const pattern = `%${query.replace(/[%_]/g, "\\$&")}%`;
    const search = or(ilike(orders.orderCode, pattern), ilike(customers.name, pattern), ilike(customers.phone, pattern), ilike(orders.productNameSnapshot, pattern), ilike(orders.printedName, pattern));
    if (search) conditions.push(search);
  }
  if (category && /^\d+$/.test(category)) conditions.push(eq(orders.categoryId, Number(category)));
  if (orderStatus && ORDER_STATUSES.includes(orderStatus as (typeof ORDER_STATUSES)[number])) conditions.push(eq(orders.orderStatus, orderStatus));
  if (paymentStatus && PAYMENT_STATUSES.includes(paymentStatus as (typeof PAYMENT_STATUSES)[number])) conditions.push(eq(orders.paymentStatus, paymentStatus));
  if (from && /^\d{4}-\d{2}-\d{2}$/.test(from)) conditions.push(gte(orders.createdAt, new Date(`${from}T00:00:00.000Z`)));
  if (to && /^\d{4}-\d{2}-\d{2}$/.test(to)) conditions.push(lte(orders.createdAt, new Date(`${to}T23:59:59.999Z`)));
  const limit = Math.max(1, Math.min(5000, Number(params.get("limit")) || 1000));
  const offset = Math.max(0, Math.min(10_000_000, Number(params.get("offset")) || 0));
  const rows = await db.select({
    order: orders,
    customerName: customers.name,
    customerPhone: customers.phone,
  }).from(orders).innerJoin(customers, eq(orders.customerId, customers.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(orders.createdAt)).limit(limit + 1).offset(offset);
  const hasMore = rows.length > limit;
  const safeRows = rows.slice(0, limit).map(({ order, ...customer }) => {
    const { accessTokenHash: _tokenHash, idempotencyKey: _idempotencyKey, receiptData, ...safeOrder } = order;
    return { order: { ...safeOrder, receiptAvailable: Boolean(receiptData) }, ...customer };
  });
  return Response.json({ orders: safeRows, nextOffset: hasMore ? offset + limit : null }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function PATCH(request: Request) {
  if (!(await isAdminRequest())) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  try {
    const body = await request.json() as Record<string, unknown>;
    const id = Number(body.id);
    if (!Number.isInteger(id) || id < 1) return Response.json({ error: "رقم الطلب غير صالح." }, { status: 400 });
    const changes: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof body.orderStatus === "string") {
      if (!ORDER_STATUSES.includes(body.orderStatus as (typeof ORDER_STATUSES)[number])) return Response.json({ error: "حالة الطلب غير صالحة." }, { status: 400 });
      changes.orderStatus = body.orderStatus;
    }
    if (typeof body.paymentStatus === "string") {
      if (!PAYMENT_STATUSES.includes(body.paymentStatus as (typeof PAYMENT_STATUSES)[number])) return Response.json({ error: "حالة الدفع غير صالحة." }, { status: 400 });
      changes.paymentStatus = body.paymentStatus;
    }
    if (typeof body.adminNotes === "string") changes.adminNotes = body.adminNotes.trim().slice(0, 3000);
    if (Object.keys(changes).length === 1) return Response.json({ error: "لا توجد تغييرات للحفظ." }, { status: 400 });
    const [updated] = await db.update(orders).set(changes).where(eq(orders.id, id)).returning({ id: orders.id });
    if (!updated) return Response.json({ error: "الطلب غير موجود." }, { status: 404 });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "تعذر حفظ التغييرات." }, { status: 400 });
  }
}
