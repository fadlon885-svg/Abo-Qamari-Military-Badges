import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, categories, customers, orders, products } from "@/db/schema";
import { getAdminSession, logAudit } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  const current = await getAdminSession();
  if (!current) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  await logAudit("backup_exported", "success", "تصدير نسخة JSON للبيانات", current.admin.id);
  const [categoryRows, productRows, customerRows, orderRows, settingsRows] = await Promise.all([
    db.select().from(categories).orderBy(asc(categories.id)),
    db.select().from(products).orderBy(asc(products.id)),
    db.select().from(customers).orderBy(asc(customers.id)),
    db.select().from(orders).orderBy(asc(orders.id)),
    db.select().from(appSettings).where(eq(appSettings.key, "commerce")),
  ]);
  const safeOrders = orderRows.map(({ accessTokenHash: _hash, idempotencyKey: _key, ...order }) => order);
  const backup = {
    application: "أبو قمري للعلامات العسكرية",
    exportedAt: new Date().toISOString(),
    note: "نسخة بيانات إدارية. احفظ الملف في مكان آمن؛ يتضمن بيانات الزبائن والمواقع والإيصالات.",
    categories: categoryRows,
    products: productRows,
    customers: customerRows,
    orders: safeOrders,
    settings: settingsRows,
  };
  const date = new Date().toISOString().slice(0, 10);
  return new Response(JSON.stringify(backup, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="abu-qomari-backup-${date}.json"`,
      "Cache-Control": "private, no-store",
    },
  });
}
