import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { getAdminSession, logAudit, unauthorized } from "@/lib/admin";
import { BRAND_KEY, brandLogoUrl, buildBrandVariants, getBrand, parseDataUrl } from "@/lib/brand";
import { validateImageDataUrl } from "@/lib/image-validation";

export const dynamic = "force-dynamic";
const MAX_BYTES = 2_000_000;
const MIN_SIDE = 192;

function describe(brand: Awaited<ReturnType<typeof getBrand>>) {
  return {
    hasCustomLogo: Boolean(brand.logoData),
    logoUrl: brandLogoUrl(brand),
    iconUrls: brand.logoData ? { "icon-192": brandLogoUrl(brand, "icon-192"), "icon-512": brandLogoUrl(brand, "icon-512"), maskable: brandLogoUrl(brand, "maskable-512"), splash: brandLogoUrl(brand, "splash") } : null,
    width: brand.width ?? null,
    height: brand.height ?? null,
    mimeType: brand.mimeType ?? null,
    updatedAt: brand.updatedAt ?? null,
    version: brand.version ?? null,
  };
}

export async function GET() {
  if (!(await getAdminSession())) return unauthorized();
  return Response.json(describe(await getBrand()), { headers: { "Cache-Control": "private, no-store" } });
}

export async function PUT(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  let body: { logoData?: unknown };
  try { body = await request.json() as { logoData?: unknown }; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const data = typeof body.logoData === "string" ? body.logoData : "";
  const parsed = parseDataUrl(data);
  if (!parsed) return Response.json({ error: "ارفع الشعار بصيغة PNG أو JPG أو WebP." }, { status: 400 });
  if (parsed.bytes.length > MAX_BYTES) return Response.json({ error: "حجم الشعار يتجاوز 2 ميغابايت. صغّر الملف دون تغيير نسبته." }, { status: 400 });
  if (!(await validateImageDataUrl(data, { maxBytes: MAX_BYTES }))) return Response.json({ error: "محتوى الملف لا يطابق صورة PNG/JPG/WebP صالحة." }, { status: 400 });

  let built;
  try { built = await buildBrandVariants(parsed.bytes); }
  catch (error) {
    await logAudit("brand_logo_rejected", "failure", "ملف صورة تالف أو غير مدعوم", current.admin.id);
    console.error("Brand variant build failed", error);
    return Response.json({ error: "تعذر قراءة الصورة؛ تأكد أنها ملف صورة سليم." }, { status: 400 });
  }
  if (built.width < MIN_SIDE || built.height < MIN_SIDE) return Response.json({ error: `دقة الشعار منخفضة؛ يلزم ${MIN_SIDE}×${MIN_SIDE} بكسل على الأقل (يفضل 512 فأكثر).` }, { status: 400 });
  const ratio = built.width / built.height;
  if (ratio > 1.6 || ratio < 0.625) return Response.json({ error: "نسبة الشعار بعيدة جدًا عن المربع؛ ستصغر كثيرًا داخل الأيقونة. استخدم نسخة أقرب إلى المربع." }, { status: 400 });

  const previous = await getBrand();
  const value = {
    logoData: data,
    mimeType: parsed.mimeType,
    width: built.width,
    height: built.height,
    variants: built.variants,
    updatedAt: new Date().toISOString(),
    version: Math.max(Date.now(), (previous.version || 0) + 1),
  };
  // Persist only after variants rendered successfully; previous logo stays live until this write commits.
  await db.insert(appSettings).values({ key: BRAND_KEY, value, updatedAt: new Date() }).onConflictDoUpdate({ target: appSettings.key, set: { value, updatedAt: new Date() } });
  await logAudit("brand_logo_updated", "success", `اعتماد شعار جديد ${built.width}×${built.height} (${parsed.mimeType}) مع توليد الأيقونات`, current.admin.id);
  return Response.json({ ok: true, ...describe(value) });
}

export async function DELETE() {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  await db.delete(appSettings).where(eq(appSettings.key, BRAND_KEY));
  await logAudit("brand_logo_removed", "success", "استعادة الشعار الأصلي للتطبيق", current.admin.id);
  return Response.json({ ok: true, ...describe({}) });
}
