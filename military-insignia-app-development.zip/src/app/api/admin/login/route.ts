import { createAdminSession, getAdminAccount, isRateLimited, logAudit, matchesOwnerIdentity, rateLimitedResponse } from "@/lib/admin";
import { verifyPassword } from "@/lib/password";
import { cleanText } from "@/lib/order-utils";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const account = await getAdminAccount();
  if (!account) return Response.json({ error: "لم تتم تهيئة حساب المسؤول بعد.", code: "setup_required" }, { status: 409 });
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }
  const name = cleanText(body.name, 120);
  const phone = cleanText(body.phone, 40);
  const password = typeof body.password === "string" ? body.password : "";
  if (await isRateLimited(account.email)) {
    await logAudit("login_blocked", "blocked", account.email);
    return rateLimitedResponse();
  }
  const identityOk = matchesOwnerIdentity(name, phone, { name: account.name, phone: account.phone });
  const passwordOk = password.length > 0 && (await verifyPassword(password, account.passwordHash));
  if (!identityOk || !passwordOk) {
    await logAudit("login_failed", "failure", account.email);
    return Response.json({ error: "بيانات الدخول غير صحيحة." }, { status: 401 });
  }
  await createAdminSession(account.id);
  await logAudit("login_success", "success", "دخول بكلمة المرور", account.id);
  return Response.json({ ok: true, admin: { name: account.name, email: account.email } });
}
