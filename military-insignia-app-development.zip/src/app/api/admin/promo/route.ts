import { db } from "@/db";
import { promoBanner } from "@/db/schema";
import { getAdminSession, logAudit, unauthorized } from "@/lib/admin";
import { validateImageDataUrl } from "@/lib/image-validation";
import { cleanText } from "@/lib/order-utils";
import { DEFAULT_PROMO, getPromoBanner, isSafePromoImage, isSafePromoLink, PROMO_ID } from "@/lib/promo";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await getAdminSession())) return unauthorized();
  return Response.json({ banner: await getPromoBanner(), defaults: DEFAULT_PROMO }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function PUT(request: Request) {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; } catch { return Response.json({ error: "بيانات غير صالحة." }, { status: 400 }); }

  const title = cleanText(body.title, 120);
  if (!title) return Response.json({ error: "اكتب عنوان اللافتة." }, { status: 400 });
  const values = {
    kicker: cleanText(body.kicker, 80),
    title,
    description: cleanText(body.description, 400),
    primaryButtonText: cleanText(body.primaryButtonText, 40),
    primaryButtonLink: cleanText(body.primaryButtonLink, 500),
    secondaryButtonText: cleanText(body.secondaryButtonText, 40),
    secondaryButtonLink: cleanText(body.secondaryButtonLink, 500),
    enabled: body.enabled !== false,
  };
  for (const [label, link] of [["الزر الأول", values.primaryButtonLink], ["الزر الثاني", values.secondaryButtonLink]] as const) {
    if (!isSafePromoLink(link)) return Response.json({ error: `رابط ${label} غير مسموح. استخدم رابطًا يبدأ بـ https:// أو #categories أو whatsapp.` }, { status: 400 });
  }
  if (values.primaryButtonText && !values.primaryButtonLink) return Response.json({ error: "حدد رابط الزر الأول أو اترك نصه فارغًا." }, { status: 400 });
  if (values.secondaryButtonText && !values.secondaryButtonLink) return Response.json({ error: "حدد رابط الزر الثاني أو اترك نصه فارغًا." }, { status: 400 });

  let imageUrl = typeof body.imageUrl === "string" ? body.imageUrl.trim() : "";
  if (imageUrl.startsWith("data:")) {
    const image = await validateImageDataUrl(imageUrl, { maxBytes: 1_200_000 });
    if (!image) return Response.json({ error: "صورة اللافتة ليست PNG/JPEG/WebP صالحة أو تجاوزت 1.2 ميغابايت." }, { status: 400 });
    imageUrl = image.dataUrl;
  } else if (!isSafePromoImage(imageUrl)) {
    return Response.json({ error: "رابط الصورة يجب أن يبدأ بـ https:// أو أن تُرفع الصورة من الجهاز." }, { status: 400 });
  }

  const record = { ...values, imageUrl, updatedAt: new Date() };
  await db.insert(promoBanner).values({ id: PROMO_ID, ...record }).onConflictDoUpdate({ target: promoBanner.id, set: record });
  await logAudit("promo_banner_updated", "success", `تحديث اللافتة الترويجية: ${title}`, current.admin.id);
  return Response.json({ ok: true, banner: await getPromoBanner() });
}

export async function DELETE() {
  const current = await getAdminSession();
  if (!current) return unauthorized();
  await db.insert(promoBanner).values({ id: PROMO_ID, ...DEFAULT_PROMO, updatedAt: new Date() }).onConflictDoUpdate({ target: promoBanner.id, set: { ...DEFAULT_PROMO, updatedAt: new Date() } });
  await logAudit("promo_banner_reset", "success", "استعادة اللافتة الترويجية الافتراضية", current.admin.id);
  return Response.json({ ok: true, banner: await getPromoBanner() });
}
