import type { MetadataRoute } from "next";
import { brandLogoUrl, getBrand } from "@/lib/brand";

export const dynamic = "force-dynamic";

export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const brand = await getBrand();
  const icons: MetadataRoute.Manifest["icons"] = brand.logoData
    ? [
        { src: brandLogoUrl(brand, "icon-192"), sizes: "192x192", type: "image/png", purpose: "any" },
        { src: brandLogoUrl(brand, "icon-512"), sizes: "512x512", type: "image/png", purpose: "any" },
        { src: brandLogoUrl(brand, "maskable-512"), sizes: "512x512", type: "image/png", purpose: "maskable" },
        { src: brandLogoUrl(brand, "splash"), sizes: "1024x1024", type: "image/png", purpose: "any" },
      ]
    : [
        { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
        { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
        { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
      ];
  return {
    id: "/",
    name: "أبو قمري للعلامات العسكرية",
    short_name: "أبو قمري",
    description: "اطلب العلامات والمنتجات العسكرية بسهولة",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait-primary",
    background_color: "#ffffff",
    theme_color: "#c91f32",
    lang: "ar",
    dir: "rtl",
    icons,
  };
}
