#!/usr/bin/env node
// Generates a one-time admin recovery token directly in the database.
// Usage: node scripts/admin-token.mjs recovery
// The plain token is printed ONCE; only its SHA-256 hash is stored. Valid for 30 minutes.
import "dotenv/config";
import { createHash, randomBytes } from "node:crypto";
import pg from "pg";

const purpose = process.argv[2];
if (purpose !== "recovery") {
  console.error("Usage: node scripts/admin-token.mjs recovery");
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is required.");
  process.exit(1);
}
const token = randomBytes(24).toString("base64url");
const hash = createHash("sha256").update(token).digest("hex");
const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
try {
  await client.query("UPDATE admin_tokens SET used_at = now() WHERE purpose = $1 AND used_at IS NULL", [purpose]);
  await client.query("INSERT INTO admin_tokens (purpose, token_hash, expires_at) VALUES ($1, $2, now() + interval '30 minutes')", [purpose, hash]);
  await client.query("INSERT INTO admin_audit_log (event, result, detail) VALUES ($1, 'info', $2)", [`${purpose}_token_created`, "أُنشئ رمز لمرة واحدة من سطر الأوامر"]);
  console.log(`\nرمز الاستعادة (صالح 30 دقيقة، لمرة واحدة):\n\n  ${token}\n\nلا يُحفظ هذا الرمز في أي مكان آخر. انسخه الآن.`);
} finally {
  await client.end();
}
