# نشر «أبو قمري للعلامات العسكرية» على Vercel

التطبيق Next.js 16 (App Router) + PostgreSQL عبر Drizzle. ليس موقعًا ثابتًا؛ يحتاج قاعدة بيانات دائمة ومتغير بيئة واحدًا مطلوبًا.

## 1) قاعدة البيانات
أنشئ قاعدة PostgreSQL مُدارة (Neon / Supabase / Vercel Postgres) وانسخ رابط الاتصال بصيغة:
`postgresql://USER:PASSWORD@HOST/DB?sslmode=require`

## 2) رفع الكود إلى GitHub
1. فكّ ضغط `AbuQamari_Vercel_Ready.zip`.
2. داخل المجلد: `git init && git add . && git commit -m "Abu Qamari"` ثم ادفعه إلى مستودع GitHub (خاص).

## 3) الاستيراد في Vercel
1. Vercel → Add New → Project → اختر المستودع. سيتعرف تلقائيًا على Next.js (`vercel.json` مرفق).
2. Settings → Environment Variables: أضف `DATABASE_URL` (Production + Preview). اختياريًا `ADMIN_EMAIL`.
3. Deploy.

## 4) إنشاء الجداول (مرة واحدة لكل قاعدة)
من جهازك مع نفس `DATABASE_URL`:
```bash
npm ci
DATABASE_URL="postgresql://..." npm run db:push
```
الأصناف الخمسة وإعدادات الدفع والافتراضية تُنشأ تلقائيًا عند أول فتح للتطبيق.

## 5) أول دخول للمسؤول
افتح الرابط المنشور → اكتب الاسم «محمد عثمان فضلون» والهاتف «0129834873» → ستظهر شاشة إنشاء كلمة مرور قوية → ثم ربط البصمة اختياريًا. **كن أول من يفتح التطبيق بعد النشر.**

## 6) استعادة الحساب (عند الحاجة)
من جهاز يملك `DATABASE_URL`: `DATABASE_URL="..." npm run admin:recovery` ثم «استعادة الحساب» من شاشة دخول المسؤول.

## ملاحظات
- `FRAME_ANCESTORS='none'` (موصى به على Vercel): يفعّل حماية clickjacking (frame-ancestors + X-Frame-Options). يُترك فارغًا في بيئة المعاينة فقط.
- HTTPS على Vercel تلقائي (ضروري لـGPS وPWA والبصمة).
- الصور (الشعار، المنتجات، الإيصالات) تُخزَّن في PostgreSQL؛ لا حاجة لتخزين ملفات خارجي.
- النسخ الاحتياطي: زر «تنزيل نسخة بيانات JSON» من الإدارة، بالإضافة إلى النسخ المجدول لدى مزود القاعدة.
- لا تُرسل رسائل واتساب تلقائيًا؛ لا توجد تكاملات دفع أو بريد.
